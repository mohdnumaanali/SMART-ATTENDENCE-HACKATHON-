const Attendance = require('../models/Attendance');
const Student = require('../models/Student');
const Subject = require('../models/Subject');
const Notification = require('../models/Notification');
const Enrollment = require('../models/Enrollment');
const asyncHandler = require('../utils/asyncHandler');
const http = require('../utils/httpError');
const { toDay } = require('../utils/dates');
const { sendCsv } = require('../utils/csv');
const { pageParams, pageResult } = require('../utils/paginate');
const { oid, getSettings, COUNTS, studentsForSubject, syncAlerts } = require('../utils/stats');
const { correctRecord } = require('../services/attendanceService');
const reports = require('../services/reportService');

const todayStr = () => new Date().toISOString().slice(0, 10);

async function ownSubject(faculty, id) {
  const s = await Subject.findOne({ _id: id, faculty: faculty._id, isActive: true });
  if (!s) throw http(403, 'This subject is not assigned to you');
  return s;
}
const ownSubjects = (faculty, extra = {}) =>
  reports.populatedSubjects({ faculty: faculty._id, ...extra });

async function scopedSubjects(req) {
  const filter = req.query.subject ? { _id: req.query.subject } : {};
  return ownSubjects(req.faculty, filter);
}

exports.overview = asyncHandler(async (req, res) => {
  const subjects = await ownSubjects(req.faculty);
  const ids = subjects.map((s) => s._id);
  const date = toDay(req.query.date || todayStr());

  const enrolledIds = await Enrollment.distinct('student', { subject: { $in: ids } });
  const studentCount = subjects.length
    ? (await Student.distinct('_id', {
        isActive: true,
        $or: [
          ...subjects.map((s) => ({ department: s.department, semester: s.semester, section: { $in: s.sections } })),
          { _id: { $in: enrolledIds } },
        ],
      })).length
    : 0;

  const conducted = await Attendance.aggregate([
    { $match: { subject: { $in: ids } } },
    { $group: { _id: { subject: '$subject', section: '$section', date: '$date', period: '$period' } } },
    { $count: 'n' },
  ]);
  const today = await Attendance.aggregate([
    { $match: { subject: { $in: ids }, date } },
    { $group: { _id: null, ...COUNTS, sessions: { $addToSet: { s: '$subject', sec: '$section', p: '$period' } } } },
  ]);
  const t = today[0] || { present: 0, late: 0, absent: 0, total: 0, sessions: [] };

  res.json({
    subjects: subjects.length, students: studentCount,
    classesConducted: conducted[0] ? conducted[0].n : 0,
    today: { present: t.present, late: t.late, absent: t.absent, total: t.total, sessions: t.sessions.length },
  });
});

exports.subjects = asyncHandler(async (req, res) => {
  const subjects = await ownSubjects(req.faculty);
  const out = [];
  for (const s of subjects) {
    out.push({
      _id: s._id, name: s.name, code: s.code, department: s.department, semester: s.semester,
      sections: s.sections, studentCount: (await studentsForSubject(s)).length,
    });
  }
  res.json(out);
});

exports.classList = asyncHandler(async (req, res) => {
  const subject = await ownSubject(req.faculty, req.params.id);
  const section = String(req.query.section || '').toUpperCase();
  if (!subject.sections.includes(section)) throw http(400, 'Select a valid section for this subject');
  const students = await studentsForSubject(subject, section);

  let existing = new Map();
  let alreadyMarked = false;
  if (req.query.date && req.query.period) {
    const recs = await Attendance.find({
      subject: subject._id, section, date: toDay(req.query.date), period: Number(req.query.period),
    }).select('student status');
    existing = new Map(recs.map((r) => [String(r.student), r.status]));
    alreadyMarked = recs.length > 0;
  }
  res.json({
    alreadyMarked,
    students: students.map((s) => ({
      _id: s._id, name: s.user ? s.user.name : '', rollNumber: s.rollNumber, status: existing.get(String(s._id)) || null,
    })),
  });
});

exports.mark = asyncHandler(async (req, res) => {
  const { subject: subjectId, date, period, records } = req.body;
  const section = String(req.body.section).toUpperCase();
  const subject = await ownSubject(req.faculty, subjectId);
  if (!subject.sections.includes(section)) throw http(400, 'Section is not part of this subject');

  const day = toDay(date);
  if (day.getTime() > Date.now() + 86400000) throw http(400, 'Attendance cannot be marked for a future date');

  const students = await studentsForSubject(subject, section);
  if (!students.length) throw http(400, 'No active students found in this section');
  const statusOf = new Map(records.map((r) => [String(r.student), r.status]));
  if (records.length !== students.length || students.some((s) => !statusOf.has(String(s._id))))
    throw http(400, 'Attendance must be submitted for every student in the section');

  if (await Attendance.exists({ subject: subject._id, section, date: day, period }))
    throw http(409, 'Attendance for this subject, section, date and period is already marked. Use Records to correct it.');
  if (await Attendance.exists({ section, date: day, period, subject: { $ne: subject._id }, student: { $in: students.map((s) => s._id) } }))
    throw http(409, 'This period is already used by another subject for this section on that date');

  const docs = students.map((s) => ({
    student: s._id, subject: subject._id, faculty: req.faculty._id, section, date: day, period,
    status: statusOf.get(String(s._id)),
  }));
  try {
    await Attendance.insertMany(docs);
  } catch (e) {
    if (e.code === 11000) throw http(409, 'Duplicate attendance detected for this class');
    throw e;
  }
  await syncAlerts(subject._id, students.map((s) => s._id));

  const count = (st) => docs.filter((d) => d.status === st).length;
  res.status(201).json({
    message: 'Attendance saved',
    summary: { present: count('Present'), absent: count('Absent'), late: count('Late'), total: docs.length },
  });
});

exports.sessions = asyncHandler(async (req, res) => {
  const pg = pageParams(req, 15);
  const subjects = await scopedSubjects(req);
  const match = { subject: { $in: subjects.map((s) => s._id) } };
  if (req.query.from || req.query.to) {
    match.date = {};
    if (req.query.from) match.date.$gte = toDay(req.query.from);
    if (req.query.to) match.date.$lte = toDay(req.query.to);
  }
  const [out] = await Attendance.aggregate([
    { $match: match },
    { $group: { _id: { subject: '$subject', section: '$section', date: '$date', period: '$period' }, ...COUNTS, edits: { $sum: { $size: '$edits' } } } },
    { $sort: { '_id.date': -1, '_id.period': -1 } },
    { $facet: { data: [{ $skip: pg.skip }, { $limit: pg.limit }], total: [{ $count: 'n' }] } },
  ]);
  const byId = new Map(subjects.map((s) => [String(s._id), s]));
  const data = out.data.map((r) => {
    const s = byId.get(String(r._id.subject));
    return {
      subject: { _id: r._id.subject, name: s ? s.name : '', code: s ? s.code : '' },
      section: r._id.section, date: r._id.date, period: r._id.period,
      present: r.present, late: r.late, absent: r.absent, total: r.total, edited: r.edits > 0,
    };
  });
  res.json(pageResult(data, out.total[0] ? out.total[0].n : 0, pg));
});

exports.sessionDetail = asyncHandler(async (req, res) => {
  const { subject, section, date, period } = req.query;
  const sub = await ownSubject(req.faculty, subject);
  const recs = await Attendance.find({
    subject: sub._id, section: String(section).toUpperCase(), date: toDay(date), period: Number(period),
  }).populate({ path: 'student', select: 'rollNumber', populate: { path: 'user', select: 'name' } }).lean();
  recs.sort((a, b) => a.student.rollNumber.localeCompare(b.student.rollNumber));
  res.json({
    subject: { _id: sub._id, name: sub.name, code: sub.code }, section, date, period: Number(period),
    records: recs.map((r) => ({
      _id: r._id, status: r.status, editCount: r.edits.length,
      student: { name: r.student.user ? r.student.user.name : '', rollNumber: r.student.rollNumber },
    })),
  });
});

exports.correct = asyncHandler(async (req, res) => {
  const rec = await correctRecord({
    id: req.params.id, user: req.user, faculty: req.faculty, status: req.body.status, reason: req.body.reason,
  });
  res.json({ message: 'Attendance corrected', status: rec.status });
});

exports.students = asyncHandler(async (req, res) => {
  const settings = await getSettings();
  const subjects = await scopedSubjects(req);
  let rows = await reports.studentSubjectRows({ subjects, settings });
  if (req.query.q) {
    const q = String(req.query.q).toLowerCase();
    rows = rows.filter((r) => r.name.toLowerCase().includes(q) || r.rollNumber.toLowerCase().includes(q));
  }
  res.json({ settings: { minAttendance: settings.minAttendance }, rows });
});

const REPORTS = {
  async subject(req, settings) {
    const subjects = await scopedSubjects(req);
    return {
      rows: await reports.subjectRows(subjects, settings),
      columns: [
        { key: 'code', label: 'Code' }, { key: 'name', label: 'Subject' }, { key: 'sections', label: 'Sections' },
        { key: 'students', label: 'Students' }, { key: 'sessions', label: 'Classes conducted' },
        { key: 'averagePercentage', label: 'Average %' }, { key: 'belowMin', label: 'Students below minimum' },
      ],
    };
  },
  async shortage(req, settings) {
    const subjects = await scopedSubjects(req);
    const rows = (await reports.studentSubjectRows({ subjects, settings })).filter((r) => !r.eligible);
    return { rows, columns: STUDENT_COLUMNS };
  },
  async students(req, settings) {
    const subjects = await scopedSubjects(req);
    return { rows: await reports.studentSubjectRows({ subjects, settings }), columns: STUDENT_COLUMNS };
  },
  async daily(req) {
    const subjects = await scopedSubjects(req);
    return {
      rows: await reports.dailyRows(subjects, req.query.date || todayStr()),
      columns: [
        { key: 'code', label: 'Code' }, { key: 'subject', label: 'Subject' }, { key: 'section', label: 'Section' },
        { key: 'period', label: 'Period' }, { key: 'present', label: 'Present' }, { key: 'late', label: 'Late' },
        { key: 'absent', label: 'Absent' }, { key: 'total', label: 'Total' },
      ],
    };
  },
  async late(req) {
    const subjects = await scopedSubjects(req);
    const { rows, summary } = await reports.lateRows({
      subjectIds: subjects.map((s) => s._id), from: req.query.from, to: req.query.to,
    });
    return {
      rows, summary,
      columns: [
        { key: 'date', label: 'Date' }, { key: 'period', label: 'Period' }, { key: 'code', label: 'Code' },
        { key: 'subject', label: 'Subject' }, { key: 'section', label: 'Section' },
        { key: 'rollNumber', label: 'Roll number' }, { key: 'name', label: 'Student' },
      ],
    };
  },
};
const STUDENT_COLUMNS = [
  { key: 'rollNumber', label: 'Roll number' }, { key: 'name', label: 'Student' }, { key: 'section', label: 'Section' },
  { key: 'code', label: 'Code' }, { key: 'subject', label: 'Subject' }, { key: 'total', label: 'Total classes' },
  { key: 'attended', label: 'Attended' }, { key: 'percentage', label: 'Attendance %' },
  { key: 'classesNeeded', label: 'Classes needed' }, { key: 'safeMisses', label: 'Safe misses' },
];

exports.report = asyncHandler(async (req, res) => {
  const fn = REPORTS[req.params.type];
  if (!fn) throw http(404, 'Unknown report');
  const { columns, ...rest } = await fn(req, await getSettings());
  res.json(rest);
});

exports.exportReport = asyncHandler(async (req, res) => {
  const fn = REPORTS[req.params.type];
  if (!fn) throw http(404, 'Unknown report');
  const { rows, columns } = await fn(req, await getSettings());
  sendCsv(res, `${req.params.type}-report-${todayStr()}.csv`, columns, rows);
});

exports.announce = asyncHandler(async (req, res) => {
  const { subject: subjectId, title, message } = req.body;
  const subject = await ownSubject(req.faculty, subjectId);
  const section = req.body.section ? String(req.body.section).toUpperCase() : null;
  if (section && !subject.sections.includes(section)) throw http(400, 'Invalid section');
  const students = await studentsForSubject(subject, section);
  if (!students.length) throw http(400, 'No students to notify');
  await Notification.insertMany(students.map((s) => ({
    user: s.user._id, type: 'faculty_update', subject: subject._id,
    title: `${subject.code}: ${title}`, message: `${message}\n— ${req.faculty.user.name}`,
  })));
  res.status(201).json({ message: `Update sent to ${students.length} student${students.length > 1 ? 's' : ''}` });
});
