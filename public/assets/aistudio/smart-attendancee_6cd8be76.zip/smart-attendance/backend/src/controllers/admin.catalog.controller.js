const mongoose = require('mongoose');
const User = require('../models/User');
const Student = require('../models/Student');
const Faculty = require('../models/Faculty');
const Subject = require('../models/Subject');
const Attendance = require('../models/Attendance');
const Notification = require('../models/Notification');
const Enrollment = require('../models/Enrollment');
const asyncHandler = require('../utils/asyncHandler');
const http = require('../utils/httpError');
const { pageParams, pageResult } = require('../utils/paginate');

const clean = (s) => (typeof s === 'string' ? s.trim() : s);
const sections = (v) =>
  [...new Set((Array.isArray(v) ? v : String(v || '').split(',')).map((x) => String(x).trim().toUpperCase()).filter(Boolean))];

/* ---------- meta (dropdown values) ---------- */
exports.meta = asyncHandler(async (req, res) => {
  const [d1, d2, d3, sem, sec] = await Promise.all([
    Student.distinct('department'), Faculty.distinct('department'), Subject.distinct('department'),
    Student.distinct('semester'), Student.distinct('section'),
  ]);
  res.json({
    departments: [...new Set([...d1, ...d2, ...d3])].sort(),
    semesters: sem.sort((a, b) => a - b),
    sections: sec.sort(),
  });
});

/* ---------- students ---------- */
const studentDto = (s) => ({
  _id: s._id, name: s.user ? s.user.name : '', email: s.user ? s.user.email : '', rollNumber: s.rollNumber,
  department: s.department, semester: s.semester, section: s.section, isActive: s.isActive,
});

exports.listStudents = asyncHandler(async (req, res) => {
  const pg = pageParams(req, 15);
  const q = {};
  if (req.query.department) q.department = req.query.department;
  if (req.query.semester) q.semester = Number(req.query.semester);
  if (req.query.section) q.section = String(req.query.section).toUpperCase();
  if (req.query.status === 'active') q.isActive = true;
  if (req.query.status === 'inactive') q.isActive = false;
  let docs = await Student.find(q).populate('user', 'name email').sort({ rollNumber: 1 });
  if (req.query.q) {
    const s = String(req.query.q).toLowerCase();
    docs = docs.filter((d) => d.rollNumber.toLowerCase().includes(s) ||
      (d.user && (d.user.name.toLowerCase().includes(s) || d.user.email.includes(s))));
  }
  res.json(pageResult(docs.slice(pg.skip, pg.skip + pg.limit).map(studentDto), docs.length, pg));
});

exports.createStudent = asyncHandler(async (req, res) => {
  const { name, email, password, rollNumber, department, semester, section } = req.body;
  const user = await User.create({ name: clean(name), email, password, role: 'student' });
  try {
    const st = await Student.create({ user: user._id, rollNumber, department: clean(department), semester, section });
    await st.populate('user', 'name email');
    res.status(201).json(studentDto(st));
  } catch (e) {
    await User.deleteOne({ _id: user._id });
    throw e;
  }
});

exports.updateStudent = asyncHandler(async (req, res) => {
  const st = await Student.findById(req.params.id).populate('user');
  if (!st) throw http(404, 'Student not found');
  const { name, email, password, rollNumber, department, semester, section, isActive } = req.body;
  if (rollNumber !== undefined) st.rollNumber = rollNumber;
  if (department !== undefined) st.department = clean(department);
  if (semester !== undefined) st.semester = semester;
  if (section !== undefined) st.section = section;
  if (isActive !== undefined) { st.isActive = isActive; st.user.isActive = isActive; }
  if (name) st.user.name = clean(name);
  if (email) st.user.email = email;
  if (password) st.user.password = password;
  await st.user.save();
  await st.save();
  res.json(studentDto(st));
});

exports.deleteStudent = asyncHandler(async (req, res) => {
  const st = await Student.findById(req.params.id);
  if (!st) throw http(404, 'Student not found');
  if (req.query.permanent === 'true') {
    await Promise.all([
      Attendance.deleteMany({ student: st._id }), Enrollment.deleteMany({ student: st._id }), Notification.deleteMany({ user: st.user }),
      User.deleteOne({ _id: st.user }), st.deleteOne(),
    ]);
    return res.json({ message: 'Student and all related records deleted' });
  }
  st.isActive = false;
  await Promise.all([st.save(), User.updateOne({ _id: st.user }, { isActive: false })]);
  res.json({ message: 'Student deactivated' });
});

/* ---------- faculty ---------- */
async function facultyDto(f, subjects) {
  return {
    _id: f._id, name: f.user ? f.user.name : '', email: f.user ? f.user.email : '', employeeId: f.employeeId,
    department: f.department, designation: f.designation, isActive: f.isActive,
    subjects: (subjects || []).map((s) => ({ _id: s._id, code: s.code, name: s.name, sections: s.sections })),
  };
}

exports.listFaculty = asyncHandler(async (req, res) => {
  const [docs, subjects] = await Promise.all([
    Faculty.find().populate('user', 'name email').sort({ employeeId: 1 }),
    Subject.find({ faculty: { $ne: null }, isActive: true }).select('code name sections faculty'),
  ]);
  res.json(await Promise.all(docs.map((f) => facultyDto(f, subjects.filter((s) => String(s.faculty) === String(f._id))))));
});

async function assignSubjects(facultyId, ids) {
  if (!Array.isArray(ids)) return;
  const valid = ids.filter((i) => mongoose.isValidObjectId(i));
  await Subject.updateMany({ faculty: facultyId, _id: { $nin: valid } }, { $unset: { faculty: 1 } });
  await Subject.updateMany({ _id: { $in: valid } }, { faculty: facultyId });
}

exports.createFaculty = asyncHandler(async (req, res) => {
  const { name, email, password, employeeId, department, designation, subjects } = req.body;
  const user = await User.create({ name: clean(name), email, password, role: 'faculty' });
  try {
    const f = await Faculty.create({ user: user._id, employeeId, department: clean(department), designation: clean(designation) || undefined });
    await assignSubjects(f._id, subjects);
    await f.populate('user', 'name email');
    res.status(201).json(await facultyDto(f, await Subject.find({ faculty: f._id })));
  } catch (e) {
    await User.deleteOne({ _id: user._id });
    throw e;
  }
});

exports.updateFaculty = asyncHandler(async (req, res) => {
  const f = await Faculty.findById(req.params.id).populate('user');
  if (!f) throw http(404, 'Faculty not found');
  const { name, email, password, employeeId, department, designation, isActive, subjects } = req.body;
  if (employeeId !== undefined) f.employeeId = employeeId;
  if (department !== undefined) f.department = clean(department);
  if (designation !== undefined) f.designation = clean(designation);
  if (isActive !== undefined) { f.isActive = isActive; f.user.isActive = isActive; }
  if (name) f.user.name = clean(name);
  if (email) f.user.email = email;
  if (password) f.user.password = password;
  await f.user.save();
  await f.save();
  await assignSubjects(f._id, subjects);
  res.json(await facultyDto(f, await Subject.find({ faculty: f._id })));
});

exports.deleteFaculty = asyncHandler(async (req, res) => {
  const f = await Faculty.findById(req.params.id);
  if (!f) throw http(404, 'Faculty not found');
  if (req.query.permanent === 'true') {
    if (await Subject.exists({ faculty: f._id })) throw http(409, 'Unassign this faculty member from all subjects first');
    if (await Attendance.exists({ faculty: f._id })) throw http(409, 'This faculty member has attendance history. Deactivate instead.');
    await Promise.all([User.deleteOne({ _id: f.user }), f.deleteOne()]);
    return res.json({ message: 'Faculty deleted' });
  }
  f.isActive = false;
  await Promise.all([f.save(), User.updateOne({ _id: f.user }, { isActive: false })]);
  res.json({ message: 'Faculty deactivated' });
});

/* ---------- subjects ---------- */
const subjectDto = (s) => ({
  _id: s._id, name: s.name, code: s.code, department: s.department, semester: s.semester, sections: s.sections,
  credits: s.credits, isActive: s.isActive,
  faculty: s.faculty ? { _id: s.faculty._id, name: s.faculty.user ? s.faculty.user.name : '', employeeId: s.faculty.employeeId } : null,
});
const withFaculty = (q) => q.populate({ path: 'faculty', select: 'employeeId user', populate: { path: 'user', select: 'name' } });

async function checkFaculty(id) {
  if (id && !(await Faculty.exists({ _id: id, isActive: true }))) throw http(400, 'Selected faculty member does not exist or is inactive');
}

exports.listSubjects = asyncHandler(async (req, res) => {
  const docs = await withFaculty(Subject.find().sort({ code: 1 }));
  res.json(docs.map(subjectDto));
});

exports.createSubject = asyncHandler(async (req, res) => {
  const { name, code, department, semester, credits, faculty } = req.body;
  await checkFaculty(faculty);
  const s = await Subject.create({
    name: clean(name), code, department: clean(department), semester, credits,
    sections: sections(req.body.sections), faculty: faculty || undefined,
  });
  res.status(201).json(subjectDto(await withFaculty(Subject.findById(s._id))));
});

exports.updateSubject = asyncHandler(async (req, res) => {
  const s = await Subject.findById(req.params.id);
  if (!s) throw http(404, 'Subject not found');
  const b = req.body;
  if (b.faculty !== undefined) await checkFaculty(b.faculty);
  ['name', 'department'].forEach((k) => b[k] !== undefined && (s[k] = clean(b[k])));
  ['code', 'semester', 'credits', 'isActive'].forEach((k) => b[k] !== undefined && (s[k] = b[k]));
  if (b.sections !== undefined) s.sections = sections(b.sections);
  if (b.faculty !== undefined) s.faculty = b.faculty || undefined;
  await s.save();
  res.json(subjectDto(await withFaculty(Subject.findById(s._id))));
});

exports.deleteSubject = asyncHandler(async (req, res) => {
  const s = await Subject.findById(req.params.id);
  if (!s) throw http(404, 'Subject not found');
  if (req.query.permanent === 'true') {
    if (await Attendance.exists({ subject: s._id })) throw http(409, 'This subject has attendance records. Deactivate it instead.');
    await Enrollment.deleteMany({ subject: s._id });
    await s.deleteOne();
    return res.json({ message: 'Subject deleted' });
  }
  s.isActive = false;
  await s.save();
  res.json({ message: 'Subject deactivated' });
});
