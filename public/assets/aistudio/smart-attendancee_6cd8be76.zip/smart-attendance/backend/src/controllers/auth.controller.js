const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Student = require('../models/Student');
const Faculty = require('../models/Faculty');
const asyncHandler = require('../utils/asyncHandler');

const sign = (user) =>
  jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '1d',
  });

async function loadProfile(user) {
  if (user.role === 'student') return Student.findOne({ user: user._id });
  if (user.role === 'faculty') return Faculty.findOne({ user: user._id });
  return null;
}

const publicUser = (u) => ({ id: u._id, name: u.name, email: u.email, role: u.role });

// Students sign in with email OR roll number; faculty with email OR employee ID; admins with email.
async function findLoginUser(identifier, role) {
  if (identifier.includes('@')) return User.findOne({ email: identifier.toLowerCase() }).select('+password');
  if (role === 'student') {
    const s = await Student.findOne({ rollNumber: identifier.toUpperCase() });
    return s ? User.findById(s.user).select('+password') : null;
  }
  if (role === 'faculty') {
    const f = await Faculty.findOne({ employeeId: identifier.toUpperCase() });
    return f ? User.findById(f.user).select('+password') : null;
  }
  return null;
}

exports.login = asyncHandler(async (req, res) => {
  const { password, role } = req.body;
  const identifier = String(req.body.identifier || req.body.email || '').trim();
  const user = await findLoginUser(identifier, role);

  // One generic message for every failure, so account existence is not revealed
  const fail = () => res.status(401).json({ message: 'Invalid login details, password or role' });
  if (!user || user.role !== role || !(await user.matchPassword(password))) return fail();
  if (!user.isActive) return res.status(403).json({ message: 'Your account has been deactivated. Contact the administrator.' });

  user.lastLogin = new Date();
  await user.save({ validateModifiedOnly: true });

  res.json({ token: sign(user), user: publicUser(user), profile: await loadProfile(user) });
});

exports.me = asyncHandler(async (req, res) => {
  res.json({ user: publicUser(req.user), profile: await loadProfile(req.user) });
});

exports.changePassword = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).select('+password');
  if (!(await user.matchPassword(req.body.currentPassword)))
    return res.status(400).json({ message: 'Current password is incorrect' });
  user.password = req.body.newPassword;
  await user.save();
  res.json({ message: 'Password updated' });
});

// Logout is client-side with JWT (discard the token); endpoint exists for a uniform API.
exports.logout = (req, res) => res.json({ message: 'Logged out' });
