const User = require('../models/User');
const Student = require('../models/Student');
const Faculty = require('../models/Faculty');
const Subject = require('../models/Subject');
const AcademicSession = require('../models/AcademicSession');
const asyncHandler = require('../utils/asyncHandler');
const http = require('../utils/httpError');
const { pageParams, pageResult, escapeRegex } = require('../utils/paginate');
const { getSettings, studentsForSubject, syncAlerts } = require('../utils/stats');

exports.getSettings = asyncHandler(async (req, res) => {
  const s = await getSettings();
  res.json({ minAttendance: s.minAttendance, lateCountsAsPresent: s.lateCountsAsPresent, session: s.session });
});

exports.updateSettings = asyncHandler(async (req, res) => {
  let session = await AcademicSession.findOne({ isActive: true });
  if (!session) {
    session = new AcademicSession({
      name: 'Default Session', startDate: new Date(), endDate: new Date(Date.now() + 365 * 86400000), isActive: true,
    });
  }
  if (req.body.minAttendance !== undefined) session.minAttendance = req.body.minAttendance;
  if (req.body.lateCountsAsPresent !== undefined) session.lateCountsAsPresent = req.body.lateCountsAsPresent;
  await session.save();
  res.json({ message: 'Settings saved', minAttendance: session.minAttendance, lateCountsAsPresent: session.lateCountsAsPresent });
});

/* ---------- academic sessions ---------- */
exports.listSessions = asyncHandler(async (req, res) => res.json(await AcademicSession.find().sort({ startDate: -1 })));

exports.createSession = asyncHandler(async (req, res) => {
  const { name, startDate, endDate, minAttendance, lateCountsAsPresent } = req.body;
  if (new Date(endDate) <= new Date(startDate)) throw http(400, 'End date must be after the start date');
  res.status(201).json(await AcademicSession.create({ name, startDate, endDate, minAttendance, lateCountsAsPresent }));
});

exports.updateSession = asyncHandler(async (req, res) => {
  const s = await AcademicSession.findById(req.params.id);
  if (!s) throw http(404, 'Session not found');
  ['name', 'startDate', 'endDate', 'minAttendance', 'lateCountsAsPresent'].forEach((k) => req.body[k] !== undefined && (s[k] = req.body[k]));
  if (s.endDate <= s.startDate) throw http(400, 'End date must be after the start date');
  await s.save();
  res.json(s);
});

exports.activateSession = asyncHandler(async (req, res) => {
  const s = await AcademicSession.findById(req.params.id);
  if (!s) throw http(404, 'Session not found');
  s.isActive = true;
  await s.save();
  res.json({ message: `${s.name} is now the active session` });
});

exports.deleteSession = asyncHandler(async (req, res) => {
  const s = await AcademicSession.findById(req.params.id);
  if (!s) throw http(404, 'Session not found');
  if (s.isActive) throw http(409, 'The active session cannot be deleted');
  await s.deleteOne();
  res.json({ message: 'Session deleted' });
});

/* ---------- users & roles ---------- */
exports.listUsers = asyncHandler(async (req, res) => {
  const pg = pageParams(req, 15);
  const q = {};
  if (req.query.role) q.role = req.query.role;
  if (req.query.q) {
    const rx = new RegExp(escapeRegex(req.query.q), 'i');
    q.$or = [{ name: rx }, { email: rx }];
  }
  const [data, total] = await Promise.all([
    User.find(q).sort({ role: 1, name: 1 }).skip(pg.skip).limit(pg.limit).select('name email role isActive lastLogin').lean(),
    User.countDocuments(q),
  ]);
  res.json(pageResult(data, total, pg));
});

exports.updateUser = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) throw http(404, 'User not found');
  if (req.body.isActive === false && String(user._id) === String(req.user._id))
    throw http(400, 'You cannot deactivate your own account');
  if (req.body.isActive !== undefined) {
    user.isActive = req.body.isActive;
    await Promise.all([
      Student.updateOne({ user: user._id }, { isActive: req.body.isActive }),
      Faculty.updateOne({ user: user._id }, { isActive: req.body.isActive }),
    ]);
  }
  if (req.body.password) user.password = req.body.password;
  await user.save();
  res.json({ message: 'User updated' });
});

exports.createAdmin = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;
  const u = await User.create({ name, email, password, role: 'admin' });
  res.status(201).json({ _id: u._id, name: u.name, email: u.email, role: u.role });
});

/* ---------- alerts ---------- */
exports.resyncAlerts = asyncHandler(async (req, res) => {
  const settings = await getSettings();
  const subjects = await Subject.find({ isActive: true });
  for (const s of subjects) {
    const students = await studentsForSubject(s);
    await syncAlerts(s._id, students.map((st) => st._id), settings);
  }
  res.json({ message: `Alerts refreshed for ${subjects.length} subjects` });
});
