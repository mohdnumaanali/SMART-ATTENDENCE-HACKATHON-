const Student = require('../models/Student');
const Subject = require('../models/Subject');
const Enrollment = require('../models/Enrollment');
const asyncHandler = require('../utils/asyncHandler');
const http = require('../utils/httpError');
const { studentsForSubject } = require('../utils/stats');

// Everyone in a subject: the class (automatic) plus manually enrolled students
exports.list = asyncHandler(async (req, res) => {
  const subject = await Subject.findById(req.query.subject);
  if (!subject) throw http(404, 'Subject not found');
  const [students, manual] = await Promise.all([
    studentsForSubject(subject),
    Enrollment.find({ subject: subject._id }).lean(),
  ]);
  const byStudent = new Map(manual.map((e) => [String(e.student), e._id]));
  res.json({
    subject: { _id: subject._id, name: subject.name, code: subject.code, department: subject.department, semester: subject.semester, sections: subject.sections },
    rows: students.map((s) => ({
      _id: s._id, name: s.user ? s.user.name : '', rollNumber: s.rollNumber, department: s.department,
      semester: s.semester, section: s.section,
      source: byStudent.has(String(s._id)) ? 'manual' : 'class',
      enrollmentId: byStudent.get(String(s._id)) || null,
    })),
  });
});

exports.create = asyncHandler(async (req, res) => {
  const [student, subject] = await Promise.all([Student.findById(req.body.student), Subject.findById(req.body.subject)]);
  if (!student || !student.isActive) throw http(404, 'Student not found or inactive');
  if (!subject || !subject.isActive) throw http(404, 'Subject not found or inactive');
  if (!subject.sections.includes(student.section))
    throw http(400, `Section ${student.section} is not part of ${subject.code}. Add that section to the subject first.`);
  if (student.department === subject.department && student.semester === subject.semester)
    throw http(409, 'This student is already in the class for this subject (same department, semester and section).');
  try {
    await Enrollment.create({ student: student._id, subject: subject._id, enrolledBy: req.user._id });
  } catch (e) {
    if (e.code === 11000) throw http(409, 'Student is already enrolled in this subject');
    throw e;
  }
  res.status(201).json({ message: `${student.rollNumber} enrolled in ${subject.code}` });
});

exports.remove = asyncHandler(async (req, res) => {
  const e = await Enrollment.findByIdAndDelete(req.params.id);
  if (!e) throw http(404, 'Enrollment not found');
  res.json({ message: 'Student removed from subject. Existing attendance records are kept.' });
});
