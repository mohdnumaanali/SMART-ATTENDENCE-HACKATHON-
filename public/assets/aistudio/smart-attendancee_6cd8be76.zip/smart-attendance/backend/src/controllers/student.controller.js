const Attendance = require('../models/Attendance');
const Subject = require('../models/Subject');
const Enrollment = require('../models/Enrollment');
const asyncHandler = require('../utils/asyncHandler');
const { toDay } = require('../utils/dates');
const { sendCsv } = require('../utils/csv');
const { pageParams, pageResult } = require('../utils/paginate');
const { oid, getSettings, perStudentSubject, withAnalysis, monthlyTrend } = require('../utils/stats');
const { STATUSES } = require('../services/attendanceService');

const facultyName = (f) => (f && f.user ? f.user.name : '');

async function buildSummary(st) {
  const settings = await getSettings();
  const stats = await perStudentSubject({ student: st._id });
  const enrolled = await Enrollment.distinct('subject', { student: st._id });
  const subjects = await Subject.find({
    $or: [
      { isActive: true, department: st.department, semester: st.semester, sections: st.section },
      { isActive: true, _id: { $in: enrolled } },
      { _id: { $in: stats.map((s) => s.subject) } },
    ],
  }).populate({ path: 'faculty', populate: { path: 'user', select: 'name' } }).sort({ code: 1 });

  const map = new Map(stats.map((s) => [String(s.subject), s]));
  const empty = { present: 0, late: 0, absent: 0, total: 0 };
  const rows = subjects.map((s) => ({
    subjectId: s._id, name: s.name, code: s.code, faculty: facultyName(s.faculty),
    ...withAnalysis(map.get(String(s._id)) || empty, settings),
  }));
  const sum = stats.reduce(
    (n, s) => ({ present: n.present + s.present, late: n.late + s.late, absent: n.absent + s.absent, total: n.total + s.total }),
    { ...empty }
  );
  return {
    settings: { minAttendance: settings.minAttendance, lateCountsAsPresent: settings.lateCountsAsPresent },
    overall: withAnalysis(sum, settings),
    subjects: rows,
    trend: await monthlyTrend({ student: st._id }, settings),
  };
}

exports.summary = asyncHandler(async (req, res) => {
  res.json(await buildSummary(req.student));
});

exports.history = asyncHandler(async (req, res) => {
  const pg = pageParams(req, 15);
  const { subject, status, from, to } = req.query;
  const q = { student: req.student._id };
  if (subject) q.subject = oid(subject);
  if (status && STATUSES.includes(status)) q.status = status;
  if (from || to) {
    q.date = {};
    if (from) q.date.$gte = toDay(from);
    if (to) q.date.$lte = toDay(to);
  }
  const [recs, total] = await Promise.all([
    Attendance.find(q).sort({ date: -1, period: -1 }).skip(pg.skip).limit(pg.limit)
      .populate('subject', 'name code')
      .populate({ path: 'faculty', populate: { path: 'user', select: 'name' } }).lean(),
    Attendance.countDocuments(q),
  ]);
  const data = recs.map((r) => ({
    _id: r._id, date: r.date, period: r.period, status: r.status,
    subject: r.subject, faculty: facultyName(r.faculty),
  }));
  res.json(pageResult(data, total, pg));
});

exports.profile = asyncHandler(async (req, res) => {
  const s = req.student;
  res.json({
    name: s.user.name, email: s.user.email, rollNumber: s.rollNumber,
    department: s.department, semester: s.semester, section: s.section,
  });
});

// CSV download: ?type=summary (default, subject-wise) or ?type=history (every class)
exports.exportReport = asyncHandler(async (req, res) => {
  const st = req.student;
  if (req.query.type === 'history') {
    const recs = await Attendance.find({ student: st._id }).sort({ date: -1, period: -1 }).limit(5000)
      .populate('subject', 'name code')
      .populate({ path: 'faculty', populate: { path: 'user', select: 'name' } }).lean();
    const rows = recs.map((r) => ({
      date: r.date.toISOString().slice(0, 10), period: r.period, code: r.subject ? r.subject.code : '',
      subject: r.subject ? r.subject.name : '', faculty: facultyName(r.faculty), status: r.status,
    }));
    return sendCsv(res, `attendance-history-${st.rollNumber}.csv`, [
      { key: 'date', label: 'Date' }, { key: 'period', label: 'Period' }, { key: 'code', label: 'Code' },
      { key: 'subject', label: 'Subject' }, { key: 'faculty', label: 'Faculty' }, { key: 'status', label: 'Status' },
    ], rows);
  }
  const { subjects, overall } = await buildSummary(st);
  const label = (r) => (r.total === 0 ? 'No classes' : r.eligible ? 'Eligible' : 'Shortage');
  const rows = [...subjects, { ...overall, code: 'ALL', name: 'Overall', faculty: '' }].map((r) => ({
    code: r.code, subject: r.name, faculty: r.faculty, total: r.total, present: r.present, late: r.late,
    absent: r.absent, attended: r.attended, percentage: r.currentPercentage, required: r.requiredPercentage,
    status: label(r), needed: r.classesNeeded === null ? 'n/a' : r.classesNeeded, safe: r.safeMisses,
  }));
  sendCsv(res, `attendance-summary-${st.rollNumber}.csv`, [
    { key: 'code', label: 'Code' }, { key: 'subject', label: 'Subject' }, { key: 'faculty', label: 'Faculty' },
    { key: 'total', label: 'Total classes' }, { key: 'present', label: 'Present' }, { key: 'late', label: 'Late' },
    { key: 'absent', label: 'Absent' }, { key: 'attended', label: 'Attended' }, { key: 'percentage', label: 'Attendance %' },
    { key: 'required', label: 'Required %' }, { key: 'status', label: 'Status' },
    { key: 'needed', label: 'Classes needed' }, { key: 'safe', label: 'Safe misses' },
  ], rows);
});
