const Notification = require('../models/Notification');
const asyncHandler = require('../utils/asyncHandler');
const { pageParams, pageResult } = require('../utils/paginate');

exports.list = asyncHandler(async (req, res) => {
  const pg = pageParams(req, 20);
  const q = { user: req.user._id };
  if (req.query.unread === 'true') q.isRead = false;
  const [data, total, unread] = await Promise.all([
    Notification.find(q).sort({ createdAt: -1 }).skip(pg.skip).limit(pg.limit).lean(),
    Notification.countDocuments(q),
    Notification.countDocuments({ user: req.user._id, isRead: false }),
  ]);
  res.json({ ...pageResult(data, total, pg), unread });
});

exports.count = asyncHandler(async (req, res) => {
  res.json({ unread: await Notification.countDocuments({ user: req.user._id, isRead: false }) });
});

exports.markRead = asyncHandler(async (req, res) => {
  await Notification.updateOne({ _id: req.params.id, user: req.user._id }, { isRead: true });
  res.json({ message: 'Marked as read' });
});

exports.markAllRead = asyncHandler(async (req, res) => {
  await Notification.updateMany({ user: req.user._id, isRead: false }, { isRead: true });
  res.json({ message: 'All notifications marked as read' });
});
