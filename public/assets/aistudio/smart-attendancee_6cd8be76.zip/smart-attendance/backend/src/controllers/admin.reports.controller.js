const Attendance = require('../models/Attendance');
const Student = require('../models/Student');
const Faculty = require('../models/Faculty');
const Subject = require('../models/Subject');
const asyncHandler = require('../utils/asyncHandler');
const http = require('../utils/httpError');
const { toDay } = require('../utils/dates');
const { sendCsv } = require('../utils/csv');
const { getSettings, attendedOf, COUNTS, monthlyTrend } = require('../utils/stats');
const { correctRecord } = require('../services/attendanceService');
const reports = require('../services/reportService');

const todayStr = () => new Date().toISOString().slice(0, 10);
const pct = (c, settings) => (c.total ? +((attendedOf(c, settings) / c.total) * 100).toFixed(1) : 0);

exports.overview = asyncHandler(async (req, res) => {
  const settings = await getSettings();
  const date = toDay(req.query.date || todayStr());
  const [students, faculty, subjects, totals, sessions, today] = await Promise.all([
    Student.countDocuments({ isActive: true }), Faculty.countDocuments({ isActive: true }),
    Subject.countDocuments({ isActive: true }),
    Attendance.aggregate([{ $group: { _id: null, ...COUNTS } }]),
    Attendance.aggregate([
      { $group: { _id: { subject: '$subject', section: '$section', date: '$date', period: '$period' } } },
      { $count: 'n' },
    ]),
    Attendance.aggregate([{ $match: { date } }, { $group: { _id: null, ...COUNTS } }]),
  ]);
  const t = totals[0] || { present: 0, late: 0, absent: 0, total: 0 };
  const d = today[0] || { present: 0, late: 0, absent: 0, total: 0 };
  res.json({
    students, faculty, subjects, classes: sessions[0] ? sessions[0].n : 0,
    overallPercentage: pct(t, settings), minAttendance: settings.minAttendance,
    status: { present: t.present, late: t.late, absent: t.absent },
    today: { present: d.present, late: d.late, absent: d.absent, total: d.total, percentage: pct(d, settings) },
  });
});

/* ---------- monitoring ---------- */
const SHORTAGE_COLUMNS = [
  { key: 'department', label: 'Department' }, { key: 'semester', label: 'Semester' }, { key: 'section', label: 'Section' },
  { key: 'rollNumber', label: 'Roll number' }, { key: 'name', label: 'Student' }, { key: 'code', label: 'Code' },
  { key: 'subject', label: 'Subject' }, { key: 'faculty', label: 'Faculty' }, { key: 'total', label: 'Total classes' },
  { key: 'attended', label: 'Attended' }, { key: 'percentage', label: 'Attendance %' },
  { key: 'classesNeeded', label: 'Classes needed' },
];

async function shortageRows(req) {
  const settings = await getSettings();
  const { department, semester, subject } = req.query;
  const filter = {};
  if (department) filter.department = department;
  if (semester) filter.semester = Number(semester);
  if (subject) filter._id = subject;
  const subjects = await reports.populatedSubjects(filter);
  const rows = await reports.studentSubjectRows({ subjects, settings });
  return { settings, rows: rows.filter((r) => !r.eligible) };
}

exports.shortage = asyncHandler(async (req, res) => {
  const { settings, rows } = await shortageRows(req);
  res.json({ settings: { minAttendance: settings.minAttendance }, rows });
});

exports.shortageExport = asyncHandler(async (req, res) => {
  const { rows } = await shortageRows(req);
  sendCsv(res, `attendance-shortage-${todayStr()}.csv`, SHORTAGE_COLUMNS, rows);
});

exports.late = asyncHandler(async (req, res) => {
  const subjects = await reports.populatedSubjects();
  res.json(await reports.lateRows({
    subjectIds: subjects.map((s) => s._id), from: req.query.from, to: req.query.to, department: req.query.department,
  }));
});

exports.daily = asyncHandler(async (req, res) => {
  const subjects = await reports.populatedSubjects();
  res.json({ rows: await reports.dailyRows(subjects, req.query.date || todayStr()) });
});

exports.correct = asyncHandler(async (req, res) => {
  const rec = await correctRecord({ id: req.params.id, user: req.user, status: req.body.status, reason: req.body.reason });
  res.json({ message: 'Attendance corrected', status: rec.status });
});

/* ---------- analytics ---------- */
exports.analytics = asyncHandler(async (req, res) => {
  const settings = await getSettings();
  const stLookup = [
    { $lookup: { from: Student.collection.name, localField: 'student', foreignField: '_id', as: 'st' } },
    { $unwind: '$st' },
  ];
  const grouped = (key) => Attendance.aggregate([...stLookup, { $group: { _id: key, ...COUNTS } }, { $sort: { _id: 1 } }]);

  const [dept, sem, subj, monthly, status] = await Promise.all([
    grouped('$st.department'), grouped('$st.semester'),
    Attendance.aggregate([{ $group: { _id: '$subject', ...COUNTS } }]),
    monthlyTrend({}, settings),
    Attendance.aggregate([{ $group: { _id: null, ...COUNTS } }]),
  ]);
  const subjects = await reports.populatedSubjects();
  const names = new Map(subjects.map((s) => [String(s._id), s]));

  const rows = await reports.studentSubjectRows({ subjects, settings });
  const deptStudents = await Student.aggregate([{ $match: { isActive: true } }, { $group: { _id: '$department', n: { $sum: 1 } } }]);
  const below = new Map();
  rows.filter((r) => !r.eligible).forEach((r) => {
    if (!below.has(r.department)) below.set(r.department, new Set());
    below.get(r.department).add(String(r.studentId));
  });
  const belowSubjects = {};
  rows.filter((r) => !r.eligible).forEach((r) => { belowSubjects[r.code] = (belowSubjects[r.code] || 0) + 1; });

  const s = status[0] || { present: 0, late: 0, absent: 0 };
  res.json({
    minAttendance: settings.minAttendance,
    status: { present: s.present, late: s.late, absent: s.absent },
    byDepartment: dept.map((r) => ({ label: r._id, total: r.total, percentage: pct(r, settings) })),
    bySemester: sem.map((r) => ({ label: `Semester ${r._id}`, total: r.total, percentage: pct(r, settings) })),
    bySubject: subj
      .map((r) => {
        const sub = names.get(String(r._id));
        return { label: sub ? sub.code : 'Removed', name: sub ? sub.name : '', total: r.total, percentage: pct(r, settings) };
      })
      .sort((a, b) => a.label.localeCompare(b.label)),
    monthly,
    shortage: {
      byDepartment: deptStudents
        .map((d) => ({ label: d._id, students: d.n, below: below.has(d._id) ? below.get(d._id).size : 0 }))
        .sort((a, b) => a.label.localeCompare(b.label)),
      bySubject: Object.entries(belowSubjects).map(([label, count]) => ({ label, count })).sort((a, b) => a.label.localeCompare(b.label)),
    },
  });
});
