const Attendance = require('../models/Attendance');
const Student = require('../models/Student');
const Subject = require('../models/Subject');
const Enrollment = require('../models/Enrollment');
const { oid, COUNTS, perStudentSubject, withAnalysis, attendedOf } = require('../utils/stats');
const { toDay } = require('../utils/dates');

const populatedSubjects = (filter = {}) =>
  Subject.find({ isActive: true, ...filter }).populate({ path: 'faculty', populate: { path: 'user', select: 'name' } }).sort({ code: 1 });

// One row per (student, subject) with full eligibility analysis
async function studentSubjectRows({ subjects, settings, studentMatch = {} }) {
  if (!subjects.length) return [];
  const enrollments = await Enrollment.find({ subject: { $in: subjects.map((s) => s._id) } }).select('student subject').lean();
  const enrolledBy = new Map();
  enrollments.forEach((e) => {
    const k = String(e.subject);
    if (!enrolledBy.has(k)) enrolledBy.set(k, new Set());
    enrolledBy.get(k).add(String(e.student));
  });
  const enrolledIds = [...new Set(enrollments.map((e) => e.student))];

  const students = await Student.find({
    isActive: true,
    ...studentMatch,
    $or: [
      ...subjects.map((s) => ({ department: s.department, semester: s.semester, section: { $in: s.sections } })),
      ...(enrolledIds.length ? [{ _id: { $in: enrolledIds } }] : []),
    ],
  }).populate('user', 'name');

  const stats = await perStudentSubject({ subject: { $in: subjects.map((s) => s._id) } });
  const map = new Map(stats.map((r) => [`${r.student}_${r.subject}`, r]));

  const rows = [];
  for (const sub of subjects) {
    for (const st of students) {
      const inClass = st.department === sub.department && st.semester === sub.semester && sub.sections.includes(st.section);
      const enrolled = sub.sections.includes(st.section) && enrolledBy.has(String(sub._id)) && enrolledBy.get(String(sub._id)).has(String(st._id));
      if (!inClass && !enrolled) continue;
      const c = map.get(`${st._id}_${sub._id}`) || { present: 0, late: 0, absent: 0, total: 0 };
      const a = withAnalysis(c, settings);
      rows.push({
        studentId: st._id, name: st.user ? st.user.name : '', rollNumber: st.rollNumber,
        department: st.department, semester: st.semester, section: st.section,
        subjectId: sub._id, subject: sub.name, code: sub.code,
        faculty: sub.faculty && sub.faculty.user ? sub.faculty.user.name : '',
        ...a, percentage: a.currentPercentage,
      });
    }
  }
  return rows.sort((x, y) => x.code.localeCompare(y.code) || x.rollNumber.localeCompare(y.rollNumber));
}

async function subjectRows(subjects, settings) {
  const rows = await studentSubjectRows({ subjects, settings });
  const sessions = await Attendance.aggregate([
    { $match: { subject: { $in: subjects.map((s) => s._id) } } },
    { $group: { _id: { subject: '$subject', section: '$section', date: '$date', period: '$period' } } },
    { $group: { _id: '$_id.subject', n: { $sum: 1 } } },
  ]);
  const sessionMap = new Map(sessions.map((s) => [String(s._id), s.n]));
  return subjects.map((s) => {
    const mine = rows.filter((r) => String(r.subjectId) === String(s._id));
    const att = mine.reduce((n, r) => n + r.attended, 0);
    const tot = mine.reduce((n, r) => n + r.total, 0);
    return {
      subjectId: s._id, name: s.name, code: s.code, sections: s.sections.join(', '),
      faculty: s.faculty && s.faculty.user ? s.faculty.user.name : '',
      students: mine.length, sessions: sessionMap.get(String(s._id)) || 0,
      averagePercentage: tot ? +((att / tot) * 100).toFixed(1) : 0,
      belowMin: mine.filter((r) => !r.eligible).length,
    };
  });
}

async function dailyRows(subjects, date) {
  const raw = await Attendance.aggregate([
    { $match: { subject: { $in: subjects.map((s) => s._id) }, date: toDay(date) } },
    { $group: { _id: { subject: '$subject', section: '$section', period: '$period' }, ...COUNTS } },
    { $sort: { '_id.period': 1 } },
  ]);
  const byId = new Map(subjects.map((s) => [String(s._id), s]));
  return raw.map((r) => {
    const s = byId.get(String(r._id.subject));
    return {
      subject: s ? s.name : '', code: s ? s.code : '', section: r._id.section, period: r._id.period,
      present: r.present, late: r.late, absent: r.absent, total: r.total,
    };
  });
}

async function lateRows({ subjectIds, from, to, department, limit = 500 }) {
  const q = { status: 'Late', subject: { $in: subjectIds } };
  if (from || to) {
    q.date = {};
    if (from) q.date.$gte = toDay(from);
    if (to) q.date.$lte = toDay(to);
  }
  const recs = await Attendance.find(q)
    .sort({ date: -1, period: -1 }).limit(limit)
    .populate({ path: 'student', select: 'rollNumber department', populate: { path: 'user', select: 'name' } })
    .populate('subject', 'name code')
    .lean();
  const rows = recs
    .filter((r) => r.student && (!department || r.student.department === department))
    .map((r) => ({
      date: r.date.toISOString().slice(0, 10), period: r.period, section: r.section,
      subject: r.subject ? r.subject.name : '', code: r.subject ? r.subject.code : '',
      name: r.student.user ? r.student.user.name : '', rollNumber: r.student.rollNumber,
      department: r.student.department,
    }));
  const counts = new Map();
  rows.forEach((r) => {
    const k = r.rollNumber;
    counts.set(k, { name: r.name, rollNumber: k, count: (counts.get(k)?.count || 0) + 1 });
  });
  return { rows, summary: [...counts.values()].sort((a, b) => b.count - a.count) };
}

module.exports = { populatedSubjects, studentSubjectRows, subjectRows, dailyRows, lateRows, attendedOf, oid };
