const Attendance = require('../models/Attendance');
const Subject = require('../models/Subject');
const http = require('../utils/httpError');
const { syncAlerts } = require('../utils/stats');

const WINDOW_DAYS = parseInt(process.env.CORRECTION_WINDOW_DAYS, 10) || 7;
const STATUSES = ['Present', 'Absent', 'Late'];

// Faculty may correct only their own subjects, within a time window, with a reason.
// Admins may correct any record at any time.
async function correctRecord({ id, user, faculty, status, reason }) {
  if (!STATUSES.includes(status)) throw http(400, 'Status must be Present, Absent or Late');
  if (!reason || reason.trim().length < 3) throw http(400, 'A reason is required for every correction');

  const rec = await Attendance.findById(id);
  if (!rec) throw http(404, 'Attendance record not found');

  if (user.role === 'faculty') {
    const owns = await Subject.exists({ _id: rec.subject, faculty: faculty._id });
    if (!owns) throw http(403, 'You can only correct attendance for your own subjects');
    const ageDays = (Date.now() - rec.date.getTime()) / 86400000;
    if (ageDays > WINDOW_DAYS) throw http(403, `Records older than ${WINDOW_DAYS} days can only be corrected by an administrator`);
  }
  if (rec.status === status) throw http(400, 'Status is unchanged');

  rec.edits.push({ by: user._id, from: rec.status, to: status, reason: reason.trim() });
  rec.status = status;
  await rec.save();
  await syncAlerts(rec.subject, [rec.student]);
  return rec;
}

module.exports = { correctRecord, STATUSES, WINDOW_DAYS };
