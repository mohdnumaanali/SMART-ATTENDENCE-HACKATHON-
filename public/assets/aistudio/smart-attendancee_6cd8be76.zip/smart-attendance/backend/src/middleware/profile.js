const Student = require('../models/Student');
const Faculty = require('../models/Faculty');
const asyncHandler = require('../utils/asyncHandler');

exports.loadStudent = asyncHandler(async (req, res, next) => {
  req.student = await Student.findOne({ user: req.user._id, isActive: true }).populate('user', 'name email');
  if (!req.student) return res.status(403).json({ message: 'Student profile not found or inactive' });
  next();
});

exports.loadFaculty = asyncHandler(async (req, res, next) => {
  req.faculty = await Faculty.findOne({ user: req.user._id, isActive: true }).populate('user', 'name email');
  if (!req.faculty) return res.status(403).json({ message: 'Faculty profile not found or inactive' });
  next();
});
