const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const fs = require('fs');
const { notFound, errorHandler } = require('./middleware/error');

const app = express();
app.set('trust proxy', 1); // required behind Render/Railway proxies for rate limiting

const allowedOrigins = (process.env.CLIENT_URL || 'http://localhost:4200')
  .split(',')
  .map((o) => o.trim());

app.use(helmet({ contentSecurityPolicy: false }));
// Same-origin requests (Angular served by this server) always pass; other origins must be listed in CLIENT_URL
app.use(
  cors((req, cb) => {
    const origin = req.header('Origin');
    const sameOrigin = origin && origin.replace(/^https?:\/\//, '') === req.header('Host');
    cb(null, { origin: !origin || sameOrigin || allowedOrigins.includes(origin), credentials: true });
  })
);
app.use(express.json({ limit: '1mb' }));
if (process.env.NODE_ENV !== 'production') app.use(morgan('dev'));

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));
app.use('/api/auth', require('./routes/auth.routes'));
app.use('/api/student', require('./routes/student.routes'));
app.use('/api/faculty', require('./routes/faculty.routes'));
app.use('/api/admin', require('./routes/admin.routes'));
app.use('/api/notifications', require('./routes/notification.routes'));

// Single-service deployment: serve the built Angular app if it exists
const dist = path.join(__dirname, '../../frontend/dist/smart-attendance-frontend/browser');
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get(/^\/(?!api\/).*/, (req, res) => res.sendFile(path.join(dist, 'index.html')));
}

app.use(notFound);
app.use(errorHandler);

module.exports = app;
