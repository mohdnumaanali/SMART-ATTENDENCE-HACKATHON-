require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const User = require('../models/User');
const Student = require('../models/Student');
const Faculty = require('../models/Faculty');
const Subject = require('../models/Subject');
const Attendance = require('../models/Attendance');
const Notification = require('../models/Notification');
const AcademicSession = require('../models/AcademicSession');
const { analyze } = require('../utils/attendanceMath');

// Deterministic RNG so every seed run gives the same data
function rng(seed) {
  return () => {
    seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rand = rng(42);

const DEPT = 'Computer Science';
const SEM = 5;

(async () => {
  if (process.env.NODE_ENV === 'production' && process.env.ALLOW_SEED !== 'true') {
    console.error('Refusing to seed in production: this wipes all data. Set ALLOW_SEED=true to override.');
    process.exit(1);
  }
  await connectDB();
  await Promise.all([
    Attendance.deleteMany(), Notification.deleteMany(), Subject.deleteMany(),
    Student.deleteMany(), Faculty.deleteMany(), User.deleteMany(), AcademicSession.deleteMany(),
  ]);

  await AcademicSession.create({
    name: '2026-27 Odd',
    startDate: new Date('2026-08-01'),
    endDate: new Date('2026-12-20'),
    minAttendance: 75,
    isActive: true,
  });

  // Users are created with .create() so the bcrypt pre-save hook runs
  await User.create({ name: 'System Admin', email: 'admin@college.edu', password: 'Admin@123', role: 'admin' });

  const facultyData = [
    ['Dr. Ananya Rao', 'ananya.rao@college.edu', 'FAC001'],
    ['Prof. Vikram Singh', 'vikram.singh@college.edu', 'FAC002'],
    ['Dr. Meera Nair', 'meera.nair@college.edu', 'FAC003'],
  ];
  const faculty = [];
  for (const [name, email, employeeId] of facultyData) {
    const u = await User.create({ name, email, password: 'Faculty@123', role: 'faculty' });
    faculty.push(await Faculty.create({ user: u._id, employeeId, department: DEPT }));
  }

  const subjectData = [
    ['Database Management Systems', 'CS501', 0],
    ['Operating Systems', 'CS502', 1],
    ['Computer Networks', 'CS503', 2],
    ['Web Technologies', 'CS504', 0],
  ];
  const subjects = [];
  for (const [name, code, f] of subjectData) {
    subjects.push(await Subject.create({
      name, code, department: DEPT, semester: SEM, sections: ['A', 'B'], faculty: faculty[f]._id,
    }));
  }

  // 12 students; "tendency" = probability of attending, a few intentionally low
  const names = ['Aarav Sharma', 'Diya Patel', 'Rohan Gupta', 'Sneha Reddy', 'Kabir Mehta', 'Ishita Das',
    'Arjun Iyer', 'Priya Menon', 'Nikhil Joshi', 'Tanvi Kulkarni', 'Rahul Verma', 'Aditi Bansal'];
  const tendencies = [0.95, 0.88, 0.7, 0.82, 0.65, 0.92, 0.78, 0.9, 0.6, 0.85, 0.72, 0.93];
  const students = [];
  for (let i = 0; i < names.length; i++) {
    const email = `${names[i].split(' ')[0].toLowerCase()}@student.college.edu`;
    const u = await User.create({ name: names[i], email, password: 'Student@123', role: 'student' });
    students.push({
      doc: await Student.create({
        user: u._id,
        rollNumber: `CS23${String(i + 1).padStart(3, '0')}`,
        department: DEPT,
        semester: SEM,
        section: i < 6 ? 'A' : 'B',
      }),
      p: tendencies[i],
    });
  }

  // 45 days of weekday classes; each subject has a fixed period per day
  const records = [];
  const today = new Date();
  for (let d = 45; d >= 1; d--) {
    const date = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate() - d));
    const dow = date.getUTCDay();
    if (dow === 0 || dow === 6) continue;
    subjects.forEach((subj, idx) => {
      // Not every subject meets every weekday
      if ((dow + idx) % 5 === 4) return;
      for (const s of students) {
        const r = rand();
        const status = r < s.p * 0.93 ? 'Present' : r < s.p ? 'Late' : 'Absent';
        records.push({
          student: s.doc._id, subject: subj._id, faculty: subj.faculty, section: s.doc.section,
          date, period: idx + 1, status,
        });
      }
    });
  }
  await Attendance.insertMany(records, { ordered: false });

  // Shortage notifications generated from the same math the dashboard will use
  const min = 75;
  for (const s of students) {
    for (const subj of subjects) {
      const rows = records.filter((r) => String(r.student) === String(s.doc._id) && String(r.subject) === String(subj._id));
      const attended = rows.filter((r) => r.status !== 'Absent').length;
      const a = analyze(attended, rows.length, min);
      if (!a.eligible) {
        await Notification.create({
          user: s.doc.user, type: 'shortage', subject: subj._id,
          title: `Attendance shortage: ${subj.code}`,
          message: `${subj.name}: ${a.currentPercentage}% (required ${min}%). ${a.message}`,
        });
      }
    }
  }

  console.log(`Seeded ${records.length} attendance records.`);
  console.log('Admin:   admin@college.edu / Admin@123');
  console.log('Faculty: ananya.rao@college.edu / Faculty@123');
  console.log('Student: aarav@student.college.edu / Student@123');
  await mongoose.disconnect();
})().catch((e) => { console.error(e); process.exit(1); });
