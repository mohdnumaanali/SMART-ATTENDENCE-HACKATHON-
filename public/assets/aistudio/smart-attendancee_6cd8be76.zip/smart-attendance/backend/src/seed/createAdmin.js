// Production bootstrap: creates the first admin + a default academic session. Safe to re-run.
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const User = require('../models/User');
const AcademicSession = require('../models/AcademicSession');

(async () => {
  const { ADMIN_NAME = 'System Admin', ADMIN_EMAIL, ADMIN_PASSWORD } = process.env;
  if (!ADMIN_EMAIL || !ADMIN_PASSWORD || ADMIN_PASSWORD.length < 8) {
    console.error('Set ADMIN_EMAIL and ADMIN_PASSWORD (min 8 chars) in the environment.');
    process.exit(1);
  }
  await connectDB();
  if (await User.exists({ email: ADMIN_EMAIL.toLowerCase() })) console.log('Admin already exists, nothing changed.');
  else {
    await User.create({ name: ADMIN_NAME, email: ADMIN_EMAIL, password: ADMIN_PASSWORD, role: 'admin' });
    console.log(`Admin created: ${ADMIN_EMAIL}`);
  }
  if (!(await AcademicSession.exists({}))) {
    const y = new Date().getFullYear();
    await AcademicSession.create({
      name: `${y}-${String(y + 1).slice(2)}`, startDate: new Date(y, 5, 1), endDate: new Date(y + 1, 4, 31),
      minAttendance: 75, isActive: true,
    });
    console.log('Default academic session created (min attendance 75%).');
  }
  await mongoose.disconnect();
})().catch((e) => { console.error(e); process.exit(1); });
