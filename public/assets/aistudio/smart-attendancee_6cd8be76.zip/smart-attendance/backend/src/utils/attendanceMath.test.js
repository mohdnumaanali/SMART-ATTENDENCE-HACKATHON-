const assert = require('assert');
const { analyze } = require('./attendanceMath');

// 28/40 = 70%, need 75%  ->  (28+x)/(40+x) >= 0.75  ->  x >= 8
let r = analyze(28, 40, 75);
assert.strictEqual(r.currentPercentage, 70);
assert.strictEqual(r.classesNeeded, 8);
assert.strictEqual(r.eligible, false);
assert.ok((28 + 8) / (40 + 8) >= 0.75);
assert.ok((28 + 7) / (40 + 7) < 0.75);

// Eligible student: 34/40 = 85%, y <= 5.33 -> 5
r = analyze(34, 40, 75);
assert.strictEqual(r.classesNeeded, 0);
assert.strictEqual(r.safeMisses, 5);
assert.ok(34 / 45 >= 0.75 && 34 / 46 < 0.75);

// Exactly at limit: 30/40 = 75%
r = analyze(30, 40, 75);
assert.strictEqual(r.safeMisses, 0);
assert.strictEqual(r.eligible, true);

// Empty
r = analyze(0, 0, 75);
assert.strictEqual(r.eligible, true);

console.log('attendanceMath: all tests passed');
