exports.pageParams = (req, def = 20, max = 100) => {
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || def, 1), max);
  return { page, limit, skip: (page - 1) * limit };
};
exports.pageResult = (data, total, { page, limit }) => ({ data, total, page, pages: Math.max(Math.ceil(total / limit), 1) });
exports.escapeRegex = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
