// "2026-11-12" -> Date at 00:00 UTC. Keeps one canonical value per class day.
exports.toDay = (str) => {
  const d = new Date(`${str}T00:00:00.000Z`);
  if (isNaN(d.getTime())) throw Object.assign(new Error('Invalid date'), { status: 400 });
  return d;
};
