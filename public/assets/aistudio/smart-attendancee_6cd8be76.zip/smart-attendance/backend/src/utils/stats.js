const mongoose = require('mongoose');
const Attendance = require('../models/Attendance');
const AcademicSession = require('../models/AcademicSession');
const Notification = require('../models/Notification');
const Student = require('../models/Student');
const Subject = require('../models/Subject');
const Enrollment = require('../models/Enrollment');
const { analyze } = require('./attendanceMath');

const oid = (id) => new mongoose.Types.ObjectId(String(id));

async function getSettings() {
  const s = await AcademicSession.findOne({ isActive: true }).lean();
  return {
    minAttendance: s ? s.minAttendance : 75,
    lateCountsAsPresent: s ? s.lateCountsAsPresent : true,
    session: s ? { _id: s._id, name: s.name } : null,
  };
}

const attendedOf = (c, settings) => c.present + (settings.lateCountsAsPresent ? c.late : 0);

const COUNTS = {
  present: { $sum: { $cond: [{ $eq: ['$status', 'Present'] }, 1, 0] } },
  late: { $sum: { $cond: [{ $eq: ['$status', 'Late'] }, 1, 0] } },
  absent: { $sum: { $cond: [{ $eq: ['$status', 'Absent'] }, 1, 0] } },
  total: { $sum: 1 },
};

// Attendance counts grouped by student + subject. `match` must use ObjectIds.
async function perStudentSubject(match = {}) {
  const rows = await Attendance.aggregate([
    { $match: match },
    { $group: { _id: { student: '$student', subject: '$subject' }, ...COUNTS } },
  ]);
  return rows.map((r) => ({
    student: r._id.student, subject: r._id.subject,
    present: r.present, late: r.late, absent: r.absent, total: r.total,
  }));
}

function withAnalysis(c, settings) {
  const a = analyze(attendedOf(c, settings), c.total, settings.minAttendance);
  return { present: c.present, late: c.late, absent: c.absent, ...a };
}

async function monthlyTrend(match, settings) {
  const rows = await Attendance.aggregate([
    { $match: match },
    { $group: { _id: { $dateToString: { format: '%Y-%m', date: '$date' } }, ...COUNTS } },
    { $sort: { _id: 1 } },
  ]);
  return rows.map((r) => ({
    month: r._id, total: r.total, present: r.present, late: r.late, absent: r.absent,
    percentage: r.total ? +((attendedOf(r, settings) / r.total) * 100).toFixed(1) : 0,
  }));
}

// Students of a subject = the class (department + semester + section) plus anyone explicitly enrolled.
async function studentsForSubject(subject, section) {
  const enrolled = await Enrollment.distinct('student', { subject: subject._id });
  const sec = section || { $in: subject.sections };
  return Student.find({
    isActive: true,
    $or: [
      { department: subject.department, semester: subject.semester, section: sec },
      { _id: { $in: enrolled }, section: sec },
    ],
  })
    .populate('user', 'name email')
    .sort({ rollNumber: 1 });
}

// Creates / refreshes / clears shortage and low-attendance notifications for the given students.
async function syncAlerts(subjectId, studentIds, settings) {
  settings = settings || (await getSettings());
  if (!studentIds.length) return;
  const subject = await Subject.findById(subjectId).select('name code');
  if (!subject) return;
  const students = await Student.find({ _id: { $in: studentIds } }).select('user');
  const userOf = new Map(students.map((s) => [String(s._id), s.user]));
  const rows = await perStudentSubject({ subject: oid(subjectId), student: { $in: studentIds.map(oid) } });
  const min = settings.minAttendance;

  for (const r of rows) {
    const user = userOf.get(String(r.student));
    if (!user) continue;
    const a = analyze(attendedOf(r, settings), r.total, min);
    const type = !a.eligible ? 'shortage' : a.currentPercentage < min + 5 ? 'warning' : null;

    const stale = { user, subject: subject._id, isRead: false, type: { $in: ['shortage', 'warning'] } };
    if (type) stale.type.$ne = type;
    await Notification.deleteMany(stale);

    if (type) {
      const title = type === 'shortage' ? `Attendance shortage: ${subject.code}` : `Low attendance warning: ${subject.code}`;
      const lead = type === 'shortage' ? `below the required ${min}%` : `close to the required ${min}%`;
      await Notification.findOneAndUpdate(
        { user, subject: subject._id, type, isRead: false },
        { $set: { title, message: `${subject.name}: ${a.currentPercentage}% is ${lead}. ${a.message}` } },
        { upsert: true }
      );
    }
  }
}

module.exports = {
  oid, getSettings, attendedOf, COUNTS, perStudentSubject, withAnalysis, monthlyTrend, studentsForSubject, syncAlerts,
};
