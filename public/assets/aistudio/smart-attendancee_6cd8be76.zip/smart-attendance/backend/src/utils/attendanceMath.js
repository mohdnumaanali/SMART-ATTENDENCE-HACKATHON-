/**
 * attended = Present (+ Late if lateCountsAsPresent)
 * total    = all recorded classes
 */
function percentage(attended, total) {
  return total === 0 ? 0 : (attended / total) * 100;
}

/**
 * Smallest x such that (A + x) / (T + x) >= p/100
 *   A + x >= p(T + x)/100  ->  x >= (pT - 100A) / (100 - p)
 * Returns 0 if already eligible, null if p >= 100 and not at 100% (impossible).
 */
function classesNeeded(attended, total, requiredPct) {
  if (total === 0) return 0;
  if (percentage(attended, total) >= requiredPct) return 0;
  if (requiredPct >= 100) return null;
  return Math.ceil((requiredPct * total - 100 * attended) / (100 - requiredPct));
}

/**
 * Largest y such that A / (T + y) >= p/100
 *   y <= (100A / p) - T
 * Returns 0 if the student is already below the requirement.
 */
function safeMisses(attended, total, requiredPct) {
  if (total === 0) return 0;
  if (percentage(attended, total) < requiredPct) return 0;
  return Math.max(0, Math.floor((100 * attended) / requiredPct - total));
}

function analyze(attended, total, requiredPct = 75) {
  const current = percentage(attended, total);
  const needed = classesNeeded(attended, total, requiredPct);
  const canMiss = safeMisses(attended, total, requiredPct);
  const ifMissNext = percentage(attended, total + 1);
  const eligible = total === 0 ? true : current >= requiredPct;

  let message;
  if (total === 0) message = 'No classes conducted yet.';
  else if (needed === null) message = 'The requirement is 100%, which cannot be recovered after a missed class.';
  else if (needed > 0)
    message = `You need to attend your next ${needed} class${needed > 1 ? 'es' : ''} to reach ${requiredPct}% attendance.`;
  else if (canMiss > 0)
    message = `You are eligible. You can safely miss up to ${canMiss} more class${canMiss > 1 ? 'es' : ''} and stay at or above ${requiredPct}%.`;
  else message = `You are exactly at the limit. Missing the next class will drop you below ${requiredPct}%.`;

  return {
    attended,
    total,
    missed: total - attended,
    currentPercentage: +current.toFixed(2),
    requiredPercentage: requiredPct,
    eligible,
    classesNeeded: needed,
    safeMisses: canMiss,
    percentageIfMissNext: +ifMissNext.toFixed(2),
    message,
  };
}

module.exports = { percentage, classesNeeded, safeMisses, analyze };
