const mongoose = require('mongoose');

const academicSessionSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, unique: true, trim: true }, // e.g. "2026-27 Odd"
    startDate: { type: Date, required: true },
    endDate: { type: Date, required: true },
    minAttendance: { type: Number, default: 75, min: 1, max: 100 },
    lateCountsAsPresent: { type: Boolean, default: true },
    isActive: { type: Boolean, default: false },
  },
  { timestamps: true }
);

// Only one active session at a time
academicSessionSchema.pre('save', async function (next) {
  if (this.isActive && this.isModified('isActive')) {
    await this.constructor.updateMany({ _id: { $ne: this._id } }, { isActive: false });
  }
  next();
});

module.exports = mongoose.model('AcademicSession', academicSessionSchema);
