const mongoose = require('mongoose');

// Explicit enrollment of a student in a subject (in addition to the automatic
// department + semester + section class membership).
const enrollmentSchema = new mongoose.Schema(
  {
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
    subject: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject', required: true },
    enrolledBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

enrollmentSchema.index({ student: 1, subject: 1 }, { unique: true });
enrollmentSchema.index({ subject: 1 });

module.exports = mongoose.model('Enrollment', enrollmentSchema);
