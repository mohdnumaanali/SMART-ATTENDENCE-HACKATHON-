const mongoose = require('mongoose');

const attendanceSchema = new mongoose.Schema(
  {
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
    subject: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject', required: true },
    faculty: { type: mongoose.Schema.Types.ObjectId, ref: 'Faculty', required: true },
    section: { type: String, required: true, uppercase: true },
    date: { type: Date, required: true }, // normalized to 00:00 UTC of the class day
    period: { type: Number, required: true, min: 1, max: 10 },
    status: { type: String, enum: ['Present', 'Absent', 'Late'], required: true },
    edits: [
      {
        by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        from: String,
        to: String,
        reason: String,
        at: { type: Date, default: Date.now },
      },
    ],
  },
  { timestamps: true }
);

// Enforces no duplicate entry for the same student, subject, date and period
attendanceSchema.index({ student: 1, subject: 1, date: 1, period: 1 }, { unique: true });
attendanceSchema.index({ subject: 1, date: 1, period: 1 });
attendanceSchema.index({ student: 1, date: -1 });

module.exports = mongoose.model('Attendance', attendanceSchema);
