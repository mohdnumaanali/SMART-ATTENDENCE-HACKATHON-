const router = require('express').Router();
const { body } = require('express-validator');
const rateLimit = require('express-rate-limit');
const validate = require('../middleware/validate');
const { protect } = require('../middleware/auth');
const ctrl = require('../controllers/auth.controller');

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: { message: 'Too many login attempts. Try again in 15 minutes.' },
});

router.post(
  '/login',
  loginLimiter,
  [
    body().custom((_, { req }) => String(req.body.identifier || req.body.email || '').trim().length > 0).withMessage('Enter your email or roll number'),
    body('password').notEmpty().withMessage('Password is required'),
    body('role').isIn(['student', 'faculty', 'admin']).withMessage('Select a valid role'),
  ],
  validate,
  ctrl.login
);

router.get('/me', protect, ctrl.me);
router.post('/logout', protect, ctrl.logout);
router.put(
  '/change-password',
  protect,
  [
    body('currentPassword').notEmpty().withMessage('Current password is required'),
    body('newPassword').isLength({ min: 8 }).withMessage('New password must be at least 8 characters'),
  ],
  validate,
  ctrl.changePassword
);

module.exports = router;
