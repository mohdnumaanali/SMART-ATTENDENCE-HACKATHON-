const router = require('express').Router();
const { protect, authorize } = require('../middleware/auth');
const { loadStudent } = require('../middleware/profile');
const c = require('../controllers/student.controller');

router.use(protect, authorize('student'), loadStudent);
router.get('/summary', c.summary);
router.get('/history', c.history);
router.get('/profile', c.profile);
router.get('/report/export', c.exportReport);

module.exports = router;
