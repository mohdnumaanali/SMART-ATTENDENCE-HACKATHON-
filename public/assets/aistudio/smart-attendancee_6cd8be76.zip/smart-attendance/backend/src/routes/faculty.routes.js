const router = require('express').Router();
const { body } = require('express-validator');
const validate = require('../middleware/validate');
const { protect, authorize } = require('../middleware/auth');
const { loadFaculty } = require('../middleware/profile');
const c = require('../controllers/faculty.controller');

router.use(protect, authorize('faculty'), loadFaculty);

router.get('/overview', c.overview);
router.get('/subjects', c.subjects);
router.get('/subjects/:id/students', c.classList);
router.get('/students', c.students);

router.post(
  '/attendance',
  [
    body('subject').isMongoId().withMessage('Select a subject'),
    body('section').trim().notEmpty().withMessage('Select a section'),
    body('date').matches(/^\d{4}-\d{2}-\d{2}$/).withMessage('Select a valid date'),
    body('period').isInt({ min: 1, max: 10 }).withMessage('Period must be between 1 and 10').toInt(),
    body('records').isArray({ min: 1 }).withMessage('No attendance records submitted'),
    body('records.*.student').isMongoId().withMessage('Invalid student in records'),
    body('records.*.status').isIn(['Present', 'Absent', 'Late']).withMessage('Status must be Present, Absent or Late'),
  ],
  validate,
  c.mark
);
router.get('/attendance/sessions', c.sessions);
router.get('/attendance/session', c.sessionDetail);
router.put(
  '/attendance/:id',
  [
    body('status').isIn(['Present', 'Absent', 'Late']).withMessage('Status must be Present, Absent or Late'),
    body('reason').trim().isLength({ min: 3, max: 300 }).withMessage('Enter a reason (3-300 characters)'),
  ],
  validate,
  c.correct
);

router.get('/reports/:type', c.report);
router.get('/reports/:type/export', c.exportReport);

router.post(
  '/announcements',
  [
    body('subject').isMongoId().withMessage('Select a subject'),
    body('title').trim().isLength({ min: 3, max: 100 }).withMessage('Title must be 3-100 characters'),
    body('message').trim().isLength({ min: 3, max: 1000 }).withMessage('Message must be 3-1000 characters'),
  ],
  validate,
  c.announce
);

module.exports = router;
