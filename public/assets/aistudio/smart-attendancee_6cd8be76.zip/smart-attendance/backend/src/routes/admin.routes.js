const router = require('express').Router();
const { body } = require('express-validator');
const validate = require('../middleware/validate');
const { protect, authorize } = require('../middleware/auth');
const catalog = require('../controllers/admin.catalog.controller');
const rep = require('../controllers/admin.reports.controller');
const set = require('../controllers/admin.settings.controller');
const enr = require('../controllers/admin.enrollment.controller');

router.use(protect, authorize('admin'));

const optional = (chain) => chain.optional({ values: 'falsy' });
const person = (isCreate) => [
  isCreate ? body('name').trim().notEmpty().withMessage('Name is required') : optional(body('name').trim()),
  isCreate ? body('email').isEmail().withMessage('Enter a valid email').normalizeEmail() : optional(body('email').isEmail().withMessage('Enter a valid email').normalizeEmail()),
  isCreate
    ? body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
    : optional(body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters')),
];
const dept = (isCreate) => (isCreate ? body('department').trim().notEmpty().withMessage('Department is required') : optional(body('department').trim()));

/* meta + overview */
router.get('/meta', catalog.meta);
router.get('/overview', rep.overview);

/* students */
router.get('/students', catalog.listStudents);
router.post('/students', [
  ...person(true), dept(true),
  body('rollNumber').trim().notEmpty().withMessage('Roll number is required'),
  body('semester').isInt({ min: 1, max: 12 }).withMessage('Semester must be 1-12').toInt(),
  body('section').trim().notEmpty().withMessage('Section is required'),
], validate, catalog.createStudent);
router.put('/students/:id', [
  ...person(false), dept(false),
  optional(body('semester').isInt({ min: 1, max: 12 }).withMessage('Semester must be 1-12').toInt()),
  optional(body('isActive').isBoolean().toBoolean()),
], validate, catalog.updateStudent);
router.delete('/students/:id', catalog.deleteStudent);

/* faculty */
router.get('/faculty', catalog.listFaculty);
router.post('/faculty', [
  ...person(true), dept(true),
  body('employeeId').trim().notEmpty().withMessage('Employee ID is required'),
], validate, catalog.createFaculty);
router.put('/faculty/:id', [...person(false), dept(false), optional(body('isActive').isBoolean().toBoolean())], validate, catalog.updateFaculty);
router.delete('/faculty/:id', catalog.deleteFaculty);

/* subjects */
router.get('/subjects', catalog.listSubjects);
router.post('/subjects', [
  body('name').trim().notEmpty().withMessage('Subject name is required'),
  body('code').trim().notEmpty().withMessage('Subject code is required'),
  dept(true),
  body('semester').isInt({ min: 1, max: 12 }).withMessage('Semester must be 1-12').toInt(),
  body('sections').custom((v) => (Array.isArray(v) ? v.length : String(v || '').trim().length) > 0).withMessage('Add at least one section'),
  optional(body('credits').isInt({ min: 0, max: 20 }).toInt()),
  optional(body('faculty').isMongoId().withMessage('Invalid faculty')),
], validate, catalog.createSubject);
router.put('/subjects/:id', [
  optional(body('semester').isInt({ min: 1, max: 12 }).withMessage('Semester must be 1-12').toInt()),
  optional(body('isActive').isBoolean().toBoolean()),
], validate, catalog.updateSubject);
router.delete('/subjects/:id', catalog.deleteSubject);

/* enrollments */
router.get('/enrollments', enr.list);
router.post('/enrollments', [
  body('student').isMongoId().withMessage('Select a student'),
  body('subject').isMongoId().withMessage('Select a subject'),
], validate, enr.create);
router.delete('/enrollments/:id', enr.remove);

/* monitoring */
router.get('/monitoring/shortage', rep.shortage);
router.get('/monitoring/shortage/export', rep.shortageExport);
router.get('/monitoring/late', rep.late);
router.get('/monitoring/daily', rep.daily);
router.put('/attendance/:id', [
  body('status').isIn(['Present', 'Absent', 'Late']),
  body('reason').trim().isLength({ min: 3, max: 300 }).withMessage('Enter a reason (3-300 characters)'),
], validate, rep.correct);

/* analytics */
router.get('/analytics', rep.analytics);

/* settings */
router.get('/settings', set.getSettings);
router.put('/settings', [
  optional(body('minAttendance').isFloat({ min: 1, max: 100 }).withMessage('Minimum attendance must be 1-100').toFloat()),
  optional(body('lateCountsAsPresent').isBoolean().toBoolean()),
], validate, set.updateSettings);
router.post('/notifications/resync', set.resyncAlerts);

const sessionBody = [
  body('name').trim().notEmpty().withMessage('Session name is required'),
  body('startDate').isISO8601().withMessage('Enter a valid start date'),
  body('endDate').isISO8601().withMessage('Enter a valid end date'),
  optional(body('minAttendance').isFloat({ min: 1, max: 100 }).toFloat()),
];
router.get('/sessions', set.listSessions);
router.post('/sessions', sessionBody, validate, set.createSession);
router.put('/sessions/:id', sessionBody, validate, set.updateSession);
router.put('/sessions/:id/activate', set.activateSession);
router.delete('/sessions/:id', set.deleteSession);

/* users & roles */
router.get('/users', set.listUsers);
router.post('/users/admin', person(true), validate, set.createAdmin);
router.put('/users/:id', [optional(body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters')), optional(body('isActive').isBoolean().toBoolean())], validate, set.updateUser);

module.exports = router;
