require('dotenv').config();
const app = require('./src/app');
const connectDB = require('./src/config/db');

const PORT = process.env.PORT || 5000;

(async () => {
  if (!process.env.JWT_SECRET || !process.env.MONGO_URI) {
    console.error('Missing JWT_SECRET or MONGO_URI in .env');
    process.exit(1);
  }
  await connectDB();
  app.listen(PORT, () => console.log(`API running on port ${PORT}`));
})();
