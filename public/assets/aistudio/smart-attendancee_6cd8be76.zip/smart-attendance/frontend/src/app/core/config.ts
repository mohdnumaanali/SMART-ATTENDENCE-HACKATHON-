// All API calls go to this base path. In development, proxy.conf.json forwards /api to the backend.
// In production the backend serves the Angular build, so the same relative path works.
// If you host the frontend separately (Vercel/Netlify), set this to the full backend URL,
// e.g. 'https://your-api.onrender.com/api', and add the frontend origin to CLIENT_URL on the backend.
export const API_URL = '/api';
