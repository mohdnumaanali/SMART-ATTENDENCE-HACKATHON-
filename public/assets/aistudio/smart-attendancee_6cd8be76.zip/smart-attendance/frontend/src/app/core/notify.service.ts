import { Injectable, inject, signal } from '@angular/core';
import { ApiService } from './api.service';

@Injectable({ providedIn: 'root' })
export class NotifyService {
  private api = inject(ApiService);
  unread = signal(0);
  refresh() {
    this.api.get('/notifications/count').subscribe({ next: (r) => this.unread.set(r.unread), error: () => {} });
  }
}
