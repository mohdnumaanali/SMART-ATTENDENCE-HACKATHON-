import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { ToastService, errMsg } from '../../core/toast.service';

@Component({
  selector: 'app-faculty-announcements',
  standalone: true,
  imports: [FormsModule],
  template: `
    <div class="page-head"><div><h2>Announcements</h2><p>Send an update to students of one of your subjects. They see it in their notifications.</p></div></div>
    <div class="card" style="max-width:640px">
      <form class="stack" (ngSubmit)="send()">
        <div class="form-grid">
          <label>Subject
            <select name="subject" [(ngModel)]="subject" (ngModelChange)="section = ''">
              <option value="">Select subject</option>
              @for (s of subjects; track s._id) { <option [value]="s._id">{{ s.code }} - {{ s.name }}</option> }
            </select>
          </label>
          <label>Section
            <select name="section" [(ngModel)]="section" [disabled]="!current">
              <option value="">All sections</option>
              @for (sec of current?.sections || []; track sec) { <option [value]="sec">Section {{ sec }}</option> }
            </select>
          </label>
        </div>
        <label>Title<input name="title" [(ngModel)]="title" maxlength="100" placeholder="e.g. Assignment submission deadline" /></label>
        <label>Message<textarea name="message" [(ngModel)]="message" maxlength="1000"></textarea></label>
        <div><button class="btn primary" [disabled]="busy || !subject || title.trim().length < 3 || message.trim().length < 3">{{ busy ? 'Sending...' : 'Send to students' }}</button></div>
      </form>
    </div>`,
})
export class FacultyAnnouncementsComponent implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  subjects: any[] = [];
  subject = ''; section = ''; title = ''; message = ''; busy = false;
  get current() { return this.subjects.find((s) => s._id === this.subject); }

  ngOnInit() { this.api.get('/faculty/subjects').subscribe({ next: (s) => (this.subjects = s), error: (e) => this.toast.error(errMsg(e)) }); }
  send() {
    this.busy = true;
    this.api.post('/faculty/announcements', { subject: this.subject, section: this.section, title: this.title, message: this.message }).subscribe({
      next: (r) => { this.busy = false; this.title = this.message = ''; this.toast.success(r.message); },
      error: (e) => { this.busy = false; this.toast.error(errMsg(e)); },
    });
  }
}
