import { Injectable, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs';
import { API_URL } from './config';

export type Role = 'student' | 'faculty' | 'admin';
export interface AuthUser { id: string; name: string; email: string; role: Role; }

const TOKEN_KEY = 'sa_token';
const USER_KEY = 'sa_user';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  private router = inject(Router);
  user = signal<AuthUser | null>(this.read());

  private read(): AuthUser | null {
    try { return JSON.parse(localStorage.getItem(USER_KEY) || 'null'); } catch { return null; }
  }
  get token() { return localStorage.getItem(TOKEN_KEY); }
  get loggedIn() { return !!this.token && !!this.user(); }
  homeFor(role: Role) { return '/' + role; }

  login(identifier: string, password: string, role: Role) {
    return this.http.post<any>(`${API_URL}/auth/login`, { identifier, password, role }).pipe(
      tap((res) => {
        localStorage.setItem(TOKEN_KEY, res.token);
        localStorage.setItem(USER_KEY, JSON.stringify(res.user));
        this.user.set(res.user);
      })
    );
  }

  clear() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    this.user.set(null);
  }

  logout() {
    if (this.token) this.http.post(`${API_URL}/auth/logout`, {}).subscribe({ error: () => {} });
    this.clear();
    this.router.navigate(['/login']);
  }
}
