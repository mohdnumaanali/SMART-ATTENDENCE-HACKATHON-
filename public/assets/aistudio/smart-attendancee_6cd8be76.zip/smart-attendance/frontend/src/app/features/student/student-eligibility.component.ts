import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { ToastService, errMsg } from '../../core/toast.service';
import { EligComponent } from '../../shared/elig.component';

@Component({
  selector: 'app-student-eligibility',
  standalone: true,
  imports: [FormsModule, EligComponent],
  template: `
    <div class="page-head">
      <div><h2>Eligibility Calculator</h2><p>How many classes you need to attend, or can safely miss, to stay at {{ data?.settings.minAttendance ?? 75 }}%</p></div>
      <span class="spacer"></span>
      <div class="row gap-s no-print">
        <button class="btn" (click)="csv('summary')">Download summary (CSV)</button>
        <button class="btn" (click)="csv('history')">Download full history (CSV)</button>
        <button class="btn" (click)="print()">Print / Save as PDF</button>
      </div>
    </div>
    @if (loading) { <div class="spinner-wrap"><div class="spinner"></div></div> }
    @else if (data) {
      <div class="card">
        <div class="card-head"><h3>Overall attendance</h3><app-elig [row]="data.overall" /></div>
        <div class="alert {{ data.overall.total === 0 ? 'info' : data.overall.eligible ? 'success' : 'danger' }}">{{ data.overall.message }}</div>
        <div class="calc" style="margin-top:14px">
          <div><small>Current attendance</small><b>{{ data.overall.currentPercentage }}%</b></div>
          <div><small>Required attendance</small><b>{{ data.overall.requiredPercentage }}%</b></div>
          <div><small>Consecutive classes needed</small><b>{{ data.overall.classesNeeded ?? 'n/a' }}</b></div>
          <div><small>If you miss the next class</small><b>{{ data.overall.percentageIfMissNext }}%</b></div>
          <div><small>Classes you can safely miss</small><b>{{ data.overall.safeMisses }}</b></div>
        </div>
        <p class="muted" style="margin:12px 0 0">{{ data.overall.attended }} attended out of {{ data.overall.total }} classes. Late counts as attended: {{ data.settings.lateCountsAsPresent ? 'yes' : 'no' }}.
          Needed classes x is the smallest whole number where (attended + x) / (total + x) is at least {{ data.overall.requiredPercentage }}%.</p>
      </div>

      <div class="card">
        <div class="card-head"><h3>Subject-wise eligibility</h3></div>
        @if (!data.subjects.length) { <div class="empty">No subjects found for your class.</div> }
        @else {
          <div class="table-wrap"><table>
            <thead><tr><th>Subject</th><th>Faculty</th><th class="num">Total</th><th class="num">Attended</th><th>Attendance</th><th>Status</th><th class="num">Attend next</th><th class="num">Can miss</th></tr></thead>
            <tbody>
              @for (s of data.subjects; track s.subjectId) {
                <tr>
                  <td><strong>{{ s.name }}</strong><div class="muted">{{ s.code }}</div></td>
                  <td>{{ s.faculty || '-' }}</td>
                  <td class="num">{{ s.total }}</td><td class="num">{{ s.attended }}</td>
                  <td><div class="pct-cell"><div class="bar" style="width:90px"><span [class.bad]="!s.eligible" [style.width.%]="s.currentPercentage"></span></div><b>{{ s.currentPercentage }}%</b></div></td>
                  <td><app-elig [row]="s" /></td>
                  <td class="num">{{ s.classesNeeded === 0 ? '-' : (s.classesNeeded ?? 'n/a') }}</td>
                  <td class="num">{{ s.total === 0 ? '-' : s.safeMisses }}</td>
                </tr>
              }
            </tbody>
          </table></div>
          <div style="margin-top:12px">
            @for (s of data.subjects; track s.subjectId) {
              @if (s.total > 0 && !s.eligible) { <div class="muted" style="margin-top:4px"><strong>{{ s.code }}:</strong> {{ s.message }}</div> }
            }
          </div>
        }
      </div>

      <div class="card">
        <div class="card-head"><h3>What-if planner</h3></div>
        <div class="filters">
          <label>Calculate for
            <select [(ngModel)]="scope" (ngModelChange)="plan()">
              <option value="all">Overall</option>
              @for (s of data.subjects; track s.subjectId) { <option [value]="s.subjectId">{{ s.code }} - {{ s.name }}</option> }
            </select>
          </label>
          <label>Classes I will attend<input type="number" min="0" [(ngModel)]="attend" (ngModelChange)="plan()" /></label>
          <label>Classes I will miss<input type="number" min="0" [(ngModel)]="miss" (ngModelChange)="plan()" /></label>
        </div>
        <div class="alert {{ projected >= data.settings.minAttendance ? 'success' : 'warn' }}">
          After {{ attend || 0 }} attended and {{ miss || 0 }} missed, attendance becomes <strong>{{ projected }}%</strong>
          ({{ projected >= data.settings.minAttendance ? 'at or above' : 'below' }} the required {{ data.settings.minAttendance }}%).
        </div>
      </div>
    }`,
})
export class StudentEligibilityComponent implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  loading = true;
  data: any;
  scope = 'all';
  attend = 5;
  miss = 0;
  projected = 0;

  ngOnInit() {
    this.api.get('/student/summary').subscribe({
      next: (d) => { this.data = d; this.loading = false; this.plan(); },
      error: (e) => { this.loading = false; this.toast.error(errMsg(e)); },
    });
  }

  csv(type: 'summary' | 'history') {
    this.api.download('/student/report/export', { type }, `attendance-${type}.csv`);
  }
  print() { window.print(); }

  plan() {
    const base = this.scope === 'all' ? this.data.overall : this.data.subjects.find((s: any) => s.subjectId === this.scope);
    const a = Math.max(0, Number(this.attend) || 0), m = Math.max(0, Number(this.miss) || 0);
    const total = base.total + a + m;
    this.projected = total ? +(((base.attended + a) / total) * 100).toFixed(2) : 0;
  }
}
