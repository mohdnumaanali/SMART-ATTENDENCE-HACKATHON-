import { Component, OnInit, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { ToastService, errMsg } from '../../core/toast.service';
import { todayLocal } from '../../shared/util';

@Component({
  selector: 'app-faculty-overview',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="page-head"><div><h2>Overview</h2><p>Your subjects and today's attendance</p></div></div>
    @if (loading) { <div class="spinner-wrap"><div class="spinner"></div></div> }
    @else if (o) {
      <div class="grid g4">
        <div class="stat"><small>Assigned subjects</small><strong>{{ o.subjects }}</strong></div>
        <div class="stat purple"><small>Total students</small><strong>{{ o.students }}</strong></div>
        <div class="stat ok"><small>Classes conducted</small><strong>{{ o.classesConducted }}</strong></div>
        <div class="stat warn"><small>Today's classes marked</small><strong>{{ o.today.sessions }}</strong></div>
      </div>
      <div class="card">
        <div class="card-head"><h3>Today's attendance summary</h3></div>
        @if (o.today.total === 0) { <div class="empty"><strong>Nothing marked today</strong><a routerLink="/faculty/mark">Mark attendance</a></div> }
        @else {
          <div class="row" style="gap:28px">
            <div><div class="muted">Present</div><strong style="font-size:22px;color:var(--ok)">{{ o.today.present }}</strong></div>
            <div><div class="muted">Late</div><strong style="font-size:22px;color:var(--warn)">{{ o.today.late }}</strong></div>
            <div><div class="muted">Absent</div><strong style="font-size:22px;color:var(--bad)">{{ o.today.absent }}</strong></div>
            <div><div class="muted">Entries</div><strong style="font-size:22px">{{ o.today.total }}</strong></div>
          </div>
        }
      </div>
      <div class="card">
        <div class="card-head"><h3>My subjects</h3></div>
        @if (!subjects.length) { <div class="empty"><strong>No subjects assigned</strong>Ask the administrator to assign subjects to you.</div> }
        @else {
          <div class="table-wrap"><table>
            <thead><tr><th>Code</th><th>Subject</th><th>Department</th><th>Semester</th><th>Sections</th><th class="num">Students</th><th></th></tr></thead>
            <tbody>
              @for (s of subjects; track s._id) {
                <tr><td>{{ s.code }}</td><td>{{ s.name }}</td><td>{{ s.department }}</td><td>{{ s.semester }}</td><td>{{ s.sections.join(', ') }}</td><td class="num">{{ s.studentCount }}</td>
                  <td class="actions"><a class="btn sm primary" [routerLink]="'/faculty/mark'" [queryParams]="{ subject: s._id }">Mark attendance</a></td></tr>
              }
            </tbody>
          </table></div>
        }
      </div>
    }`,
})
export class FacultyOverviewComponent implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  loading = true;
  o: any;
  subjects: any[] = [];

  ngOnInit() {
    this.api.get('/faculty/overview', { date: todayLocal() }).subscribe({
      next: (o) => { this.o = o; this.loading = false; },
      error: (e) => { this.loading = false; this.toast.error(errMsg(e)); },
    });
    this.api.get('/faculty/subjects').subscribe({ next: (s) => (this.subjects = s), error: () => {} });
  }
}
