import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService, Role } from '../../core/auth.service';
import { errMsg } from '../../core/toast.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule],
  template: `
    <div class="login-wrap">
      <div class="login-card">
        <div class="login-brand">
          <h1>Smart Attendance</h1>
          <p>College Attendance Management System</p>
        </div>
        <div class="tabs" role="tablist">
          @for (r of roles; track r.value) {
            <button type="button" class="tab" [class.active]="role === r.value" (click)="role = r.value; error = ''">{{ r.label }}</button>
          }
        </div>
        <form class="stack" (ngSubmit)="submit()">
          <label>{{ idLabel }}
            <input type="text" name="email" [(ngModel)]="email" required autocomplete="username" [placeholder]="idHint" />
          </label>
          <label>Password
            <input type="password" name="password" [(ngModel)]="password" required autocomplete="current-password" />
          </label>
          @if (error) { <div class="alert danger">{{ error }}</div> }
          <button class="btn primary block" [disabled]="loading || !email || !password">
            {{ loading ? 'Signing in...' : 'Sign in as ' + current.label }}
          </button>
        </form>
      </div>
    </div>`,
})
export class LoginComponent {
  private auth = inject(AuthService);
  private router = inject(Router);
  roles: { value: Role; label: string }[] = [
    { value: 'student', label: 'Student' }, { value: 'faculty', label: 'Faculty' }, { value: 'admin', label: 'Admin' },
  ];
  role: Role = 'student';
  email = '';
  password = '';
  error = '';
  loading = false;
  get current() { return this.roles.find((r) => r.value === this.role)!; }
  get idLabel() { return this.role === 'student' ? 'Roll number or email' : this.role === 'faculty' ? 'Employee ID or email' : 'Email'; }
  get idHint() { return this.role === 'student' ? 'e.g. CS23001' : this.role === 'faculty' ? 'e.g. FAC001' : 'admin@college.edu'; }

  submit() {
    this.loading = true;
    this.error = '';
    this.auth.login(this.email.trim(), this.password, this.role).subscribe({
      next: (res) => this.router.navigate([this.auth.homeFor(res.user.role)]),
      error: (e) => { this.loading = false; this.error = errMsg(e); },
    });
  }
}
