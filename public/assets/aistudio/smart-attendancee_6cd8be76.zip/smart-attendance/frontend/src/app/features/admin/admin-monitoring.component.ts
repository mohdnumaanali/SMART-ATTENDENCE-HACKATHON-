import { Component, OnInit, inject } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { ToastService, errMsg } from '../../core/toast.service';
import { todayLocal } from '../../shared/util';

@Component({
  selector: 'app-admin-monitoring',
  standalone: true,
  imports: [FormsModule, DatePipe],
  template: `
    <div class="page-head"><div><h2>Attendance Monitoring</h2><p>Shortages, late entries and daily attendance across all departments</p></div></div>
    <div class="tabs">
      @for (t of tabs; track t.key) { <button class="tab" [class.active]="tab === t.key" (click)="setTab(t.key)">{{ t.label }}</button> }
    </div>
    <div class="card">
      <div class="filters">
        @if (tab !== 'daily') {
          <label>Department<select [(ngModel)]="department" (ngModelChange)="load()"><option value="">All</option>@for (d of meta.departments; track d) { <option>{{ d }}</option> }</select></label>
        }
        @if (tab === 'shortage') {
          <label>Semester<select [(ngModel)]="semester" (ngModelChange)="load()"><option value="">All</option>@for (s of meta.semesters; track s) { <option [value]="s">{{ s }}</option> }</select></label>
          <label>Subject<select [(ngModel)]="subject" (ngModelChange)="load()"><option value="">All</option>@for (s of subjects; track s._id) { <option [value]="s._id">{{ s.code }}</option> }</select></label>
        }
        @if (tab === 'late') {
          <label>From<input type="date" [(ngModel)]="from" (ngModelChange)="load()" /></label>
          <label>To<input type="date" [(ngModel)]="to" (ngModelChange)="load()" /></label>
        }
        @if (tab === 'daily') { <label>Date<input type="date" [(ngModel)]="date" (ngModelChange)="load()" /></label> }
        <span class="spacer"></span>
        @if (tab === 'shortage') { <button class="btn" [disabled]="!rows.length" (click)="export()">Export CSV</button> }
      </div>
      @if (loading) { <div class="spinner-wrap"><div class="spinner"></div></div> }
      @else if (!rows.length) { <div class="empty"><strong>Nothing to show</strong>{{ emptyText }}</div> }
      @else {
        @if (tab === 'shortage') {
          <p class="muted" style="margin-top:0">{{ rows.length }} student-subject records below {{ min }}%</p>
          <div class="table-wrap"><table>
            <thead><tr><th>Department</th><th>Sem</th><th>Sec</th><th>Roll number</th><th>Student</th><th>Subject</th><th class="num">Attended / Total</th><th class="num">Attendance</th><th class="num">Attend next</th></tr></thead>
            <tbody>@for (r of rows; track r.studentId + r.subjectId) { <tr><td>{{ r.department }}</td><td>{{ r.semester }}</td><td>{{ r.section }}</td><td>{{ r.rollNumber }}</td><td>{{ r.name }}</td><td>{{ r.code }}</td><td class="num">{{ r.attended }} / {{ r.total }}</td><td class="num"><span class="badge bad">{{ r.percentage }}%</span></td><td class="num">{{ r.classesNeeded }}</td></tr> }</tbody>
          </table></div>
        }
        @if (tab === 'late') {
          <div class="row" style="margin-bottom:12px">@for (s of summary.slice(0, 6); track s.rollNumber) { <span class="badge warn">{{ s.name }} ({{ s.rollNumber }}): {{ s.count }}</span> }</div>
          <div class="table-wrap"><table>
            <thead><tr><th>Date</th><th>Period</th><th>Department</th><th>Subject</th><th>Section</th><th>Roll number</th><th>Student</th></tr></thead>
            <tbody>@for (r of rows; track $index) { <tr><td>{{ r.date | date:'dd MMM yyyy':'UTC' }}</td><td>{{ r.period }}</td><td>{{ r.department }}</td><td>{{ r.code }}</td><td>{{ r.section }}</td><td>{{ r.rollNumber }}</td><td>{{ r.name }}</td></tr> }</tbody>
          </table></div>
        }
        @if (tab === 'daily') {
          <div class="table-wrap"><table>
            <thead><tr><th>Period</th><th>Subject</th><th>Section</th><th class="num">Present</th><th class="num">Late</th><th class="num">Absent</th><th class="num">Total</th></tr></thead>
            <tbody>@for (r of rows; track $index) { <tr><td>{{ r.period }}</td><td>{{ r.code }} - {{ r.subject }}</td><td>{{ r.section }}</td><td class="num">{{ r.present }}</td><td class="num">{{ r.late }}</td><td class="num">{{ r.absent }}</td><td class="num">{{ r.total }}</td></tr> }</tbody>
          </table></div>
        }
      }
    </div>`,
})
export class AdminMonitoringComponent implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  tabs = [{ key: 'shortage', label: 'Attendance shortages' }, { key: 'late', label: 'Late entries' }, { key: 'daily', label: 'Daily attendance' }];
  tab = 'shortage';
  loading = true;
  meta: any = { departments: [], semesters: [] };
  subjects: any[] = [];
  department = ''; semester = ''; subject = ''; from = ''; to = ''; date = todayLocal();
  rows: any[] = [];
  summary: any[] = [];
  min = 75;
  get emptyText() {
    return { shortage: 'No student is below the minimum attendance.', late: 'No late entries match the filters.', daily: 'No attendance was marked on this date.' }[this.tab] as string;
  }

  ngOnInit() {
    this.api.get('/admin/meta').subscribe({ next: (m) => (this.meta = m), error: () => {} });
    this.api.get('/admin/subjects').subscribe({ next: (s) => (this.subjects = s), error: () => {} });
    this.load();
  }
  setTab(t: string) { this.tab = t; this.load(); }
  load() {
    this.loading = true;
    const url = `/admin/monitoring/${this.tab}`;
    this.api.get(url, { department: this.department, semester: this.semester, subject: this.subject, from: this.from, to: this.to, date: this.date }).subscribe({
      next: (r) => { this.rows = r.rows; this.summary = r.summary || []; if (r.settings) this.min = r.settings.minAttendance; this.loading = false; },
      error: (e) => { this.loading = false; this.toast.error(errMsg(e)); },
    });
  }
  export() {
    this.api.download('/admin/monitoring/shortage/export', { department: this.department, semester: this.semester, subject: this.subject }, 'attendance-shortage.csv');
  }
}
