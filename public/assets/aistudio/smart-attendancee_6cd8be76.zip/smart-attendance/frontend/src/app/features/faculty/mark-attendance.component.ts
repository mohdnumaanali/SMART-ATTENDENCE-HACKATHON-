import { Component, OnInit, inject } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { ToastService, errMsg } from '../../core/toast.service';
import { todayLocal } from '../../shared/util';

@Component({
  selector: 'app-mark-attendance',
  standalone: true,
  imports: [FormsModule, RouterLink],
  template: `
    <div class="page-head"><div><h2>Mark Attendance</h2><p>Select the class, load the student list, then submit</p></div></div>
    <div class="card">
      <div class="filters">
        <label>Subject
          <select [(ngModel)]="subjectId" (ngModelChange)="onSubject()">
            <option value="">Select subject</option>
            @for (s of subjects; track s._id) { <option [value]="s._id">{{ s.code }} - {{ s.name }}</option> }
          </select>
        </label>
        <label>Class / section
          <select [(ngModel)]="section" (ngModelChange)="reset()" [disabled]="!subject">
            <option value="">Select section</option>
            @for (sec of subject?.sections || []; track sec) { <option [value]="sec">Section {{ sec }}</option> }
          </select>
        </label>
        <label>Date<input type="date" [(ngModel)]="date" [max]="today" (ngModelChange)="reset()" /></label>
        <label>Period
          <select [(ngModel)]="period" (ngModelChange)="reset()">
            @for (p of periods; track p) { <option [ngValue]="p">Period {{ p }}</option> }
          </select>
        </label>
        <button class="btn primary" [disabled]="!subjectId || !section || !date || loading" (click)="load()">{{ loading ? 'Loading...' : 'Load students' }}</button>
      </div>

      @if (!subjects.length && ready) { <div class="empty"><strong>No subjects assigned</strong>Ask the administrator to assign subjects to you.</div> }
      @if (alreadyMarked) {
        <div class="alert warn">Attendance for this class is already marked. To fix a mistake, open <a routerLink="/faculty/records">Attendance Records</a>.</div>
      }
      @if (students.length && !alreadyMarked) {
        <div class="row" style="margin:6px 0 12px">
          <strong>{{ students.length }} students</strong>
          <span class="spacer"></span>
          <button class="btn sm" (click)="setAll('Present')">All present</button>
          <button class="btn sm" (click)="setAll('Absent')">All absent</button>
        </div>
        <div class="table-wrap"><table>
          <thead><tr><th>Roll number</th><th>Student</th><th>Attendance</th></tr></thead>
          <tbody>
            @for (s of students; track s._id) {
              <tr>
                <td>{{ s.rollNumber }}</td><td>{{ s.name }}</td>
                <td>
                  <div class="seg">
                    <label><input type="radio" [name]="'st' + s._id" value="Present" [(ngModel)]="s.status" /><span class="P">Present</span></label>
                    <label><input type="radio" [name]="'st' + s._id" value="Late" [(ngModel)]="s.status" /><span class="L">Late</span></label>
                    <label><input type="radio" [name]="'st' + s._id" value="Absent" [(ngModel)]="s.status" /><span class="A">Absent</span></label>
                  </div>
                </td>
              </tr>
            }
          </tbody>
        </table></div>
        <div class="sticky-bar">
          <span><b style="color:var(--ok)">{{ count('Present') }}</b> present</span>
          <span><b style="color:var(--warn)">{{ count('Late') }}</b> late</span>
          <span><b style="color:var(--bad)">{{ count('Absent') }}</b> absent</span>
          <span class="muted">{{ unmarked }} not marked</span>
          <span class="spacer"></span>
          <button class="btn primary" [disabled]="saving || unmarked > 0" (click)="submit()">{{ saving ? 'Saving...' : 'Submit attendance' }}</button>
        </div>
      }
      @if (loaded && !students.length) { <div class="empty"><strong>No students in this section</strong>Add students to this department, semester and section first.</div> }
    </div>`,
})
export class MarkAttendanceComponent implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  private route = inject(ActivatedRoute);
  today = todayLocal();
  periods = [1, 2, 3, 4, 5, 6, 7, 8];
  subjects: any[] = [];
  subjectId = '';
  section = '';
  date = todayLocal();
  period = 1;
  students: any[] = [];
  alreadyMarked = false;
  loaded = false;
  loading = false;
  saving = false;
  ready = false;

  get subject() { return this.subjects.find((s) => s._id === this.subjectId); }
  get unmarked() { return this.students.filter((s) => !s.status).length; }
  count = (st: string) => this.students.filter((s) => s.status === st).length;

  ngOnInit() {
    this.api.get('/faculty/subjects').subscribe({
      next: (s) => {
        this.subjects = s; this.ready = true;
        const pre = this.route.snapshot.queryParamMap.get('subject');
        if (pre && s.some((x: any) => x._id === pre)) { this.subjectId = pre; this.onSubject(); }
      },
      error: (e) => this.toast.error(errMsg(e)),
    });
  }
  onSubject() { this.section = this.subject?.sections.length === 1 ? this.subject.sections[0] : ''; this.reset(); }
  reset() { this.students = []; this.alreadyMarked = false; this.loaded = false; }

  load() {
    this.loading = true;
    this.api.get(`/faculty/subjects/${this.subjectId}/students`, { section: this.section, date: this.date, period: this.period }).subscribe({
      next: (r) => {
        this.alreadyMarked = r.alreadyMarked;
        this.students = r.students.map((s: any) => ({ ...s, status: null }));
        this.loaded = true; this.loading = false;
      },
      error: (e) => { this.loading = false; this.toast.error(errMsg(e)); },
    });
  }
  setAll(status: string) { this.students.forEach((s) => (s.status = status)); }

  submit() {
    const msg = `Submit attendance for ${this.subject.code}, section ${this.section}, ${this.date}, period ${this.period}?\n\nPresent ${this.count('Present')}, Late ${this.count('Late')}, Absent ${this.count('Absent')}`;
    if (!confirm(msg)) return;
    this.saving = true;
    this.api.post('/faculty/attendance', {
      subject: this.subjectId, section: this.section, date: this.date, period: this.period,
      records: this.students.map((s) => ({ student: s._id, status: s.status })),
    }).subscribe({
      next: (r) => {
        this.saving = false;
        this.toast.success(`Attendance saved: ${r.summary.present} present, ${r.summary.late} late, ${r.summary.absent} absent`);
        this.reset();
        this.period = Math.min(this.period + 1, 8);
      },
      error: (e) => { this.saving = false; this.toast.error(errMsg(e)); },
    });
  }
}
