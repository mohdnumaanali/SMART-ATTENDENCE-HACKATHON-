import { Component, OnInit, inject } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { ToastService, errMsg } from '../../core/toast.service';
import { PagerComponent } from '../../shared/pager.component';

@Component({
  selector: 'app-student-history',
  standalone: true,
  imports: [FormsModule, DatePipe, PagerComponent],
  template: `
    <div class="page-head"><div><h2>Attendance History</h2><p>Every class recorded for you</p></div></div>
    <div class="card">
      <div class="filters">
        <label>Subject
          <select [(ngModel)]="f.subject" (ngModelChange)="load(1)">
            <option value="">All subjects</option>
            @for (s of subjects; track s.subjectId) { <option [value]="s.subjectId">{{ s.code }} - {{ s.name }}</option> }
          </select>
        </label>
        <label>Status
          <select [(ngModel)]="f.status" (ngModelChange)="load(1)">
            <option value="">All</option><option>Present</option><option>Late</option><option>Absent</option>
          </select>
        </label>
        <label>From<input type="date" [(ngModel)]="f.from" (ngModelChange)="load(1)" /></label>
        <label>To<input type="date" [(ngModel)]="f.to" (ngModelChange)="load(1)" /></label>
        <button class="btn" (click)="reset()">Clear</button>
      </div>
      @if (loading) { <div class="spinner-wrap"><div class="spinner"></div></div> }
      @else if (!res.data.length) { <div class="empty"><strong>No records found</strong>Try changing the filters.</div> }
      @else {
        <div class="table-wrap"><table>
          <thead><tr><th>Date</th><th>Period</th><th>Subject</th><th>Faculty</th><th>Status</th></tr></thead>
          <tbody>
            @for (r of res.data; track r._id) {
              <tr>
                <td>{{ r.date | date:'dd MMM yyyy':'UTC' }}</td><td>{{ r.period }}</td>
                <td>{{ r.subject?.name }} <span class="muted">({{ r.subject?.code }})</span></td>
                <td>{{ r.faculty || '-' }}</td>
                <td><span class="badge {{ r.status }}">{{ r.status }}</span></td>
              </tr>
            }
          </tbody>
        </table></div>
        <app-pager [page]="res.page" [pages]="res.pages" [total]="res.total" (pageChange)="load($event)" />
      }
    </div>`,
})
export class StudentHistoryComponent implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  loading = true;
  subjects: any[] = [];
  res: any = { data: [], page: 1, pages: 1, total: 0 };
  f = { subject: '', status: '', from: '', to: '' };

  ngOnInit() {
    this.api.get('/student/summary').subscribe({ next: (d) => (this.subjects = d.subjects), error: () => {} });
    this.load(1);
  }
  load(page: number) {
    this.loading = true;
    this.api.get('/student/history', { ...this.f, page, limit: 15 }).subscribe({
      next: (r) => { this.res = r; this.loading = false; },
      error: (e) => { this.loading = false; this.toast.error(errMsg(e)); },
    });
  }
  reset() { this.f = { subject: '', status: '', from: '', to: '' }; this.load(1); }
}
