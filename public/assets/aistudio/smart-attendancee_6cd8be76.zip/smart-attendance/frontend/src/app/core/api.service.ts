import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { API_URL } from './config';
import { ToastService } from './toast.service';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private http = inject(HttpClient);
  private toast = inject(ToastService);

  private params(p?: Record<string, any>) {
    let hp = new HttpParams();
    Object.entries(p || {}).forEach(([k, v]) => {
      if (v !== null && v !== undefined && v !== '') hp = hp.set(k, String(v));
    });
    return hp;
  }
  get<T = any>(url: string, p?: Record<string, any>) { return this.http.get<T>(API_URL + url, { params: this.params(p) }); }
  post<T = any>(url: string, body: any = {}) { return this.http.post<T>(API_URL + url, body); }
  put<T = any>(url: string, body: any = {}) { return this.http.put<T>(API_URL + url, body); }
  delete<T = any>(url: string, p?: Record<string, any>) { return this.http.delete<T>(API_URL + url, { params: this.params(p) }); }

  download(url: string, p: Record<string, any>, filename: string) {
    this.http.get(API_URL + url, { params: this.params(p), responseType: 'blob' }).subscribe({
      next: (blob) => {
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = filename;
        a.click();
        URL.revokeObjectURL(a.href);
        this.toast.success('Export downloaded');
      },
      error: () => this.toast.error('Export failed. Please try again.'),
    });
  }
}
