import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { ToastService, errMsg } from '../../core/toast.service';

@Component({
  selector: 'app-student-profile',
  standalone: true,
  imports: [FormsModule],
  template: `
    <div class="page-head"><div><h2>My Profile</h2></div></div>
    <div class="grid g2">
      <div class="card">
        <div class="card-head"><h3>Student details</h3></div>
        @if (p) {
          <div class="form-grid">
            <div><div class="muted">Name</div><strong>{{ p.name }}</strong></div>
            <div><div class="muted">Roll number</div><strong>{{ p.rollNumber }}</strong></div>
            <div><div class="muted">Department</div><strong>{{ p.department }}</strong></div>
            <div><div class="muted">Semester</div><strong>{{ p.semester }}</strong></div>
            <div><div class="muted">Section</div><strong>{{ p.section }}</strong></div>
            <div><div class="muted">Email</div><strong>{{ p.email }}</strong></div>
          </div>
        } @else { <div class="spinner-wrap"><div class="spinner"></div></div> }
      </div>
      <div class="card">
        <div class="card-head"><h3>Change password</h3></div>
        <form class="stack" (ngSubmit)="change()">
          <label>Current password<input type="password" name="cur" [(ngModel)]="cur" autocomplete="current-password" /></label>
          <label>New password (min 8 characters)<input type="password" name="nw" [(ngModel)]="nw" autocomplete="new-password" /></label>
          <label>Confirm new password<input type="password" name="cf" [(ngModel)]="cf" autocomplete="new-password" /></label>
          <button class="btn primary" [disabled]="busy || !cur || !nw">Update password</button>
        </form>
      </div>
    </div>`,
})
export class StudentProfileComponent implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  p: any;
  cur = ''; nw = ''; cf = ''; busy = false;

  ngOnInit() {
    this.api.get('/student/profile').subscribe({ next: (p) => (this.p = p), error: (e) => this.toast.error(errMsg(e)) });
  }
  change() {
    if (this.nw.length < 8) return this.toast.error('New password must be at least 8 characters');
    if (this.nw !== this.cf) return this.toast.error('New passwords do not match');
    this.busy = true;
    this.api.put('/auth/change-password', { currentPassword: this.cur, newPassword: this.nw }).subscribe({
      next: () => { this.busy = false; this.cur = this.nw = this.cf = ''; this.toast.success('Password updated'); },
      error: (e) => { this.busy = false; this.toast.error(errMsg(e)); },
    });
  }
}
