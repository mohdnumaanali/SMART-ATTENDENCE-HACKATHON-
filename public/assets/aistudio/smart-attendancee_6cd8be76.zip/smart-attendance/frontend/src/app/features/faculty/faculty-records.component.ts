import { Component, OnInit, inject } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { forkJoin } from 'rxjs';
import { ApiService } from '../../core/api.service';
import { ToastService, errMsg } from '../../core/toast.service';
import { ModalComponent } from '../../shared/modal.component';
import { PagerComponent } from '../../shared/pager.component';

@Component({
  selector: 'app-faculty-records',
  standalone: true,
  imports: [FormsModule, DatePipe, ModalComponent, PagerComponent],
  template: `
    <div class="page-head"><div><h2>Attendance Records</h2><p>Review past classes and correct mistakes. Corrections need a reason and are logged.</p></div></div>
    <div class="card">
      <div class="filters">
        <label>Subject
          <select [(ngModel)]="f.subject" (ngModelChange)="load(1)">
            <option value="">All my subjects</option>
            @for (s of subjects; track s._id) { <option [value]="s._id">{{ s.code }} - {{ s.name }}</option> }
          </select>
        </label>
        <label>From<input type="date" [(ngModel)]="f.from" (ngModelChange)="load(1)" /></label>
        <label>To<input type="date" [(ngModel)]="f.to" (ngModelChange)="load(1)" /></label>
      </div>
      @if (loading) { <div class="spinner-wrap"><div class="spinner"></div></div> }
      @else if (!res.data.length) { <div class="empty"><strong>No attendance records</strong>Marked classes will be listed here.</div> }
      @else {
        <div class="table-wrap"><table>
          <thead><tr><th>Date</th><th>Period</th><th>Subject</th><th>Section</th><th class="num">Present</th><th class="num">Late</th><th class="num">Absent</th><th></th></tr></thead>
          <tbody>
            @for (r of res.data; track $index) {
              <tr>
                <td>{{ r.date | date:'dd MMM yyyy':'UTC' }}</td><td>{{ r.period }}</td><td>{{ r.subject.code }} - {{ r.subject.name }}</td><td>{{ r.section }}</td>
                <td class="num">{{ r.present }}</td><td class="num">{{ r.late }}</td><td class="num">{{ r.absent }}</td>
                <td class="actions">@if (r.edited) { <span class="badge warn">Edited</span> }<button class="btn sm" (click)="open(r)">View / correct</button></td>
              </tr>
            }
          </tbody>
        </table></div>
        <app-pager [page]="res.page" [pages]="res.pages" [total]="res.total" (pageChange)="load($event)" />
      }
    </div>

    @if (detail) {
      <app-modal [title]="detail.subject.code + ' - section ' + detail.section + ', period ' + detail.period" [wide]="true" (close)="detail = null">
        <p class="muted" style="margin-top:0">{{ detail.date | date:'dd MMM yyyy':'UTC' }}. Faculty can correct records for 7 days; older records need an administrator.</p>
        <div class="table-wrap"><table>
          <thead><tr><th>Roll number</th><th>Student</th><th>Status</th></tr></thead>
          <tbody>
            @for (r of detail.records; track r._id) {
              <tr>
                <td>{{ r.student.rollNumber }}</td><td>{{ r.student.name }}
                  @if (r.editCount) { <span class="badge warn">edited {{ r.editCount }}x</span> }</td>
                <td>
                  <select [(ngModel)]="r.newStatus">
                    <option>Present</option><option>Late</option><option>Absent</option>
                  </select>
                  @if (r.newStatus !== r.status) { <span class="muted">was {{ r.status }}</span> }
                </td>
              </tr>
            }
          </tbody>
        </table></div>
        <label style="margin-top:14px">Reason for correction (required)
          <input [(ngModel)]="reason" maxlength="300" placeholder="e.g. Marked wrong student by mistake" />
        </label>
        <div class="modal-foot">
          <button class="btn" (click)="detail = null">Cancel</button>
          <button class="btn primary" [disabled]="saving || !changed.length" (click)="save()">{{ saving ? 'Saving...' : 'Save ' + changed.length + ' correction(s)' }}</button>
        </div>
      </app-modal>
    }`,
})
export class FacultyRecordsComponent implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  loading = true;
  saving = false;
  subjects: any[] = [];
  res: any = { data: [], page: 1, pages: 1, total: 0 };
  f = { subject: '', from: '', to: '' };
  detail: any = null;
  reason = '';
  private page = 1;

  get changed() { return this.detail ? this.detail.records.filter((r: any) => r.newStatus !== r.status) : []; }

  ngOnInit() {
    this.api.get('/faculty/subjects').subscribe({ next: (s) => (this.subjects = s), error: () => {} });
    this.load(1);
  }
  load(page: number) {
    this.page = page;
    this.loading = true;
    this.api.get('/faculty/attendance/sessions', { ...this.f, page, limit: 15 }).subscribe({
      next: (r) => { this.res = r; this.loading = false; },
      error: (e) => { this.loading = false; this.toast.error(errMsg(e)); },
    });
  }
  open(r: any) {
    this.api.get('/faculty/attendance/session', {
      subject: r.subject._id, section: r.section, date: r.date.slice(0, 10), period: r.period,
    }).subscribe({
      next: (d) => { d.records.forEach((x: any) => (x.newStatus = x.status)); this.detail = d; this.reason = ''; },
      error: (e) => this.toast.error(errMsg(e)),
    });
  }
  save() {
    if (this.reason.trim().length < 3) return this.toast.error('Enter a reason for the correction');
    this.saving = true;
    forkJoin(this.changed.map((r: any) => this.api.put(`/faculty/attendance/${r._id}`, { status: r.newStatus, reason: this.reason }))).subscribe({
      next: () => { this.saving = false; this.detail = null; this.toast.success('Attendance corrected'); this.load(this.page); },
      error: (e) => { this.saving = false; this.toast.error(errMsg(e)); },
    });
  }
}
