import { Component, OnDestroy, OnInit, inject, signal } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs';
import { AuthService } from '../core/auth.service';
import { NotifyService } from '../core/notify.service';
import { IconComponent } from './icon.component';

interface NavItem { path: string; label: string; icon: string; }

const NAV: Record<string, NavItem[]> = {
  student: [
    { path: 'dashboard', label: 'Dashboard', icon: 'grid' },
    { path: 'eligibility', label: 'Eligibility Calculator', icon: 'percent' },
    { path: 'history', label: 'Attendance History', icon: 'clock' },
    { path: 'notifications', label: 'Notifications', icon: 'bell' },
    { path: 'profile', label: 'My Profile', icon: 'user' },
  ],
  faculty: [
    { path: 'overview', label: 'Overview', icon: 'grid' },
    { path: 'mark', label: 'Mark Attendance', icon: 'check' },
    { path: 'students', label: 'Student Records', icon: 'users' },
    { path: 'records', label: 'Attendance Records', icon: 'clock' },
    { path: 'reports', label: 'Reports', icon: 'file' },
    { path: 'announcements', label: 'Announcements', icon: 'send' },
  ],
  admin: [
    { path: 'overview', label: 'Overview', icon: 'grid' },
    { path: 'students', label: 'Students', icon: 'users' },
    { path: 'faculty', label: 'Faculty', icon: 'user' },
    { path: 'subjects', label: 'Subjects', icon: 'book' },
    { path: 'enrollments', label: 'Enrollments', icon: 'check' },
    { path: 'monitoring', label: 'Attendance Monitoring', icon: 'alert' },
    { path: 'analytics', label: 'Reports & Analytics', icon: 'chart' },
    { path: 'settings', label: 'System Settings', icon: 'settings' },
  ],
};
const PORTAL: Record<string, string> = { student: 'Student Portal', faculty: 'Faculty Portal', admin: 'Administration' };

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, IconComponent],
  template: `
    <div class="shell">
      <aside class="sidebar" [class.open]="open()">
        <div class="brand">
          <div class="brand-mark"><app-icon name="check" [size]="16" /></div>
          <div><strong>Smart Attendance</strong><small>{{ portal }}</small></div>
        </div>
        <nav>
          @for (n of nav; track n.path) {
            <a [routerLink]="'/' + role + '/' + n.path" routerLinkActive="active" (click)="open.set(false)">
              <app-icon [name]="n.icon" /> <span>{{ n.label }}</span>
              @if (n.path === 'notifications' && notify.unread() > 0) { <em class="count">{{ notify.unread() }}</em> }
            </a>
          }
        </nav>
        <div class="side-foot">
          <div class="who"><strong>{{ auth.user()?.name }}</strong><small>{{ auth.user()?.email }}</small></div>
          <button class="btn ghost block" (click)="auth.logout()"><app-icon name="logout" /> Sign out</button>
        </div>
      </aside>
      @if (open()) { <div class="scrim" (click)="open.set(false)"></div> }
      <div class="main">
        <header class="topbar">
          <button class="icon-btn menu-btn" (click)="open.set(!open())" aria-label="Menu"><app-icon name="menu" /></button>
          <span class="topbar-title">{{ title() }}</span>
          <span class="spacer"></span>
          @if (role === 'student') {
            <a class="icon-btn bell" [routerLink]="'/student/notifications'" aria-label="Notifications">
              <app-icon name="bell" />
              @if (notify.unread() > 0) { <em class="dot">{{ notify.unread() > 9 ? '9+' : notify.unread() }}</em> }
            </a>
          }
        </header>
        <main class="content"><router-outlet /></main>
      </div>
    </div>`,
})
export class ShellComponent implements OnInit, OnDestroy {
  auth = inject(AuthService);
  notify = inject(NotifyService);
  private router = inject(Router);
  open = signal(false);
  title = signal('');
  role = this.auth.user()?.role || 'student';
  nav = NAV[this.role];
  portal = PORTAL[this.role];
  private timer?: any;

  ngOnInit() {
    this.setTitle(this.router.url);
    this.router.events.pipe(filter((e) => e instanceof NavigationEnd)).subscribe((e: any) => this.setTitle(e.urlAfterRedirects));
    if (this.role === 'student') {
      this.notify.refresh();
      this.timer = setInterval(() => this.notify.refresh(), 60000);
    }
  }
  ngOnDestroy() { clearInterval(this.timer); }

  private setTitle(url: string) {
    const seg = url.split('?')[0].split('/')[2];
    this.title.set(this.nav.find((n) => n.path === seg)?.label || '');
  }
}
