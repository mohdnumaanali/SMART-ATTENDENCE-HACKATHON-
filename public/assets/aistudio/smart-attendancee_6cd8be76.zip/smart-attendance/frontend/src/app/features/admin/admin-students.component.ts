import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { ToastService, errMsg } from '../../core/toast.service';
import { IconComponent } from '../../shared/icon.component';
import { ModalComponent } from '../../shared/modal.component';
import { PagerComponent } from '../../shared/pager.component';

const BLANK = { name: '', email: '', password: '', rollNumber: '', department: '', semester: 1, section: '' };

@Component({
  selector: 'app-admin-students',
  standalone: true,
  imports: [FormsModule, IconComponent, ModalComponent, PagerComponent],
  template: `
    <div class="page-head">
      <div><h2>Students</h2><p>Add, edit and manage student accounts</p></div><span class="spacer"></span>
      <button class="btn primary" (click)="openForm()"><app-icon name="plus" /> Add student</button>
    </div>
    <div class="card">
      <div class="filters">
        <div class="search"><app-icon name="search" [size]="15" /><input placeholder="Search name, email or roll no." [(ngModel)]="f.q" (ngModelChange)="load(1)" /></div>
        <label>Department<select [(ngModel)]="f.department" (ngModelChange)="load(1)"><option value="">All</option>@for (d of meta.departments; track d) { <option>{{ d }}</option> }</select></label>
        <label>Semester<select [(ngModel)]="f.semester" (ngModelChange)="load(1)"><option value="">All</option>@for (s of meta.semesters; track s) { <option [value]="s">{{ s }}</option> }</select></label>
        <label>Section<select [(ngModel)]="f.section" (ngModelChange)="load(1)"><option value="">All</option>@for (s of meta.sections; track s) { <option>{{ s }}</option> }</select></label>
        <label>Status<select [(ngModel)]="f.status" (ngModelChange)="load(1)"><option value="">All</option><option value="active">Active</option><option value="inactive">Inactive</option></select></label>
      </div>
      @if (loading) { <div class="spinner-wrap"><div class="spinner"></div></div> }
      @else if (!res.data.length) { <div class="empty"><strong>No students found</strong>Add a student or adjust the filters.</div> }
      @else {
        <div class="table-wrap"><table>
          <thead><tr><th>Roll number</th><th>Name</th><th>Email</th><th>Department</th><th>Sem</th><th>Sec</th><th>Status</th><th></th></tr></thead>
          <tbody>
            @for (s of res.data; track s._id) {
              <tr>
                <td>{{ s.rollNumber }}</td><td>{{ s.name }}</td><td>{{ s.email }}</td><td>{{ s.department }}</td><td>{{ s.semester }}</td><td>{{ s.section }}</td>
                <td><span class="badge {{ s.isActive ? 'active' : 'inactive' }}">{{ s.isActive ? 'Active' : 'Inactive' }}</span></td>
                <td class="actions">
                  <button class="icon-btn" title="Edit" (click)="openForm(s)"><app-icon name="edit" /></button>
                  <button class="btn sm" (click)="toggle(s)">{{ s.isActive ? 'Deactivate' : 'Activate' }}</button>
                  <button class="icon-btn" title="Delete permanently" (click)="remove(s)"><app-icon name="trash" /></button>
                </td>
              </tr>
            }
          </tbody>
        </table></div>
        <app-pager [page]="res.page" [pages]="res.pages" [total]="res.total" (pageChange)="load($event)" />
      }
    </div>

    @if (form) {
      <app-modal [title]="editId ? 'Edit student' : 'Add student'" (close)="form = null">
        <form (ngSubmit)="save()">
          <div class="form-grid">
            <label class="full">Full name<input name="name" [(ngModel)]="form.name" required /></label>
            <label>Email<input type="email" name="email" [(ngModel)]="form.email" required /></label>
            <label>{{ editId ? 'New password (optional)' : 'Password' }}<input type="password" name="pw" [(ngModel)]="form.password" autocomplete="new-password" [required]="!editId" minlength="8" placeholder="Min 8 characters" /></label>
            <label>Roll number<input name="roll" [(ngModel)]="form.rollNumber" required /></label>
            <label>Department<input name="dept" [(ngModel)]="form.department" list="depts" required /></label>
            <label>Semester<input type="number" name="sem" [(ngModel)]="form.semester" min="1" max="12" required /></label>
            <label>Section<input name="sec" [(ngModel)]="form.section" list="secs" required maxlength="3" /></label>
          </div>
          <datalist id="depts">@for (d of meta.departments; track d) { <option [value]="d"></option> }</datalist>
          <datalist id="secs">@for (d of meta.sections; track d) { <option [value]="d"></option> }</datalist>
          <div class="modal-foot"><button type="button" class="btn" (click)="form = null">Cancel</button><button class="btn primary" [disabled]="saving">{{ saving ? 'Saving...' : 'Save' }}</button></div>
        </form>
      </app-modal>
    }`,
})
export class AdminStudentsComponent implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  loading = true; saving = false;
  res: any = { data: [], page: 1, pages: 1, total: 0 };
  meta: any = { departments: [], semesters: [], sections: [] };
  f = { q: '', department: '', semester: '', section: '', status: '' };
  form: any = null;
  editId = '';
  private page = 1;

  ngOnInit() { this.loadMeta(); this.load(1); }
  loadMeta() { this.api.get('/admin/meta').subscribe({ next: (m) => (this.meta = m), error: () => {} }); }
  load(page: number) {
    this.page = page; this.loading = true;
    this.api.get('/admin/students', { ...this.f, page, limit: 15 }).subscribe({
      next: (r) => { this.res = r; this.loading = false; },
      error: (e) => { this.loading = false; this.toast.error(errMsg(e)); },
    });
  }
  openForm(s?: any) {
    this.editId = s ? s._id : '';
    this.form = s ? { ...s, password: '' } : { ...BLANK };
  }
  save() {
    const f = this.form;
    if (!f.name || !f.email || !f.rollNumber || !f.department || !f.section) return this.toast.error('Fill in all required fields');
    if (!this.editId && (f.password || '').length < 8) return this.toast.error('Password must be at least 8 characters');
    const body: any = { name: f.name, email: f.email, rollNumber: f.rollNumber, department: f.department, semester: Number(f.semester), section: f.section };
    if (f.password) body.password = f.password;
    this.saving = true;
    const req = this.editId ? this.api.put(`/admin/students/${this.editId}`, body) : this.api.post('/admin/students', body);
    req.subscribe({
      next: () => { this.saving = false; this.form = null; this.toast.success(this.editId ? 'Student updated' : 'Student added'); this.load(this.page); this.loadMeta(); },
      error: (e) => { this.saving = false; this.toast.error(errMsg(e)); },
    });
  }
  toggle(s: any) {
    this.api.put(`/admin/students/${s._id}`, { isActive: !s.isActive }).subscribe({
      next: () => { this.toast.success(s.isActive ? 'Student deactivated' : 'Student activated'); this.load(this.page); },
      error: (e) => this.toast.error(errMsg(e)),
    });
  }
  remove(s: any) {
    if (!confirm(`Permanently delete ${s.name} (${s.rollNumber}) and ALL their attendance records? This cannot be undone.\n\nUse Deactivate to keep records.`)) return;
    this.api.delete(`/admin/students/${s._id}`, { permanent: true }).subscribe({
      next: () => { this.toast.success('Student deleted'); this.load(this.page); },
      error: (e) => this.toast.error(errMsg(e)),
    });
  }
}
