import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, throwError } from 'rxjs';
import { AuthService } from './auth.service';
import { ToastService } from './toast.service';
import { API_URL } from './config';
import { Router } from '@angular/router';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const toast = inject(ToastService);
  const router = inject(Router);
  const token = auth.token;
  const isApi = req.url.startsWith(API_URL);
  const authed = token && isApi ? req.clone({ setHeaders: { Authorization: `Bearer ${token}` } }) : req;

  return next(authed).pipe(
    catchError((err) => {
      if (err.status === 401 && isApi && !req.url.endsWith('/auth/login')) {
        auth.clear();
        toast.error('Your session has expired. Please sign in again.');
        router.navigate(['/login']);
      } else if (err.status === 0) {
        toast.error('Cannot reach the server. Check your connection.');
      }
      return throwError(() => err);
    })
  );
};
