import { Routes } from '@angular/router';
import { guestGuard, roleGuard } from './core/guards';
import { ShellComponent } from './shared/shell.component';

export const routes: Routes = [
  { path: 'login', canActivate: [guestGuard], loadComponent: () => import('./features/auth/login.component').then((m) => m.LoginComponent) },
  {
    path: 'student', component: ShellComponent, canActivate: [roleGuard('student')],
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      { path: 'dashboard', loadComponent: () => import('./features/student/student-dashboard.component').then((m) => m.StudentDashboardComponent) },
      { path: 'eligibility', loadComponent: () => import('./features/student/student-eligibility.component').then((m) => m.StudentEligibilityComponent) },
      { path: 'history', loadComponent: () => import('./features/student/student-history.component').then((m) => m.StudentHistoryComponent) },
      { path: 'notifications', loadComponent: () => import('./features/student/notifications.component').then((m) => m.NotificationsComponent) },
      { path: 'profile', loadComponent: () => import('./features/student/student-profile.component').then((m) => m.StudentProfileComponent) },
    ],
  },
  {
    path: 'faculty', component: ShellComponent, canActivate: [roleGuard('faculty')],
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'overview' },
      { path: 'overview', loadComponent: () => import('./features/faculty/faculty-overview.component').then((m) => m.FacultyOverviewComponent) },
      { path: 'mark', loadComponent: () => import('./features/faculty/mark-attendance.component').then((m) => m.MarkAttendanceComponent) },
      { path: 'students', loadComponent: () => import('./features/faculty/faculty-students.component').then((m) => m.FacultyStudentsComponent) },
      { path: 'records', loadComponent: () => import('./features/faculty/faculty-records.component').then((m) => m.FacultyRecordsComponent) },
      { path: 'reports', loadComponent: () => import('./features/faculty/faculty-reports.component').then((m) => m.FacultyReportsComponent) },
      { path: 'announcements', loadComponent: () => import('./features/faculty/faculty-announcements.component').then((m) => m.FacultyAnnouncementsComponent) },
    ],
  },
  {
    path: 'admin', component: ShellComponent, canActivate: [roleGuard('admin')],
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'overview' },
      { path: 'overview', loadComponent: () => import('./features/admin/admin-overview.component').then((m) => m.AdminOverviewComponent) },
      { path: 'students', loadComponent: () => import('./features/admin/admin-students.component').then((m) => m.AdminStudentsComponent) },
      { path: 'faculty', loadComponent: () => import('./features/admin/admin-faculty.component').then((m) => m.AdminFacultyComponent) },
      { path: 'subjects', loadComponent: () => import('./features/admin/admin-subjects.component').then((m) => m.AdminSubjectsComponent) },
      { path: 'enrollments', loadComponent: () => import('./features/admin/admin-enrollments.component').then((m) => m.AdminEnrollmentsComponent) },
      { path: 'monitoring', loadComponent: () => import('./features/admin/admin-monitoring.component').then((m) => m.AdminMonitoringComponent) },
      { path: 'analytics', loadComponent: () => import('./features/admin/admin-analytics.component').then((m) => m.AdminAnalyticsComponent) },
      { path: 'settings', loadComponent: () => import('./features/admin/admin-settings.component').then((m) => m.AdminSettingsComponent) },
    ],
  },
  { path: '', pathMatch: 'full', redirectTo: 'login' },
  { path: '**', redirectTo: 'login' },
];
