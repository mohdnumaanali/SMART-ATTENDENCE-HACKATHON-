import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { ToastService, errMsg } from '../../core/toast.service';
import { IconComponent } from '../../shared/icon.component';
import { ModalComponent } from '../../shared/modal.component';

const BLANK = { name: '', email: '', password: '', employeeId: '', department: '', designation: 'Assistant Professor', subjects: [] as string[] };

@Component({
  selector: 'app-admin-faculty',
  standalone: true,
  imports: [FormsModule, IconComponent, ModalComponent],
  template: `
    <div class="page-head">
      <div><h2>Faculty</h2><p>Manage faculty accounts and subject assignments</p></div><span class="spacer"></span>
      <button class="btn primary" (click)="openForm()"><app-icon name="plus" /> Add faculty</button>
    </div>
    <div class="card">
      <div class="filters"><div class="search"><app-icon name="search" [size]="15" /><input placeholder="Search name, email or employee ID" [(ngModel)]="q" /></div></div>
      @if (loading) { <div class="spinner-wrap"><div class="spinner"></div></div> }
      @else if (!filtered.length) { <div class="empty"><strong>No faculty found</strong>Add a faculty member to get started.</div> }
      @else {
        <div class="table-wrap"><table>
          <thead><tr><th>Employee ID</th><th>Name</th><th>Department</th><th>Assigned subjects</th><th>Status</th><th></th></tr></thead>
          <tbody>
            @for (f of filtered; track f._id) {
              <tr>
                <td>{{ f.employeeId }}</td><td>{{ f.name }}<div class="muted">{{ f.email }}</div></td><td>{{ f.department }}</td>
                <td class="wrap">@for (s of f.subjects; track s._id) { <span class="badge info" style="margin:0 4px 4px 0">{{ s.code }} ({{ s.sections.join(',') }})</span> } @if (!f.subjects.length) { <span class="muted">None</span> }</td>
                <td><span class="badge {{ f.isActive ? 'active' : 'inactive' }}">{{ f.isActive ? 'Active' : 'Inactive' }}</span></td>
                <td class="actions">
                  <button class="icon-btn" title="Edit" (click)="openForm(f)"><app-icon name="edit" /></button>
                  <button class="btn sm" (click)="toggle(f)">{{ f.isActive ? 'Deactivate' : 'Activate' }}</button>
                  <button class="icon-btn" title="Delete" (click)="remove(f)"><app-icon name="trash" /></button>
                </td>
              </tr>
            }
          </tbody>
        </table></div>
      }
    </div>

    @if (form) {
      <app-modal [title]="editId ? 'Edit faculty' : 'Add faculty'" [wide]="true" (close)="form = null">
        <form (ngSubmit)="save()">
          <div class="form-grid">
            <label>Full name<input name="name" [(ngModel)]="form.name" required /></label>
            <label>Email<input type="email" name="email" [(ngModel)]="form.email" required /></label>
            <label>{{ editId ? 'New password (optional)' : 'Password' }}<input type="password" name="pw" [(ngModel)]="form.password" autocomplete="new-password" placeholder="Min 8 characters" /></label>
            <label>Employee ID<input name="eid" [(ngModel)]="form.employeeId" required /></label>
            <label>Department<input name="dept" [(ngModel)]="form.department" list="fdepts" required /></label>
            <label>Designation<input name="des" [(ngModel)]="form.designation" /></label>
            <div class="full"><div style="font-weight:500;font-size:13px;margin-bottom:5px">Assign subjects (sections are set on the subject)</div>
              <div class="checklist">
                @for (s of subjects; track s._id) {
                  <label class="check"><input type="checkbox" [checked]="form.subjects.includes(s._id)" (change)="pick(s._id, $any($event.target).checked)" />
                    {{ s.code }} - {{ s.name }} <span class="muted">(sem {{ s.semester }}, sec {{ s.sections.join(',') }}{{ s.faculty && s.faculty._id !== editId ? '; currently ' + s.faculty.name : '' }})</span></label>
                }
                @if (!subjects.length) { <span class="muted">No subjects yet. Create subjects first.</span> }
              </div>
            </div>
          </div>
          <datalist id="fdepts">@for (d of depts; track d) { <option [value]="d"></option> }</datalist>
          <div class="modal-foot"><button type="button" class="btn" (click)="form = null">Cancel</button><button class="btn primary" [disabled]="saving">{{ saving ? 'Saving...' : 'Save' }}</button></div>
        </form>
      </app-modal>
    }`,
})
export class AdminFacultyComponent implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  loading = true; saving = false;
  list: any[] = [];
  subjects: any[] = [];
  depts: string[] = [];
  q = '';
  form: any = null;
  editId = '';

  get filtered() {
    const q = this.q.trim().toLowerCase();
    return q ? this.list.filter((f) => [f.name, f.email, f.employeeId].some((v) => v.toLowerCase().includes(q))) : this.list;
  }
  ngOnInit() { this.load(); }
  load() {
    this.api.get('/admin/faculty').subscribe({ next: (r) => { this.list = r; this.loading = false; }, error: (e) => { this.loading = false; this.toast.error(errMsg(e)); } });
    this.api.get('/admin/subjects').subscribe({ next: (s) => (this.subjects = s.filter((x: any) => x.isActive)), error: () => {} });
    this.api.get('/admin/meta').subscribe({ next: (m) => (this.depts = m.departments), error: () => {} });
  }
  openForm(f?: any) {
    this.editId = f ? f._id : '';
    this.form = f ? { ...f, password: '', subjects: f.subjects.map((s: any) => s._id) } : { ...BLANK, subjects: [] };
  }
  pick(id: string, on: boolean) {
    this.form.subjects = on ? [...this.form.subjects, id] : this.form.subjects.filter((x: string) => x !== id);
  }
  save() {
    const f = this.form;
    if (!f.name || !f.email || !f.employeeId || !f.department) return this.toast.error('Fill in all required fields');
    if (!this.editId && (f.password || '').length < 8) return this.toast.error('Password must be at least 8 characters');
    const body: any = { name: f.name, email: f.email, employeeId: f.employeeId, department: f.department, designation: f.designation, subjects: f.subjects };
    if (f.password) body.password = f.password;
    this.saving = true;
    const req = this.editId ? this.api.put(`/admin/faculty/${this.editId}`, body) : this.api.post('/admin/faculty', body);
    req.subscribe({
      next: () => { this.saving = false; this.form = null; this.toast.success(this.editId ? 'Faculty updated' : 'Faculty added'); this.load(); },
      error: (e) => { this.saving = false; this.toast.error(errMsg(e)); },
    });
  }
  toggle(f: any) {
    this.api.put(`/admin/faculty/${f._id}`, { isActive: !f.isActive }).subscribe({
      next: () => { this.toast.success(f.isActive ? 'Faculty deactivated' : 'Faculty activated'); this.load(); },
      error: (e) => this.toast.error(errMsg(e)),
    });
  }
  remove(f: any) {
    if (!confirm(`Permanently delete ${f.name}? This only works if they have no subjects or attendance history.`)) return;
    this.api.delete(`/admin/faculty/${f._id}`, { permanent: true }).subscribe({
      next: () => { this.toast.success('Faculty deleted'); this.load(); },
      error: (e) => this.toast.error(errMsg(e)),
    });
  }
}
