import { Component, OnInit, inject } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { ToastService, errMsg } from '../../core/toast.service';
import { ChartComponent } from '../../shared/chart.component';
import { COLORS, todayLocal } from '../../shared/util';

@Component({
  selector: 'app-admin-overview',
  standalone: true,
  imports: [ChartComponent],
  template: `
    <div class="page-head"><div><h2>Overview</h2><p>System-wide summary from live records</p></div></div>
    @if (loading) { <div class="spinner-wrap"><div class="spinner"></div></div> }
    @else if (o) {
      <div class="grid g5">
        <div class="stat"><small>Students</small><strong>{{ o.students }}</strong></div>
        <div class="stat purple"><small>Faculty</small><strong>{{ o.faculty }}</strong></div>
        <div class="stat"><small>Subjects</small><strong>{{ o.subjects }}</strong></div>
        <div class="stat warn"><small>Classes conducted</small><strong>{{ o.classes }}</strong></div>
        <div class="stat" [class.ok]="o.overallPercentage >= o.minAttendance" [class.bad]="o.classes > 0 && o.overallPercentage < o.minAttendance">
          <small>Overall attendance</small><strong>{{ o.overallPercentage }}%</strong><span>Minimum {{ o.minAttendance }}%</span></div>
      </div>
      <div class="grid g2" style="margin-top:16px">
        <div class="card">
          <div class="card-head"><h3>Today</h3></div>
          @if (o.today.total === 0) { <div class="empty"><strong>No attendance marked today</strong></div> }
          @else {
            <div class="row" style="gap:28px">
              <div><div class="muted">Present</div><strong style="font-size:22px;color:var(--ok)">{{ o.today.present }}</strong></div>
              <div><div class="muted">Late</div><strong style="font-size:22px;color:var(--warn)">{{ o.today.late }}</strong></div>
              <div><div class="muted">Absent</div><strong style="font-size:22px;color:var(--bad)">{{ o.today.absent }}</strong></div>
              <div><div class="muted">Attendance</div><strong style="font-size:22px">{{ o.today.percentage }}%</strong></div>
            </div>
          }
        </div>
        <div class="card">
          <div class="card-head"><h3>All-time status split</h3></div>
          @if (o.classes === 0) { <div class="empty"><strong>No attendance recorded yet</strong></div> }
          @else { <app-chart type="doughnut" [labels]="['Present','Late','Absent']" [datasets]="sets" [options]="{ plugins: { legend: { position: 'right' } } }" [height]="180" /> }
        </div>
      </div>
    }`,
})
export class AdminOverviewComponent implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  loading = true;
  o: any;
  sets: any[] = [];
  ngOnInit() {
    this.api.get('/admin/overview', { date: todayLocal() }).subscribe({
      next: (o) => {
        this.o = o; this.loading = false;
        this.sets = [{ data: [o.status.present, o.status.late, o.status.absent], backgroundColor: [COLORS.green, COLORS.amber, COLORS.red] }];
      },
      error: (e) => { this.loading = false; this.toast.error(errMsg(e)); },
    });
  }
}
