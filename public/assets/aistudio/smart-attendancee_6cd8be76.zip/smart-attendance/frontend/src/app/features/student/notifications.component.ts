import { Component, OnInit, inject } from '@angular/core';
import { DatePipe } from '@angular/common';
import { ApiService } from '../../core/api.service';
import { NotifyService } from '../../core/notify.service';
import { ToastService, errMsg } from '../../core/toast.service';
import { PagerComponent } from '../../shared/pager.component';

const LABEL: Record<string, string> = { shortage: 'Shortage', warning: 'Low attendance', faculty_update: 'Faculty update', system: 'System' };

@Component({
  selector: 'app-notifications',
  standalone: true,
  imports: [DatePipe, PagerComponent],
  template: `
    <div class="page-head">
      <div><h2>Notifications</h2><p>{{ res.unread }} unread</p></div>
      <span class="spacer"></span>
      <button class="btn" [disabled]="!res.unread" (click)="readAll()">Mark all as read</button>
    </div>
    <div class="card" style="padding:0">
      @if (loading) { <div class="spinner-wrap"><div class="spinner"></div></div> }
      @else if (!res.data.length) { <div class="empty"><strong>No notifications</strong>Shortage alerts and faculty updates will show up here.</div> }
      @else {
        @for (n of res.data; track n._id) {
          <div class="notif" [class.unread]="!n.isRead">
            <div style="flex:1">
              <div class="row gap-s"><span class="badge {{ n.type }}">{{ label(n.type) }}</span><strong>{{ n.title }}</strong></div>
              <p>{{ n.message }}</p>
              <small class="muted">{{ n.createdAt | date:'dd MMM yyyy, HH:mm' }}</small>
            </div>
            @if (!n.isRead) { <button class="btn sm" style="align-self:flex-start" (click)="read(n)">Mark read</button> }
          </div>
        }
      }
    </div>
    <div style="padding:0 4px"><app-pager [page]="res.page" [pages]="res.pages" [total]="res.total" (pageChange)="load($event)" /></div>`,
})
export class NotificationsComponent implements OnInit {
  private api = inject(ApiService);
  private notify = inject(NotifyService);
  private toast = inject(ToastService);
  loading = true;
  res: any = { data: [], page: 1, pages: 1, total: 0, unread: 0 };
  label = (t: string) => LABEL[t] || t;

  ngOnInit() { this.load(1); }
  load(page: number) {
    this.loading = true;
    this.api.get('/notifications', { page, limit: 15 }).subscribe({
      next: (r) => { this.res = r; this.loading = false; this.notify.unread.set(r.unread); },
      error: (e) => { this.loading = false; this.toast.error(errMsg(e)); },
    });
  }
  read(n: any) {
    this.api.put(`/notifications/${n._id}/read`).subscribe({
      next: () => { n.isRead = true; this.res.unread = Math.max(0, this.res.unread - 1); this.notify.unread.set(this.res.unread); },
      error: (e) => this.toast.error(errMsg(e)),
    });
  }
  readAll() {
    this.api.put('/notifications/read-all').subscribe({
      next: () => { this.res.data.forEach((n: any) => (n.isRead = true)); this.res.unread = 0; this.notify.unread.set(0); this.toast.success('All notifications marked as read'); },
      error: (e) => this.toast.error(errMsg(e)),
    });
  }
}
