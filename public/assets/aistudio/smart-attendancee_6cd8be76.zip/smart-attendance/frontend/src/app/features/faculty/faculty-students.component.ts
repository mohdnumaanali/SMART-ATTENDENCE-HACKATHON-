import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { ToastService, errMsg } from '../../core/toast.service';
import { EligComponent } from '../../shared/elig.component';
import { IconComponent } from '../../shared/icon.component';

@Component({
  selector: 'app-faculty-students',
  standalone: true,
  imports: [FormsModule, EligComponent, IconComponent],
  template: `
    <div class="page-head"><div><h2>Student Records</h2><p>Students in your subjects with their attendance</p></div></div>
    <div class="card">
      <div class="filters">
        <label>Subject
          <select [(ngModel)]="subject" (ngModelChange)="load()">
            <option value="">All my subjects</option>
            @for (s of subjects; track s._id) { <option [value]="s._id">{{ s.code }} - {{ s.name }}</option> }
          </select>
        </label>
        <div class="search"><app-icon name="search" [size]="15" /><input placeholder="Search name or roll number" [(ngModel)]="q" /></div>
        <span class="muted">{{ filtered.length }} records &middot; minimum {{ min }}%</span>
      </div>
      @if (loading) { <div class="spinner-wrap"><div class="spinner"></div></div> }
      @else if (!filtered.length) { <div class="empty"><strong>No students found</strong>Check your search or subject assignments.</div> }
      @else {
        <div class="table-wrap"><table>
          <thead><tr><th>Roll number</th><th>Student</th><th>Section</th><th>Subject</th><th class="num">Attended / Total</th><th>Attendance</th><th>Status</th></tr></thead>
          <tbody>
            @for (r of filtered; track r.studentId + r.subjectId) {
              <tr>
                <td>{{ r.rollNumber }}</td><td>{{ r.name }}</td><td>{{ r.section }}</td><td>{{ r.code }}</td>
                <td class="num">{{ r.attended }} / {{ r.total }}</td>
                <td><div class="pct-cell"><div class="bar" style="width:90px"><span [class.bad]="!r.eligible" [style.width.%]="r.percentage"></span></div><b>{{ r.percentage }}%</b></div></td>
                <td><app-elig [row]="r" /></td>
              </tr>
            }
          </tbody>
        </table></div>
      }
    </div>`,
})
export class FacultyStudentsComponent implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  loading = true;
  subjects: any[] = [];
  subject = '';
  q = '';
  rows: any[] = [];
  min = 75;

  get filtered() {
    const q = this.q.trim().toLowerCase();
    return q ? this.rows.filter((r) => r.name.toLowerCase().includes(q) || r.rollNumber.toLowerCase().includes(q)) : this.rows;
  }
  ngOnInit() {
    this.api.get('/faculty/subjects').subscribe({ next: (s) => (this.subjects = s), error: () => {} });
    this.load();
  }
  load() {
    this.loading = true;
    this.api.get('/faculty/students', { subject: this.subject }).subscribe({
      next: (r) => { this.rows = r.rows; this.min = r.settings.minAttendance; this.loading = false; },
      error: (e) => { this.loading = false; this.toast.error(errMsg(e)); },
    });
  }
}
