import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { ToastService, errMsg } from '../../core/toast.service';
import { IconComponent } from '../../shared/icon.component';
import { ModalComponent } from '../../shared/modal.component';

const BLANK = { name: '', code: '', department: '', semester: 1, sections: '', credits: 3, faculty: '' };

@Component({
  selector: 'app-admin-subjects',
  standalone: true,
  imports: [FormsModule, IconComponent, ModalComponent],
  template: `
    <div class="page-head">
      <div><h2>Subjects</h2><p>Create subjects, set semesters and sections, assign faculty</p></div><span class="spacer"></span>
      <button class="btn primary" (click)="openForm()"><app-icon name="plus" /> Add subject</button>
    </div>
    <div class="card">
      <div class="filters">
        <div class="search"><app-icon name="search" [size]="15" /><input placeholder="Search name or code" [(ngModel)]="q" /></div>
        <label>Semester<select [(ngModel)]="sem"><option value="">All</option>@for (s of semesters; track s) { <option [value]="s">{{ s }}</option> }</select></label>
      </div>
      @if (loading) { <div class="spinner-wrap"><div class="spinner"></div></div> }
      @else if (!filtered.length) { <div class="empty"><strong>No subjects found</strong>Create a subject to get started.</div> }
      @else {
        <div class="table-wrap"><table>
          <thead><tr><th>Code</th><th>Subject</th><th>Department</th><th>Sem</th><th>Sections</th><th>Faculty</th><th>Status</th><th></th></tr></thead>
          <tbody>
            @for (s of filtered; track s._id) {
              <tr>
                <td>{{ s.code }}</td><td>{{ s.name }}</td><td>{{ s.department }}</td><td>{{ s.semester }}</td><td>{{ s.sections.join(', ') }}</td>
                <td>{{ s.faculty?.name || 'Unassigned' }}</td>
                <td><span class="badge {{ s.isActive ? 'active' : 'inactive' }}">{{ s.isActive ? 'Active' : 'Inactive' }}</span></td>
                <td class="actions">
                  <button class="icon-btn" title="Edit" (click)="openForm(s)"><app-icon name="edit" /></button>
                  <button class="btn sm" (click)="toggle(s)">{{ s.isActive ? 'Deactivate' : 'Activate' }}</button>
                  <button class="icon-btn" title="Delete" (click)="remove(s)"><app-icon name="trash" /></button>
                </td>
              </tr>
            }
          </tbody>
        </table></div>
      }
    </div>

    @if (form) {
      <app-modal [title]="editId ? 'Edit subject' : 'Add subject'" (close)="form = null">
        <form (ngSubmit)="save()">
          <div class="form-grid">
            <label class="full">Subject name<input name="name" [(ngModel)]="form.name" required /></label>
            <label>Code<input name="code" [(ngModel)]="form.code" required /></label>
            <label>Credits<input type="number" name="cr" [(ngModel)]="form.credits" min="0" max="20" /></label>
            <label>Department<input name="dept" [(ngModel)]="form.department" list="sdepts" required /></label>
            <label>Semester<input type="number" name="sem" [(ngModel)]="form.semester" min="1" max="12" required /></label>
            <label class="full">Sections (comma separated)<input name="sec" [(ngModel)]="form.sections" placeholder="A, B" required /></label>
            <label class="full">Faculty
              <select name="fac" [(ngModel)]="form.faculty"><option value="">Unassigned</option>@for (f of faculty; track f._id) { <option [value]="f._id">{{ f.name }} ({{ f.employeeId }})</option> }</select>
            </label>
          </div>
          <datalist id="sdepts">@for (d of depts; track d) { <option [value]="d"></option> }</datalist>
          <div class="modal-foot"><button type="button" class="btn" (click)="form = null">Cancel</button><button class="btn primary" [disabled]="saving">{{ saving ? 'Saving...' : 'Save' }}</button></div>
        </form>
      </app-modal>
    }`,
})
export class AdminSubjectsComponent implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  loading = true; saving = false;
  list: any[] = [];
  faculty: any[] = [];
  depts: string[] = [];
  q = ''; sem = '';
  form: any = null;
  editId = '';

  get semesters() { return [...new Set(this.list.map((s) => s.semester))].sort((a, b) => a - b); }
  get filtered() {
    const q = this.q.trim().toLowerCase();
    return this.list.filter((s) => (!q || s.name.toLowerCase().includes(q) || s.code.toLowerCase().includes(q)) && (!this.sem || s.semester === Number(this.sem)));
  }
  ngOnInit() { this.load(); }
  load() {
    this.api.get('/admin/subjects').subscribe({ next: (r) => { this.list = r; this.loading = false; }, error: (e) => { this.loading = false; this.toast.error(errMsg(e)); } });
    this.api.get('/admin/faculty').subscribe({ next: (r) => (this.faculty = r.filter((f: any) => f.isActive)), error: () => {} });
    this.api.get('/admin/meta').subscribe({ next: (m) => (this.depts = m.departments), error: () => {} });
  }
  openForm(s?: any) {
    this.editId = s ? s._id : '';
    this.form = s ? { ...s, sections: s.sections.join(', '), faculty: s.faculty?._id || '' } : { ...BLANK };
  }
  save() {
    const f = this.form;
    if (!f.name || !f.code || !f.department || !String(f.sections).trim()) return this.toast.error('Fill in all required fields');
    const body = { name: f.name, code: f.code, department: f.department, semester: Number(f.semester), credits: Number(f.credits), sections: f.sections, faculty: f.faculty || '' };
    this.saving = true;
    const req = this.editId ? this.api.put(`/admin/subjects/${this.editId}`, body) : this.api.post('/admin/subjects', body);
    req.subscribe({
      next: () => { this.saving = false; this.form = null; this.toast.success(this.editId ? 'Subject updated' : 'Subject created'); this.load(); },
      error: (e) => { this.saving = false; this.toast.error(errMsg(e)); },
    });
  }
  toggle(s: any) {
    this.api.put(`/admin/subjects/${s._id}`, { isActive: !s.isActive }).subscribe({
      next: () => { this.toast.success(s.isActive ? 'Subject deactivated' : 'Subject activated'); this.load(); },
      error: (e) => this.toast.error(errMsg(e)),
    });
  }
  remove(s: any) {
    if (!confirm(`Delete subject ${s.code}? This only works if no attendance has been recorded for it.`)) return;
    this.api.delete(`/admin/subjects/${s._id}`, { permanent: true }).subscribe({
      next: () => { this.toast.success('Subject deleted'); this.load(); },
      error: (e) => this.toast.error(errMsg(e)),
    });
  }
}
