import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService, Role } from './auth.service';

export const roleGuard = (role: Role): CanActivateFn => () => {
  const auth = inject(AuthService);
  const router = inject(Router);
  if (!auth.loggedIn) return router.createUrlTree(['/login']);
  const user = auth.user()!;
  return user.role === role ? true : router.createUrlTree([auth.homeFor(user.role)]);
};

export const guestGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  return auth.loggedIn ? inject(Router).createUrlTree([auth.homeFor(auth.user()!.role)]) : true;
};
