export const todayLocal = (): string => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

export const monthLabel = (ym: string): string => {
  const [y, m] = ym.split('-');
  return new Date(Number(y), Number(m) - 1, 1).toLocaleString('en', { month: 'short', year: '2-digit' });
};

export const COLORS = { blue: '#3b5bdb', purple: '#7048e8', green: '#2f9e44', amber: '#f08c00', red: '#e03131', navy: '#12214a', grey: '#adb5bd' };
