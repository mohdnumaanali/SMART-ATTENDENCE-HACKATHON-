import { Component, OnInit, inject } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { ToastService, errMsg } from '../../core/toast.service';
import { ModalComponent } from '../../shared/modal.component';
import { PagerComponent } from '../../shared/pager.component';

@Component({
  selector: 'app-admin-settings',
  standalone: true,
  imports: [FormsModule, DatePipe, ModalComponent, PagerComponent],
  template: `
    <div class="page-head"><div><h2>System Settings</h2></div></div>

    <div class="card">
      <div class="card-head"><h3>Attendance rules</h3></div>
      <form class="filters" (ngSubmit)="saveRules()">
        <label>Minimum attendance (%)<input type="number" name="min" [(ngModel)]="min" min="1" max="100" step="0.5" required /></label>
        <label class="check" style="padding-bottom:9px"><input type="checkbox" name="late" [(ngModel)]="late" /> Count "Late" as attended</label>
        <button class="btn primary" [disabled]="busy">Save rules</button>
        <button type="button" class="btn" (click)="resync()" title="Rebuild shortage alerts using the current rules">Refresh student alerts</button>
      </form>
      <p class="muted" style="margin:0">Applies to every dashboard, calculator and report straight away. Alerts update automatically whenever attendance is submitted.</p>
    </div>

    <div class="card">
      <div class="card-head"><h3>Academic sessions</h3><span class="spacer"></span><button class="btn sm primary" (click)="openSession()">Add session</button></div>
      @if (!sessions.length) { <div class="empty"><strong>No sessions yet</strong></div> }
      @else {
        <div class="table-wrap"><table>
          <thead><tr><th>Name</th><th>Start</th><th>End</th><th class="num">Minimum %</th><th>Status</th><th></th></tr></thead>
          <tbody>
            @for (s of sessions; track s._id) {
              <tr>
                <td>{{ s.name }}</td><td>{{ s.startDate | date:'dd MMM yyyy':'UTC' }}</td><td>{{ s.endDate | date:'dd MMM yyyy':'UTC' }}</td><td class="num">{{ s.minAttendance }}</td>
                <td><span class="badge {{ s.isActive ? 'active' : 'none' }}">{{ s.isActive ? 'Active' : 'Inactive' }}</span></td>
                <td class="actions">
                  @if (!s.isActive) { <button class="btn sm" (click)="activate(s)">Make active</button><button class="btn sm danger" (click)="delSession(s)">Delete</button> }
                </td>
              </tr>
            }
          </tbody>
        </table></div>
      }
    </div>

    <div class="card">
      <div class="card-head"><h3>User accounts and roles</h3><span class="spacer"></span><button class="btn sm primary" (click)="admin = { name: '', email: '', password: '' }">Add administrator</button></div>
      <div class="filters">
        <label>Search<input [(ngModel)]="uq" (ngModelChange)="loadUsers(1)" placeholder="Name or email" /></label>
        <label>Role<select [(ngModel)]="urole" (ngModelChange)="loadUsers(1)"><option value="">All</option><option value="student">Student</option><option value="faculty">Faculty</option><option value="admin">Admin</option></select></label>
      </div>
      <p class="muted" style="margin-top:0">A user's role is fixed when the account is created (students and faculty are created on their own pages). Here you can deactivate accounts, reset passwords and add administrators.</p>
      <div class="table-wrap"><table>
        <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Last login</th><th>Status</th><th></th></tr></thead>
        <tbody>
          @for (u of users.data; track u._id) {
            <tr>
              <td>{{ u.name }}</td><td>{{ u.email }}</td><td style="text-transform:capitalize">{{ u.role }}</td>
              <td>{{ u.lastLogin ? (u.lastLogin | date:'dd MMM yyyy, HH:mm') : 'Never' }}</td>
              <td><span class="badge {{ u.isActive ? 'active' : 'inactive' }}">{{ u.isActive ? 'Active' : 'Inactive' }}</span></td>
              <td class="actions"><button class="btn sm" (click)="reset = { user: u, password: '' }">Reset password</button><button class="btn sm" (click)="toggleUser(u)">{{ u.isActive ? 'Deactivate' : 'Activate' }}</button></td>
            </tr>
          }
        </tbody>
      </table></div>
      <app-pager [page]="users.page" [pages]="users.pages" [total]="users.total" (pageChange)="loadUsers($event)" />
    </div>

    @if (session) {
      <app-modal title="Add academic session" (close)="session = null">
        <form (ngSubmit)="saveSession()">
          <div class="form-grid">
            <label class="full">Name<input name="n" [(ngModel)]="session.name" placeholder="2027-28 Odd" required /></label>
            <label>Start date<input type="date" name="s" [(ngModel)]="session.startDate" required /></label>
            <label>End date<input type="date" name="e" [(ngModel)]="session.endDate" required /></label>
            <label>Minimum attendance (%)<input type="number" name="m" [(ngModel)]="session.minAttendance" min="1" max="100" /></label>
          </div>
          <div class="modal-foot"><button type="button" class="btn" (click)="session = null">Cancel</button><button class="btn primary">Create</button></div>
        </form>
      </app-modal>
    }
    @if (admin) {
      <app-modal title="Add administrator" (close)="admin = null">
        <form (ngSubmit)="saveAdmin()">
          <div class="form-grid">
            <label class="full">Full name<input name="n" [(ngModel)]="admin.name" required /></label>
            <label>Email<input type="email" name="e" [(ngModel)]="admin.email" required /></label>
            <label>Password<input type="password" name="p" [(ngModel)]="admin.password" minlength="8" required autocomplete="new-password" /></label>
          </div>
          <div class="modal-foot"><button type="button" class="btn" (click)="admin = null">Cancel</button><button class="btn primary">Create administrator</button></div>
        </form>
      </app-modal>
    }
    @if (reset) {
      <app-modal [title]="'Reset password: ' + reset.user.name" (close)="reset = null">
        <form (ngSubmit)="savePassword()">
          <label>New password (min 8 characters)<input type="password" name="p" [(ngModel)]="reset.password" minlength="8" required autocomplete="new-password" /></label>
          <div class="modal-foot"><button type="button" class="btn" (click)="reset = null">Cancel</button><button class="btn primary">Reset password</button></div>
        </form>
      </app-modal>
    }`,
})
export class AdminSettingsComponent implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  min = 75; late = true; busy = false;
  sessions: any[] = [];
  users: any = { data: [], page: 1, pages: 1, total: 0 };
  uq = ''; urole = '';
  session: any = null; admin: any = null; reset: any = null;
  private upage = 1;

  ngOnInit() { this.loadRules(); this.loadSessions(); this.loadUsers(1); }

  loadRules() { this.api.get('/admin/settings').subscribe({ next: (s) => { this.min = s.minAttendance; this.late = s.lateCountsAsPresent; }, error: (e) => this.toast.error(errMsg(e)) }); }
  saveRules() {
    const m = Number(this.min);
    if (!(m >= 1 && m <= 100)) return this.toast.error('Minimum attendance must be between 1 and 100');
    this.busy = true;
    this.api.put('/admin/settings', { minAttendance: m, lateCountsAsPresent: this.late }).subscribe({
      next: () => { this.busy = false; this.toast.success('Attendance rules saved'); this.loadSessions(); },
      error: (e) => { this.busy = false; this.toast.error(errMsg(e)); },
    });
  }
  resync() { this.api.post('/admin/notifications/resync').subscribe({ next: (r) => this.toast.success(r.message), error: (e) => this.toast.error(errMsg(e)) }); }

  loadSessions() { this.api.get('/admin/sessions').subscribe({ next: (s) => (this.sessions = s), error: () => {} }); }
  openSession() { this.session = { name: '', startDate: '', endDate: '', minAttendance: this.min }; }
  saveSession() {
    this.api.post('/admin/sessions', { ...this.session, minAttendance: Number(this.session.minAttendance) }).subscribe({
      next: () => { this.session = null; this.toast.success('Session created'); this.loadSessions(); },
      error: (e) => this.toast.error(errMsg(e)),
    });
  }
  activate(s: any) {
    this.api.put(`/admin/sessions/${s._id}/activate`).subscribe({ next: (r) => { this.toast.success(r.message); this.loadSessions(); this.loadRules(); }, error: (e) => this.toast.error(errMsg(e)) });
  }
  delSession(s: any) {
    if (!confirm(`Delete session ${s.name}?`)) return;
    this.api.delete(`/admin/sessions/${s._id}`).subscribe({ next: () => { this.toast.success('Session deleted'); this.loadSessions(); }, error: (e) => this.toast.error(errMsg(e)) });
  }

  loadUsers(page: number) {
    this.upage = page;
    this.api.get('/admin/users', { q: this.uq, role: this.urole, page, limit: 10 }).subscribe({ next: (u) => (this.users = u), error: (e) => this.toast.error(errMsg(e)) });
  }
  toggleUser(u: any) {
    this.api.put(`/admin/users/${u._id}`, { isActive: !u.isActive }).subscribe({
      next: () => { this.toast.success(u.isActive ? 'Account deactivated' : 'Account activated'); this.loadUsers(this.upage); },
      error: (e) => this.toast.error(errMsg(e)),
    });
  }
  savePassword() {
    this.api.put(`/admin/users/${this.reset.user._id}`, { password: this.reset.password }).subscribe({
      next: () => { this.reset = null; this.toast.success('Password reset'); },
      error: (e) => this.toast.error(errMsg(e)),
    });
  }
  saveAdmin() {
    this.api.post('/admin/users/admin', this.admin).subscribe({
      next: () => { this.admin = null; this.toast.success('Administrator created'); this.loadUsers(1); },
      error: (e) => this.toast.error(errMsg(e)),
    });
  }
}
