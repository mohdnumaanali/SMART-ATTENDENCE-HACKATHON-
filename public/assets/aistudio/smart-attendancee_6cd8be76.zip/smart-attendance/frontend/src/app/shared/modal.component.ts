import { Component, EventEmitter, Input, Output } from '@angular/core';
import { IconComponent } from './icon.component';

@Component({
  selector: 'app-modal',
  standalone: true,
  imports: [IconComponent],
  template: `
    <div class="modal-backdrop" (click)="close.emit()">
      <div class="modal" [class.wide]="wide" (click)="$event.stopPropagation()" role="dialog" aria-modal="true">
        <div class="modal-head">
          <h3>{{ title }}</h3>
          <button type="button" class="icon-btn" (click)="close.emit()" aria-label="Close"><app-icon name="x" /></button>
        </div>
        <div class="modal-body"><ng-content /></div>
      </div>
    </div>`,
})
export class ModalComponent {
  @Input() title = '';
  @Input() wide = false;
  @Output() close = new EventEmitter<void>();
}
