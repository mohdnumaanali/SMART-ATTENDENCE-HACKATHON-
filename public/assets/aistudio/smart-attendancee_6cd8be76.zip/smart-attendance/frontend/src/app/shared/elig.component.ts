import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-elig',
  standalone: true,
  template: `<span class="badge {{ cls }}">{{ text }}</span>`,
})
export class EligComponent {
  @Input() row: any = {};
  get cls() { return this.row.total === 0 ? 'none' : this.row.eligible ? 'ok' : 'bad'; }
  get text() { return this.row.total === 0 ? 'No classes' : this.row.eligible ? 'Eligible' : 'Shortage'; }
}
