import { Injectable, signal } from '@angular/core';

export interface Toast { id: number; type: 'success' | 'error' | 'info'; text: string; }

@Injectable({ providedIn: 'root' })
export class ToastService {
  toasts = signal<Toast[]>([]);
  private n = 0;

  show(type: Toast['type'], text: string) {
    const id = ++this.n;
    this.toasts.update((t) => [...t, { id, type, text }]);
    setTimeout(() => this.dismiss(id), 4500);
  }
  success(text: string) { this.show('success', text); }
  error(text: string) { this.show('error', text); }
  info(text: string) { this.show('info', text); }
  dismiss(id: number) { this.toasts.update((t) => t.filter((x) => x.id !== id)); }
}

export const errMsg = (e: any): string =>
  e?.error?.message || (e?.status === 0 ? 'Cannot reach the server.' : 'Something went wrong. Please try again.');
