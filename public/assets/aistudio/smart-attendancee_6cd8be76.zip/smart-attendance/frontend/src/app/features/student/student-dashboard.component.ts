import { Component, OnInit, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { ToastService, errMsg } from '../../core/toast.service';
import { ChartComponent } from '../../shared/chart.component';
import { EligComponent } from '../../shared/elig.component';
import { COLORS, monthLabel } from '../../shared/util';

@Component({
  selector: 'app-student-dashboard',
  standalone: true,
  imports: [ChartComponent, EligComponent, RouterLink],
  template: `
    <div class="page-head"><div><h2>Dashboard</h2><p>Your attendance across all subjects</p></div></div>
    @if (loading) { <div class="spinner-wrap"><div class="spinner"></div></div> }
    @else if (data) {
      @if (data.overall.total === 0) {
        <div class="card empty"><strong>No attendance recorded yet</strong>Your attendance will appear here once faculty start marking classes.</div>
      } @else {
        <div class="grid g5">
          <div class="stat" [class.bad]="!data.overall.eligible" [class.ok]="data.overall.eligible">
            <small>Overall attendance</small><strong>{{ data.overall.currentPercentage }}%</strong>
            <span>Required {{ data.settings.minAttendance }}%</span>
          </div>
          <div class="stat purple"><small>Classes conducted</small><strong>{{ data.overall.total }}</strong></div>
          <div class="stat ok"><small>Attended</small><strong>{{ data.overall.attended }}</strong><span>{{ data.overall.present }} present, {{ data.overall.late }} late</span></div>
          <div class="stat bad"><small>Missed</small><strong>{{ data.overall.absent }}</strong></div>
          <div class="stat"><small>Status</small><strong style="font-size:18px;padding-top:6px"><app-elig [row]="data.overall" /></strong></div>
        </div>
        <div class="alert {{ data.overall.eligible ? 'success' : 'danger' }}" style="margin-top:16px">
          {{ data.overall.message }} <a routerLink="/student/eligibility">See full calculator</a>
        </div>
        <div class="grid g2" style="margin-top:16px">
          <div class="card">
            <div class="card-head"><h3>Subject-wise attendance</h3></div>
            <app-chart type="bar" [labels]="subjectLabels" [datasets]="subjectSets" [options]="pctOptions" />
          </div>
          <div class="card">
            <div class="card-head"><h3>Present, late and absent</h3></div>
            <app-chart type="doughnut" [labels]="['Present','Late','Absent']" [datasets]="statusSets" [options]="{ plugins: { legend: { position: 'bottom' } } }" />
          </div>
        </div>
        @if (data.trend.length > 1) {
          <div class="card">
            <div class="card-head"><h3>Monthly trend</h3></div>
            <app-chart type="line" [labels]="trendLabels" [datasets]="trendSets" [options]="pctOptions" [height]="220" />
          </div>
        }
        <div class="card">
          <div class="card-head"><h3>Subjects</h3></div>
          @for (s of data.subjects; track s.subjectId) {
            <div class="row" style="padding:8px 0;border-bottom:1px solid var(--border)">
              <div style="flex:1;min-width:180px"><strong>{{ s.name }}</strong><div class="muted">{{ s.code }} &middot; {{ s.faculty || 'Faculty not assigned' }}</div></div>
              <div class="pct-cell" style="flex:1;min-width:200px"><div class="bar" style="flex:1"><span [class.bad]="!s.eligible" [style.width.%]="s.currentPercentage"></span></div><b>{{ s.currentPercentage }}%</b></div>
              <app-elig [row]="s" />
            </div>
          }
        </div>
      }
    }`,
})
export class StudentDashboardComponent implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  loading = true;
  data: any;
  subjectLabels: string[] = [];
  subjectSets: any[] = [];
  statusSets: any[] = [];
  trendLabels: string[] = [];
  trendSets: any[] = [];
  pctOptions = { scales: { y: { min: 0, max: 100, ticks: { callback: (v: any) => v + '%' } } }, plugins: { legend: { position: 'bottom' } } };

  ngOnInit() {
    this.api.get('/student/summary').subscribe({
      next: (d) => { this.data = d; this.build(); this.loading = false; },
      error: (e) => { this.loading = false; this.toast.error(errMsg(e)); },
    });
  }

  private build() {
    const d = this.data, min = d.settings.minAttendance;
    this.subjectLabels = d.subjects.map((s: any) => s.code);
    this.subjectSets = [
      { label: 'Attendance %', data: d.subjects.map((s: any) => s.currentPercentage), backgroundColor: d.subjects.map((s: any) => (s.eligible ? COLORS.blue : COLORS.red)), borderRadius: 4 },
      { type: 'line', label: `Required (${min}%)`, data: d.subjects.map(() => min), borderColor: COLORS.red, borderDash: [6, 4], pointRadius: 0, borderWidth: 2 },
    ];
    this.statusSets = [{ data: [d.overall.present, d.overall.late, d.overall.absent], backgroundColor: [COLORS.green, COLORS.amber, COLORS.red] }];
    this.trendLabels = d.trend.map((t: any) => monthLabel(t.month));
    this.trendSets = [
      { label: 'Attendance %', data: d.trend.map((t: any) => t.percentage), borderColor: COLORS.purple, backgroundColor: COLORS.purple, tension: 0.3 },
      { label: `Required (${min}%)`, data: d.trend.map(() => min), borderColor: COLORS.red, borderDash: [6, 4], pointRadius: 0 },
    ];
  }
}
