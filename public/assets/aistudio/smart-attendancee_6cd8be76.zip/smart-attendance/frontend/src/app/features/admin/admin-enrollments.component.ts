import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { ToastService, errMsg } from '../../core/toast.service';

@Component({
  selector: 'app-admin-enrollments',
  standalone: true,
  imports: [FormsModule],
  template: `
    <div class="page-head"><div><h2>Enrollments</h2><p>Students in a subject: the class (department, semester and section) plus anyone you enroll manually</p></div></div>
    <div class="card">
      <div class="filters">
        <label style="min-width:280px">Subject
          <select [(ngModel)]="subjectId" (ngModelChange)="load()">
            <option value="">Select subject</option>
            @for (s of subjects; track s._id) { <option [value]="s._id">{{ s.code }} - {{ s.name }} (sem {{ s.semester }}, sec {{ s.sections.join(',') }})</option> }
          </select>
        </label>
      </div>

      @if (data) {
        <div class="card" style="background:#f8f9fd">
          <div class="card-head"><h3>Enroll a student in {{ data.subject.code }}</h3></div>
          <div class="filters" style="margin-bottom:0">
            <label>Find student<input [(ngModel)]="q" (ngModelChange)="search()" placeholder="Name or roll number" /></label>
            <label style="min-width:300px">Student
              <select [(ngModel)]="studentId">
                <option value="">Select student</option>
                @for (s of candidates; track s._id) { <option [value]="s._id">{{ s.rollNumber }} - {{ s.name }} ({{ s.department }}, sem {{ s.semester }}, sec {{ s.section }})</option> }
              </select>
            </label>
            <button class="btn primary" [disabled]="!studentId || busy" (click)="enroll()">Enroll</button>
          </div>
          <p class="muted" style="margin:10px 0 0">A student's section must be one of this subject's sections ({{ data.subject.sections.join(', ') }}). Students already in the class are added automatically.</p>
        </div>

        <div class="card-head" style="margin-top:16px"><h3>{{ data.rows.length }} students in {{ data.subject.code }}</h3></div>
        @if (!data.rows.length) { <div class="empty"><strong>No students enrolled</strong>Add students above or create students in this class.</div> }
        @else {
          <div class="table-wrap"><table>
            <thead><tr><th>Roll number</th><th>Name</th><th>Department</th><th>Sem</th><th>Sec</th><th>Enrolled via</th><th></th></tr></thead>
            <tbody>
              @for (r of data.rows; track r._id) {
                <tr>
                  <td>{{ r.rollNumber }}</td><td>{{ r.name }}</td><td>{{ r.department }}</td><td>{{ r.semester }}</td><td>{{ r.section }}</td>
                  <td><span class="badge {{ r.source === 'manual' ? 'info' : 'none' }}">{{ r.source === 'manual' ? 'Manual enrollment' : 'Class' }}</span></td>
                  <td class="actions">@if (r.enrollmentId) { <button class="btn sm danger" (click)="remove(r)">Remove</button> }</td>
                </tr>
              }
            </tbody>
          </table></div>
        }
      } @else { <div class="empty"><strong>Select a subject</strong>to see and manage its students.</div> }
    </div>`,
})
export class AdminEnrollmentsComponent implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  subjects: any[] = [];
  subjectId = '';
  data: any = null;
  q = '';
  candidates: any[] = [];
  studentId = '';
  busy = false;

  ngOnInit() {
    this.api.get('/admin/subjects').subscribe({ next: (s) => (this.subjects = s.filter((x: any) => x.isActive)), error: (e) => this.toast.error(errMsg(e)) });
  }
  load() {
    this.data = null; this.studentId = ''; this.q = ''; this.candidates = [];
    if (!this.subjectId) return;
    this.api.get('/admin/enrollments', { subject: this.subjectId }).subscribe({
      next: (d) => { this.data = d; this.search(); },
      error: (e) => this.toast.error(errMsg(e)),
    });
  }
  search() {
    const inSubject = new Set(this.data.rows.map((r: any) => r._id));
    this.api.get('/admin/students', { q: this.q, status: 'active', limit: 100 }).subscribe({
      next: (r) => (this.candidates = r.data.filter((s: any) => !inSubject.has(s._id))),
      error: () => {},
    });
  }
  enroll() {
    this.busy = true;
    this.api.post('/admin/enrollments', { student: this.studentId, subject: this.subjectId }).subscribe({
      next: (r) => { this.busy = false; this.studentId = ''; this.toast.success(r.message); this.load(); },
      error: (e) => { this.busy = false; this.toast.error(errMsg(e)); },
    });
  }
  remove(r: any) {
    if (!confirm(`Remove ${r.name} (${r.rollNumber}) from ${this.data.subject.code}? Existing attendance records are kept.`)) return;
    this.api.delete(`/admin/enrollments/${r.enrollmentId}`).subscribe({
      next: (res) => { this.toast.success(res.message); this.load(); },
      error: (e) => this.toast.error(errMsg(e)),
    });
  }
}
