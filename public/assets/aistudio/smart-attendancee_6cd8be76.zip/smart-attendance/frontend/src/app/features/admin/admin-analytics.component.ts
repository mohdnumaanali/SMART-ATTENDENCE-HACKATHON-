import { Component, OnInit, inject } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { ToastService, errMsg } from '../../core/toast.service';
import { ChartComponent } from '../../shared/chart.component';
import { COLORS, monthLabel } from '../../shared/util';

@Component({
  selector: 'app-admin-analytics',
  standalone: true,
  imports: [ChartComponent],
  template: `
    <div class="page-head"><div><h2>Reports & Analytics</h2><p>Computed from attendance records. Minimum attendance: {{ a?.minAttendance ?? 75 }}%</p></div></div>
    @if (loading) { <div class="spinner-wrap"><div class="spinner"></div></div> }
    @else if (!a || (a.status.present + a.status.late + a.status.absent) === 0) { <div class="card empty"><strong>No attendance data yet</strong>Charts appear once attendance has been marked.</div> }
    @else {
      <div class="grid g2">
        <div class="card"><div class="card-head"><h3>Department-wise attendance</h3></div>
          <app-chart type="bar" [labels]="dept.labels" [datasets]="dept.sets" [options]="pct" /></div>
        <div class="card"><div class="card-head"><h3>Semester-wise attendance</h3></div>
          <app-chart type="bar" [labels]="sem.labels" [datasets]="sem.sets" [options]="pct" /></div>
        <div class="card"><div class="card-head"><h3>Subject-wise comparison</h3></div>
          <app-chart type="bar" [labels]="subj.labels" [datasets]="subj.sets" [options]="pct" /></div>
        <div class="card"><div class="card-head"><h3>Monthly attendance trend</h3></div>
          <app-chart type="line" [labels]="trend.labels" [datasets]="trend.sets" [options]="pct" /></div>
        <div class="card"><div class="card-head"><h3>Present vs late vs absent</h3></div>
          <app-chart type="doughnut" [labels]="['Present','Late','Absent']" [datasets]="status" [options]="{ plugins: { legend: { position: 'bottom' } } }" /></div>
        <div class="card"><div class="card-head"><h3>Attendance shortage overview</h3></div>
          <app-chart type="bar" [labels]="short.labels" [datasets]="short.sets" [options]="{ scales: { x: { stacked: true }, y: { stacked: true, beginAtZero: true, ticks: { precision: 0 } } }, plugins: { legend: { position: 'bottom' } } }" /></div>
      </div>
      <div class="card">
        <div class="card-head"><h3>Shortage records by subject</h3></div>
        @if (!a.shortage.bySubject.length) { <div class="empty"><strong>No shortages</strong>Every student meets the minimum in every subject.</div> }
        @else {
          <div class="table-wrap"><table>
            <thead><tr><th>Subject</th><th class="num">Students below {{ a.minAttendance }}%</th></tr></thead>
            <tbody>@for (s of a.shortage.bySubject; track s.label) { <tr><td>{{ s.label }}</td><td class="num">{{ s.count }}</td></tr> }</tbody>
          </table></div>
        }
      </div>
    }`,
})
export class AdminAnalyticsComponent implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  loading = true;
  a: any;
  dept: any = {}; sem: any = {}; subj: any = {}; trend: any = {}; short: any = {}; status: any[] = [];
  pct = { scales: { y: { min: 0, max: 100, ticks: { callback: (v: any) => v + '%' } } }, plugins: { legend: { display: false } } };

  ngOnInit() {
    this.api.get('/admin/analytics').subscribe({
      next: (a) => { this.a = a; this.build(); this.loading = false; },
      error: (e) => { this.loading = false; this.toast.error(errMsg(e)); },
    });
  }
  private bars(rows: any[], color: string) {
    const min = this.a.minAttendance;
    return {
      labels: rows.map((r) => r.label),
      sets: [
        { label: 'Attendance %', data: rows.map((r) => r.percentage), backgroundColor: rows.map((r) => (r.percentage >= min ? color : COLORS.red)), borderRadius: 4 },
        { type: 'line', label: `Minimum (${min}%)`, data: rows.map(() => min), borderColor: COLORS.red, borderDash: [6, 4], pointRadius: 0 },
      ],
    };
  }
  private build() {
    const a = this.a;
    this.dept = this.bars(a.byDepartment, COLORS.blue);
    this.sem = this.bars(a.bySemester, COLORS.purple);
    this.subj = this.bars(a.bySubject, COLORS.blue);
    this.trend = {
      labels: a.monthly.map((m: any) => monthLabel(m.month)),
      sets: [
        { label: 'Attendance %', data: a.monthly.map((m: any) => m.percentage), borderColor: COLORS.purple, backgroundColor: COLORS.purple, tension: 0.3 },
        { label: `Minimum (${a.minAttendance}%)`, data: a.monthly.map(() => a.minAttendance), borderColor: COLORS.red, borderDash: [6, 4], pointRadius: 0 },
      ],
    };
    this.status = [{ data: [a.status.present, a.status.late, a.status.absent], backgroundColor: [COLORS.green, COLORS.amber, COLORS.red] }];
    this.short = {
      labels: a.shortage.byDepartment.map((d: any) => d.label),
      sets: [
        { label: 'Meeting minimum', data: a.shortage.byDepartment.map((d: any) => d.students - d.below), backgroundColor: COLORS.blue },
        { label: 'Below minimum (in any subject)', data: a.shortage.byDepartment.map((d: any) => d.below), backgroundColor: COLORS.red },
      ],
    };
  }
}
