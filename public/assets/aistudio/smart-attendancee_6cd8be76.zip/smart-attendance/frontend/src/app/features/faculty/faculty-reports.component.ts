import { Component, OnInit, inject } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { ToastService, errMsg } from '../../core/toast.service';
import { ChartComponent } from '../../shared/chart.component';
import { COLORS, todayLocal } from '../../shared/util';

@Component({
  selector: 'app-faculty-reports',
  standalone: true,
  imports: [FormsModule, DatePipe, ChartComponent],
  template: `
    <div class="page-head"><div><h2>Reports</h2><p>Export any report as CSV</p></div></div>
    <div class="tabs">
      @for (t of tabs; track t.key) { <button class="tab" [class.active]="tab === t.key" (click)="setTab(t.key)">{{ t.label }}</button> }
    </div>
    <div class="card">
      <div class="filters">
        @if (tab !== 'daily') {
          <label>Subject
            <select [(ngModel)]="subject" (ngModelChange)="load()">
              <option value="">All my subjects</option>
              @for (s of subjects; track s._id) { <option [value]="s._id">{{ s.code }} - {{ s.name }}</option> }
            </select>
          </label>
        }
        @if (tab === 'daily') { <label>Date<input type="date" [(ngModel)]="date" (ngModelChange)="load()" /></label> }
        @if (tab === 'late') {
          <label>From<input type="date" [(ngModel)]="from" (ngModelChange)="load()" /></label>
          <label>To<input type="date" [(ngModel)]="to" (ngModelChange)="load()" /></label>
        }
        <span class="spacer"></span>
        <button class="btn" [disabled]="!rows.length" (click)="export()">Export CSV</button>
      </div>

      @if (loading) { <div class="spinner-wrap"><div class="spinner"></div></div> }
      @else if (!rows.length) { <div class="empty"><strong>No data</strong>{{ emptyText }}</div> }
      @else {
        @if (tab === 'subject') {
          <app-chart type="bar" [labels]="chartLabels" [datasets]="chartSets" [options]="{ scales: { y: { min: 0, max: 100 } }, plugins: { legend: { display: false } } }" [height]="220" />
          <div class="table-wrap" style="margin-top:14px"><table>
            <thead><tr><th>Code</th><th>Subject</th><th>Sections</th><th class="num">Students</th><th class="num">Classes conducted</th><th class="num">Average %</th><th class="num">Below minimum</th></tr></thead>
            <tbody>@for (r of rows; track r.subjectId) { <tr><td>{{ r.code }}</td><td>{{ r.name }}</td><td>{{ r.sections }}</td><td class="num">{{ r.students }}</td><td class="num">{{ r.sessions }}</td><td class="num">{{ r.averagePercentage }}%</td><td class="num">{{ r.belowMin }}</td></tr> }</tbody>
          </table></div>
        }
        @if (tab === 'shortage') {
          <div class="table-wrap"><table>
            <thead><tr><th>Roll number</th><th>Student</th><th>Section</th><th>Subject</th><th class="num">Attended / Total</th><th class="num">Attendance</th><th class="num">Attend next</th></tr></thead>
            <tbody>@for (r of rows; track r.studentId + r.subjectId) { <tr><td>{{ r.rollNumber }}</td><td>{{ r.name }}</td><td>{{ r.section }}</td><td>{{ r.code }}</td><td class="num">{{ r.attended }} / {{ r.total }}</td><td class="num"><span class="badge bad">{{ r.percentage }}%</span></td><td class="num">{{ r.classesNeeded }}</td></tr> }</tbody>
          </table></div>
        }
        @if (tab === 'daily') {
          <div class="table-wrap"><table>
            <thead><tr><th>Period</th><th>Subject</th><th>Section</th><th class="num">Present</th><th class="num">Late</th><th class="num">Absent</th><th class="num">Total</th></tr></thead>
            <tbody>@for (r of rows; track $index) { <tr><td>{{ r.period }}</td><td>{{ r.code }} - {{ r.subject }}</td><td>{{ r.section }}</td><td class="num">{{ r.present }}</td><td class="num">{{ r.late }}</td><td class="num">{{ r.absent }}</td><td class="num">{{ r.total }}</td></tr> }</tbody>
          </table></div>
        }
        @if (tab === 'late') {
          <h3 style="margin-bottom:8px">Most frequent late entries</h3>
          <div class="row" style="margin-bottom:14px">
            @for (s of summary.slice(0, 5); track s.rollNumber) { <span class="badge warn">{{ s.name }} ({{ s.rollNumber }}): {{ s.count }}</span> }
          </div>
          <div class="table-wrap"><table>
            <thead><tr><th>Date</th><th>Period</th><th>Subject</th><th>Section</th><th>Roll number</th><th>Student</th></tr></thead>
            <tbody>@for (r of rows; track $index) { <tr><td>{{ r.date | date:'dd MMM yyyy':'UTC' }}</td><td>{{ r.period }}</td><td>{{ r.code }}</td><td>{{ r.section }}</td><td>{{ r.rollNumber }}</td><td>{{ r.name }}</td></tr> }</tbody>
          </table></div>
        }
      }
    </div>`,
})
export class FacultyReportsComponent implements OnInit {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  tabs = [
    { key: 'subject', label: 'Subject-wise' }, { key: 'shortage', label: 'Below minimum' },
    { key: 'daily', label: 'Daily summary' }, { key: 'late', label: 'Late entries' },
  ];
  tab = 'subject';
  loading = true;
  subjects: any[] = [];
  subject = ''; date = todayLocal(); from = ''; to = '';
  rows: any[] = [];
  summary: any[] = [];
  chartLabels: string[] = [];
  chartSets: any[] = [];
  get emptyText() {
    return { subject: 'No subjects assigned.', shortage: 'No student is below the minimum attendance.', daily: 'No attendance marked on this date.', late: 'No late entries recorded.' }[this.tab] as string;
  }

  ngOnInit() {
    this.api.get('/faculty/subjects').subscribe({ next: (s) => (this.subjects = s), error: () => {} });
    this.load();
  }
  setTab(t: string) { this.tab = t; this.load(); }
  private params() { return { subject: this.subject, date: this.date, from: this.from, to: this.to }; }

  load() {
    this.loading = true;
    this.api.get(`/faculty/reports/${this.tab}`, this.params()).subscribe({
      next: (r) => {
        this.rows = r.rows; this.summary = r.summary || []; this.loading = false;
        if (this.tab === 'subject') {
          this.chartLabels = r.rows.map((x: any) => x.code);
          this.chartSets = [{ label: 'Average attendance %', data: r.rows.map((x: any) => x.averagePercentage), backgroundColor: COLORS.blue, borderRadius: 4 }];
        }
      },
      error: (e) => { this.loading = false; this.toast.error(errMsg(e)); },
    });
  }
  export() { this.api.download(`/faculty/reports/${this.tab}/export`, this.params(), `${this.tab}-report.csv`); }
}
