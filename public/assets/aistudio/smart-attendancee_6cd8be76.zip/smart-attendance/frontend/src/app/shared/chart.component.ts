import { AfterViewInit, Component, ElementRef, Input, OnChanges, OnDestroy, ViewChild } from '@angular/core';
import { Chart, ChartType, registerables } from 'chart.js';

Chart.register(...registerables);
Chart.defaults.font.family = "system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif";
Chart.defaults.color = '#5b6685';

@Component({
  selector: 'app-chart',
  standalone: true,
  template: `<div class="chart-box" [style.height.px]="height"><canvas #c></canvas></div>`,
})
export class ChartComponent implements AfterViewInit, OnChanges, OnDestroy {
  @Input() type: ChartType = 'bar';
  @Input() labels: string[] = [];
  @Input() datasets: any[] = [];
  @Input() options: any = {};
  @Input() height = 260;
  @ViewChild('c') canvas!: ElementRef<HTMLCanvasElement>;
  private chart?: Chart;

  ngAfterViewInit() { this.render(); }
  ngOnChanges() { if (this.chart) this.render(); }
  ngOnDestroy() { this.chart?.destroy(); }

  private render() {
    this.chart?.destroy();
    this.chart = new Chart(this.canvas.nativeElement, {
      type: this.type,
      data: { labels: this.labels, datasets: this.datasets },
      options: { responsive: true, maintainAspectRatio: false, ...this.options },
    });
  }
}
