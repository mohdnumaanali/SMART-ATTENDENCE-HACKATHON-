import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-pager',
  standalone: true,
  template: `
    @if (pages > 1) {
      <div class="pager">
        <span class="muted">{{ total }} records &middot; page {{ page }} of {{ pages }}</span>
        <div class="row gap-s">
          <button class="btn sm" [disabled]="page <= 1" (click)="pageChange.emit(page - 1)">Previous</button>
          <button class="btn sm" [disabled]="page >= pages" (click)="pageChange.emit(page + 1)">Next</button>
        </div>
      </div>
    }`,
})
export class PagerComponent {
  @Input() page = 1;
  @Input() pages = 1;
  @Input() total = 0;
  @Output() pageChange = new EventEmitter<number>();
}
