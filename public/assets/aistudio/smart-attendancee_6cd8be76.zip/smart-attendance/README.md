# Smart Attendance Management System

Angular (frontend) + Node.js/Express (backend) + MongoDB. Three role-based portals: Student, Faculty, Admin.

```
smart-attendance/
├── backend/    Express API: config, models, middleware, controllers, services, routes, seed scripts
├── frontend/   Angular app: core (auth, api, guards, interceptor), shared (shell, chart, modal), features/{auth,student,faculty,admin}
├── package.json   root scripts used for deployment
└── render.yaml    one-click Render blueprint
```

## Run locally (VS Code)

Prerequisites: Node.js 18+ (20 recommended) and MongoDB (local, or a free Atlas cluster).

**1. Backend**
```bash
cd backend
npm install
cp .env.example .env          # Windows: copy .env.example .env  -> then edit MONGO_URI and JWT_SECRET
npm run test:math             # optional: verifies the eligibility formula
npm run seed                  # sample data (wipes the database!)
npm run dev                   # API on http://localhost:5000
```
**2. Frontend** (second terminal)
```bash
cd frontend
npm install
npm start                     # http://localhost:4200 (proxies /api to port 5000)
```

### Sample logins (after `npm run seed`)
| Role | Email | Password |
|---|---|---|
| Admin | admin@college.edu | Admin@123 |
| Faculty | ananya.rao@college.edu (also vikram.singh@, meera.nair@) | Faculty@123 |
| Student | aarav@student.college.edu (also diya@, rohan@, sneha@, kabir@, ishita@, arjun@, priya@, nikhil@, tanvi@, rahul@, aditi@) | Student@123 |

`nikhil@`, `kabir@` and `rahul@` have low attendance, so the shortage alerts and calculator have data.

## Deploy (single service on Render + MongoDB Atlas)

The backend serves the built Angular app, so one web service hosts everything and no CORS setup is needed.

**1. MongoDB Atlas**
1. Create a free cluster at mongodb.com/atlas.
2. Database Access: add a user with a password (avoid special characters, or URL-encode them).
3. Network Access: add `0.0.0.0/0` (Render's IPs change).
4. Connect > Drivers: copy the string and put your database name in it:
   `mongodb+srv://USER:PASSWORD@cluster0.xxxxx.mongodb.net/smart_attendance?retryWrites=true&w=majority`

**2. Create the first admin (run once, from your computer)**
```bash
cd backend && npm install
# macOS/Linux
MONGO_URI="<atlas string>" ADMIN_EMAIL=you@college.edu ADMIN_PASSWORD='ChooseAStrongOne1' npm run create-admin
# Windows PowerShell
$env:MONGO_URI="<atlas string>"; $env:ADMIN_EMAIL="you@college.edu"; $env:ADMIN_PASSWORD="ChooseAStrongOne1"; npm run create-admin
```
This creates the admin and a default academic session (minimum 75%). It is safe to re-run.
To load the demo data into Atlas instead, set `ALLOW_SEED=true` and `NODE_ENV=production`, then run `npm run seed` (it wipes the database).

**3. Render**
1. Push this folder to a GitHub repository.
2. Render dashboard > New > Blueprint > pick the repo (it reads `render.yaml`). Or New > Web Service with:
   - Build command: `npm run build`
   - Start command: `npm start`
3. Environment variables: `MONGO_URI` (Atlas string), `JWT_SECRET` (long random text), `NODE_ENV=production`, `NODE_VERSION=20`.
4. Deploy. Open the Render URL and sign in as the admin. Then add departments' students, faculty and subjects from the Admin portal.

The free Render plan sleeps after inactivity, so the first request can take about 30 seconds.

### Other options
- **Railway / any Node host:** same build and start commands, same environment variables.
- **Frontend on Vercel/Netlify, backend elsewhere:** build with `cd frontend && npm run build`, publish `dist/smart-attendance-frontend/browser`, add an SPA rewrite to `index.html`, set `API_URL` in `frontend/src/app/core/config.ts` to the full backend URL (for example `https://your-api.onrender.com/api`), and set `CLIENT_URL` on the backend to the frontend origin (comma separated for several).

## Environment variables (backend)
| Variable | Purpose |
|---|---|
| `MONGO_URI` | MongoDB connection string (required) |
| `JWT_SECRET` | Signing secret for tokens (required, keep private) |
| `JWT_EXPIRES_IN` | Token lifetime, default `1d` |
| `PORT` | Set automatically by most hosts, default 5000 |
| `CLIENT_URL` | Extra allowed browser origins (only for a separately hosted frontend) |
| `CORRECTION_WINDOW_DAYS` | How long faculty may correct their own attendance, default 7 |

## How the main rules work
- **Eligibility math** (`backend/src/utils/attendanceMath.js`): classes needed = ceil((p*T - 100*A) / (100 - p)); safe misses = floor(100*A/p - T). Attended counts Present, plus Late when "Late counts as attended" is on (Admin > System Settings).
- **No duplicates:** a unique MongoDB index on student + subject + date + period, plus API checks (also blocks two subjects in the same period for one section).
- **Corrections:** faculty can correct their own subjects for 7 days with a reason; admins can correct any record. Every change is logged on the record.
- **Alerts:** shortage and low-attendance notifications are created/updated whenever attendance is submitted or corrected.
- **Security:** bcrypt (cost 12) password hashing, JWT auth, role checks on every API route (verified against the database each request), rate-limited login, helmet, input validation, generic login errors.

## Known limits
- JWT logout is client-side (the token is discarded; it expires after `JWT_EXPIRES_IN`).
- A user's role is fixed at account creation. Students and faculty are created on their own admin pages; administrators from System Settings.
